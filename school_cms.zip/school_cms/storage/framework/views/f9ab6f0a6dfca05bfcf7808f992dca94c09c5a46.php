<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>CSRA | <?php echo e(@$title); ?></title>
    <meta content="" name="description">
    <meta content="" name="keywords">


    <!-- Favicons -->
    <link href="<?php echo e(asset('assets/img/Logo/logo.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('assets/img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?php echo e(asset('assets/vendor/animate.css/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/aos/aos.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet">

    <!-- Template Main CSS File -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.2/js/toastr.min.js"></script>
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" integrity="sha512-UTNP5BXLIptsaj5WdKFrkFov94lDx+eBvbKyoe1YAfjeRPC+gT5kyZ10kOHCfNZqEui1sxmqvodNUx3KbuYI/A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- <script src="https://code.jquery.com/jquery-2.2.4.js"></script> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

    <style>
        #navbar a {
            text-transform: uppercase;
        }

        .card:hover {
            transform: scale(1.03);
            /* box-shadow: 0 0 15px #000000, 0 0 30px #FFFFFF; */
        }

        #header .logo {
            margin-left: 30px;
        }

        .logo-right { margin-right: 30px; }
    </style>


</head>

<body>

   <!-- ======= Header ======= -->
   <header id="header" class="fixed-top">
        <div class="container-fluid d-flex align-items-center" style="margin-left: 0px;">

            <h1 class="logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/Logo/logo.png')); ?>" class="img-fluid"
                        alt="NR Group" style="max-height: 55px;"></a></h1>
       

            <nav id="navbar" class="navbar order-last order-lg-0 mx-lg-auto ms-auto">
                <ul>
                    <li class="header_item"><a class="" href="<?php echo e(route('customer.index')); ?>">Home</a></li>
                    <li class="header_item"><a class="" href="<?php echo e(route('customer.about')); ?>">ABOUT</a></li>
                    <li class="header_item"><a class="" href="<?php echo e(route('customer.activities')); ?>">ACTIVITIES</a></li>
                    <li class="header_item"><a class="" href="<?php echo e(route('customer.contact')); ?>">Contact</a></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav><!-- .navbar -->

            <h1 class="logo-right"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/img/since.png')); ?>" class="img-fluid"
                alt="NR Group" style="max-height: 55px;"></a></h1>
        </div>
    </header><!-- End Header -->

    <script>
        var pathname = window.location.pathname;

        $(document).ready(function() {
            $('ul li a').click(function() {
                // alert($(this).attr('href'));
                $('li a').removeClass("active");
                $(this).addClass("active");
            });
        });
    </script><?php /**PATH C:\xampp\htdocs\school_cms\resources\views/user/layout/header.blade.php ENDPATH**/ ?>