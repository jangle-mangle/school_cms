<?php echo $__env->make('user.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .banner_img {
        position: relative;
        display: inline-block;
        /* Ensures the div only takes up as much width as needed */
    }

    .text-overlay {
        position: absolute;
        top: 80%;
        /* Adjust as needed */
        left: 10%;
        /* Adjust as needed */
        transform: translate(25%, -50%);
        /* background-color: rgba(255, 255, 255, 0.5); */
        /* Semi-transparent background */
        padding: 10px;
        color: black;
        /* font-size: 18px; */
        text-align: left;
    }

    .text-overlay h1 {
        color: #ffffff;
        font-weight: bold;
    }

    .text-overlay p {
        color: #ffffff;
    }

    #about {
        line-height: 2.2;
        font-size: 17px;
    }

    #core-values {
        color: #ffffff;
    }

    #core-values span.heading {
        padding: 10px 30px;
        background: #ff0000;
        border-radius: 2rem;
        margin-bottom: 45px;
    }

    #core-values ul li,
    #core-values p {
        line-height: 1.8;
        /* margin-top: 20px; */
    }

    .leadership_team_btn a { font-size: 21px; padding: 10px 40px; border: 1px solid #000; border-radius: 2rem; color: #000000; }
    .leadership_team_btn .row-icon { font-size: 40px; margin-left: 15px; }
</style>

<!-- ======= Hero Section ======= -->

<main id="main">

    <section id="hero">
        <img class="banner_img" src="<?php echo e(asset('user/home/home-banner.jpg')); ?>" alt="">
        <div class="text-overlay" style="line-height: 6px">
            <h1>RELATIONSHIPS</h1>
            <h1>STRONGER</h1>
            <h1>THAN STEEL</h1>
            <p>CSRA forges relationships that are stronger than</p>
            <p>steel, building a foundation that endures. We believe</p>
            <p>in connections built on resilience and trust, standing</p>
            <p>firm against any challenge.</p>
        </div>
    </section><!-- End Hero -->
    <section style="padding: 0px 0px">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <img src="<?php echo e(asset('user/home/india-map.png')); ?>" alt="">
                </div>
                <div class="col-md-4 offset-lg-1">
                    <img src="<?php echo e(asset('user/home/cg-map.png')); ?>" alt="">
                </div>
            </div>
        </div>

    </section>
    <!-- ======= About Section ======= -->
    <section id="about" class="about section_mob_view" style="padding:0px 0px ">
        <div class="container px-lg-5" data-aos="fade-up">

            <div class="row align-items-center">
                <div class="col-md-5">
                    <h1 class="">About CSRA</h1>
                    <p>Chhattisgarh Steel Re-Rollers Association (CSRA) is an organization that has been dedicated
                        to enhancing the Steel Re-Rolling business
                        opportunities for its members since its inception in the year 1981. Registered under the
                        Societies Registration Act 1860, CSRA is
                        located in the vibrant city of Raipur, in the state of Chhattisgarh.</p>

                </div>
                <div class="col-md-7">
                    <img class="img-fluid" src="<?php echo e(url('user/home/men-bg.jpg')); ?>" alt="">
                </div>
            </div>
        </div>
    </section>

    <section id="core-values" style="background: url(<?php echo e(url('user/home/values-bg.jpg')); ?>)">
        <div class="container px-lg-5" data-aos="fade-up">
            <div class="row align-items-start">
                <div class="col-lg-6">
                    <div class="row px-4">
                        <div class="col-lg-12 px-4 card_height">
                            <div class="row">
                                <div class="col-lg-3 col-6">
                                    <img src="<?php echo e(asset('user/home/diamond-icon.png')); ?>" class="img-fluid"
                                        alt="">
                                </div>
                                <div class="col-lg-8">
                                    <span class="heading">CORE VALUES</span>
                                    <ul class="mt-lg-3" style="line-height: 1px; ">
                                        <li>Evironment Over Everything</li>
                                        <li>24 x 7 Member Help</li>
                                        <li>To Help Members With Government Rules and Regulations</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mt-lg-5">
                            <div class="row">
                                <div class="col-lg-3 col-6">

                                </div>
                                <div class="col-lg-8">
                                    <span class="heading">मुल सिद्धांत </span>
                                    <ul class="mt-3">
                                        <li>पर्यावरण पहले, हमेशा</li>
                                        <li>२४ x ७ सदस्यों की सहायता</li>
                                        <li>सदस्यों को सरकार के नीति एवं नियमों से अवगत करना</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row px-4" style="border-left: 1px solid #dddddd;">
                        <div class="col-lg-12 px-4 card_height">
                            <div class="row">
                                <div class="col-lg-3 col-6">
                                    <img src="<?php echo e(asset('user/home/goal.png')); ?>" class="img-fluid" alt="">
                                </div>
                                <div class="col-lg-8">
                                    <span class="heading">CORE PURPOSE</span>
                                    <p class="mt-3">To provide information, programs, and services that improve the business
                                        opportunities of its members, and to facilitate coordination among members and
                                        with both state and central governments.</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-12 mt-lg-5">
                            <div class="row">
                                <div class="col-lg-3 col-6">

                                </div>
                                <div class="col-lg-8">
                                    <span class="heading">मुल उद्देश्य </span>
                                    <p class="mt-3">राज्य और केन्द्र सरकार के बीच समन्वय के साथ अपने सदस्यों का व्यवसायिक उत्थान में
                                        सुधार करने वाली जानकारी, कार्यक्रम और सेवाए प्रदान करना </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section><!-- End About Section -->



    <!-- ======= Our Product Section ======= -->
    <section id="our_service" class="our_service">
        <div class="container py-lg-5 py-3" data-aos="fade-up">
            <center>
                <h1 class="text-dark text-uppercase">LEADERSHIP TEAM</h1>
            </center>
            <div class="row justify-content-center my-lg-4">
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-01.png')); ?>" class="img-fluid rounded" alt=""
                            style="width: 12rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">President</p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold">Mr. Sanjay
                                Tripathi,
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Shivam Structural & Steel)</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-02.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 13rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Gr. Secretary</p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold">Mr. Banke Bihari
                                Agrawal,
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Shivam Structural & Steel)</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-03.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 12rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Treasure</p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold">Mr. Om Prakash
                                Agrawal
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Sindh Ispat)</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-04.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 12rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">IPP</p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold">Mr. Manoj
                                Kumar Agrawal
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Mahendra Sponge & Power)</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-05.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 13rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Vice President</p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold">Mr. Vinod
                                Agrawal,

                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Krishna Iron Strips & Tubes)</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center my-lg-4">
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-06.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 12rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Vice President

                            </p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold"> Mr. Ajay
                                Gupta,
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark"> (M/s. Adarsh Ispat Udyog Pvt. Ltd.)
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-07.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 13rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Joint Secretary

                            </p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold"> Mr. Rajkumar
                                Agrawal,
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark"> (M/s. Alankar Steels Pvt. Ltd)</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-08.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 12rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Joint Secretary

                            </p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold"> Mr. Ashish
                                Jindal,
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Ajay Ingot Rolling Mill Pvt.
                                Ltd.)</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-09.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 12rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Joint Secretary

                            </p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold"> Mr. R. N.
                                Singla,
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Fortun Metliks Ltd.)</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 text-center my-0 leaders p-2">
                    <div>
                        <img src="<?php echo e(asset('assets/img/home/team-10.png')); ?>" class="img-fluid rounded"
                            alt="" style="width: 12rem;">
                        <div class="my-2">
                            <p style="font-size: 11px;" class="my-0 text-dark">Vice Presiden</p>
                            <p style="font-size: 13px;" class="my-0 text-dark text-capitalize fw-bold">Mr. Anand
                                Choudhary je
                            </p>
                            <p style="font-size: 11px;" class="my-0 text-dark">(M/s. Drolia Electrosteels Pvt. Ltd.)
                            </p>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row justify-content-center leadership_team_btn">
                <div class="col-4">
                    <a href="<?php echo e(route('executive.member')); ?>">
                        <span>VIEW EXECUTIVE MEMBERS</span> <span class="row-icon">&#x203A;</span>
                        
                    </a>
                </div>
                <div class="col-4">
                    <a href="<?php echo e(route('member')); ?>">
                        <span>VIEW ALL MEMBERS</span> <span class="row-icon">&#x203A;</span>
                        
                    </a>
                </div>
            </div>

        </div>
    </section><!-- End Our Product Section -->




</main><!-- End #main -->

<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
<?php echo $__env->make('user.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- End Footer -->
<?php /**PATH C:\xampp\htdocs\school_cms\resources\views/user/homepage.blade.php ENDPATH**/ ?>