<style>
    .deal-edit-label {
        cursor: pointer;
        background-color: #80808063;
        clip-path: polygon(75% 0%, 93% 48%, 78% 100%, 0% 100%, 10% 49%, 0% 0%);
        height: 35px;
    }

    .deal-edit-label-active {
        cursor: pointer;
        background-color: #32557f;
        clip-path: polygon(75% 0%, 93% 48%, 78% 100%, 0% 100%, 10% 49%, 0% 0%);
        height: 35px;
    }

    .deal-edit-label p,
    .deal-edit-label-active p {
        position: relative;
        top: 6px;
        color: white;
        text-align: center;
        font-size: 13px;
    }
</style>
<div class="modal fade text-left" id="bannerAddModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-top modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add New Banner</h4>
                <button type="button" class="close close-btn" data-dismiss="modal" aria-label="Close">
                    <i class="bx bx-x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('admin.add.banner')); ?>" method="POST" class="form form-vertical" id="banner_add_data" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" class="form-control-file form-control"
                    name="id">
                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add-album-thumbnail-image">Banner Image</label>
                                    <div class="position-relative has-icon-left">
                                        <input type="file" id="add-album-thumbnail-image" class="form-control-file form-control"
                                            name="img">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="add-position">Title</label>
                                    <div class="position-relative ">
                                        <input type="text" id="add-title" class="form-control " name="title"
                                            placeholder="Enter Title">
                                        <div class="form-control-position">
                                            <i class='bx bx-sort-alt-2'></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="my-2 btn btn-sm btn-primary px-4" type="submit">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\school_cms\resources\views/admin/modal/bannerAddModal.blade.php ENDPATH**/ ?>