<style>
    .deal-edit-label {
        cursor: pointer;
        background-color: #80808063;
        clip-path: polygon(75% 0%, 93% 48%, 78% 100%, 0% 100%, 10% 49%, 0% 0%);
        height: 35px;
    }

    .deal-edit-label-active {
        cursor: pointer;
        background-color: #32557f;
        clip-path: polygon(75% 0%, 93% 48%, 78% 100%, 0% 100%, 10% 49%, 0% 0%);
        height: 35px;
    }

    .deal-edit-label p,
    .deal-edit-label-active p {
        position: relative;
        top: 6px;
        color: white;
        text-align: center;
        font-size: 13px;
    }
</style>
<div class="modal fade text-left" id="roleModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-top modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add New Role</h4>
                <button type="button" class="close close-btn" data-dismiss="modal" aria-label="Close">
                    <i class="bx bx-x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form class="form form-vertical" id="role_add_data" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="role-id" name="id" />
                    <div class="form-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="job_title">Role Name</label>
                                    <div class="position-relative has-icon-left">
                                        <input type="text" id="name" class="form-control" name="name" placeholder="Enter Name" required>
                                        <div class="form-control-position">
                                            <i class="bx bxs-label"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-secondary close-btn" data-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ml-1 role-add-btn">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Save</span>
                </button>
            </div>
        </div>
    </div>
</div>



<script>
    $(document).ready(function() {


        $(document).on('click', '#roleModal .close-btn', function() {

            resetAlbumAddFrom();
        });
        
        $(document).on('click', '.role-edit-btn', function() {
            var id = $(this).data('id');
            var name = $(this).data('name');
            $("#role-id").val(id);
            $("#name").val(name);
        });

        $(document).on('click', '.role-add-btn', function() {

            var that = this;
            var title = $('#name').val();

            //validation
            var error = 0;
            if (title == "" || title == undefined || title == null) {
                Toast.fire({
                    icon: 'error',
                    title: 'Please Enter Title.'
                });
                error += 1;
                return false;
            } else if (error == 0) {

                var myform = document.getElementById("role_add_data");
                var formData = new FormData(myform);

                formData.append('_token', '<?php echo e(csrf_token()); ?>');
                $(this).html('Saving...').attr('disabled', true);
                $.ajax({
                    type: "post",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    url: "<?php echo e(route('admin.add.role')); ?>",
                    success: function(result) {
                        $(that).html('Save').attr('disabled', false);

                        if (result.error == true) {
                            Toast.fire({
                                icon: 'error',
                                title: result.message
                            });
                        } else {
                            Toast.fire({
                                icon: 'success',
                                title: result.message
                            });
                            $('#roleModal').modal('toggle');
                            resetAlbumAddFrom();
                        }
                        $('#roleTable').DataTable().ajax.reload();
                    }
                });
            }

        });



    }); // Main script closing tag.
</script><?php /**PATH C:\xampp\htdocs\school_cms\resources\views/admin/modal/roleModal.blade.php ENDPATH**/ ?>