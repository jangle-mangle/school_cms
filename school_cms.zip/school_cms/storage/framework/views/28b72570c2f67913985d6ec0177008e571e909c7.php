<style>
    .whatsapp-fixed {
        display: block;
        width: 60px;
        height: 60px;
        line-height: 60px;
        text-align: center;
        border-radius: 50%;
        position: fixed;
        bottom: 24px;
        left: 10px;
        z-index: 100;
        color: #fff0;
        font-size: 30px;
        background: #4ac65900;
    }
</style>

<footer id="footer" class="bg-dark">

<div class="footer-top ">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-lg-3 col-md-6 footer-contact offset-lg-1">
                <img src="<?php echo e(asset('assets/img/Logo/logo.png')); ?>" class="img-fluid" style="max-width:20%;" alt="">
                <hr class="text-light">
                <p class="text-light">
                    Corporate Office <br>
                    1st Floor, Sona Tower, Ramsagar
                    Para, Raipur, C.G.-492001
                    <br>
                    <br>
                    <strong>Email Us <br> </strong>
                    office.cgsra@gmail.in<br>
                    cgrsra@rediffmail.com,<br>
                    <br>

                    <strong>Call Us <br></strong>
                    0771-2292732, 4017502<br>
                    <br>
                </p>
            </div>

            <div class="col-lg-2 col-md-6 footer-links">

                <ul>
                    <li><i class="bx bx-chevron-right"></i> <a href="index.html">HOME</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="about.html">ACTIVITIES</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="javascript:void(0);"
                            id="our-company-menu">CONTACT</a></li>
                </ul>
            </div>

            <div class="col-lg-2 offset-lg-2">
                <div class="social-links text-center d-flex flex-row flex-sm-column text-md-right pt-3 pt-md-0">
                    <a href="#" class="facebook my-2"><i class="bx bxl-facebook"></i></a>
                    <a href="#" class="twitter my-2"><i class="bx bxl-twitter"></i></a>
                    <a href="#" class="instagram my-2"><i class="bx bxl-instagram"></i></a>
                    <!-- <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a> -->
                    <!-- <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a> -->
                </div>
            </div>
            <hr>
            <div class="copyright text-light">
                &copy; Copyright 2023-2024<strong><span>Adish Digital </span></strong> LLP. All Rights
                Reserved
            </div>

            
        </div>
    </div>
</div>


</footer><!-- End Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="<?php echo e(asset('assets/vendor/purecounter/purecounter_vanilla.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/aos/aos.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/php-email-form/validate.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- Template Main JS File -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

<script>
    $(document).ready(function() {
        $('#navbar li a').each(function(index, value) {
            if ($(this).attr('href') == window.location.href) {
                $(this).addClass('active');
                $(this).closest('.dropdown').find('a:first').addClass('active');
            } else if (window.location.pathname == '/' && $(this).attr('href') == window.location
                .origin) {
                $(this).addClass('active');
            }
        });

        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 100,
            nav: false,
            autoplay: true,
            autoPlaySpeed: 1000,
            autoPlayTimeout: 1000,
            autoplayHoverPause: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            }
        })
    });

    $(document).on('click', '#our-company-menu', function() {
        $('#our-company-submenu').slideToggle("slow");
    });

    $(document).on('click', '#product-menu', function() {
        $('#product-submenu').slideToggle("slow");
    });

      // 3D Slider  
      $('.slider').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: true,
            dots: false,
            centerMode: true,
            variableWidth: true,
            infinite: true,
            focusOnSelect: true,
            cssEase: 'linear',
            touchMove: true,
            prevArrow: '<button class="slick-prev"> < </button>',
            nextArrow: '<button class="slick-next"> > </button>',

            //         responsive: [                        
            //             {
            //               breakpoint: 576,
            //               settings: {
            //                 centerMode: false,
            //                 variableWidth: false,
            //               }
            //             },
            //         ]
        });

        $(".contact_us_form").submit(function(event) {
        event.preventDefault();
        var formData = new FormData($(this)[0]);
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('user.contact_us.form')); ?>",
            data: formData,
            dataType: 'json',
            contentType: false,
            cache: false,
            processData: false,
            // beforeSend: function()
            // {
            //   $("#warning-msg").removeClass('d-none');
            //   $("#warning-msg").text('Data is being saved do not refresh or submit again');
            // },
            success: function(data) {
                // console.log(data);
                if (data.status) {
                    toastr.success(data.message, '', {
                        closeButton: !0,
                        tapToDismiss: !1,
                        progressBar: true,
                        timeOut: 1000
                    });
                    location.reload();
                } else {
                    toastr.error(data.message, '', {
                        closeButton: !0,
                        tapToDismiss: !1,
                        progressBar: true,
                        timeOut: 1000
                    });
                }
            }
        });
    });
</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\school_cms\resources\views/user/layout/footer.blade.php ENDPATH**/ ?>