<?php echo $__env->make('user.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .banner_img {
        position: relative;
        display: inline-block;
        /* Ensures the div only takes up as much width as needed */
    }

    .text-overlay {
        position: absolute;
        top: 80%;
        /* Adjust as needed */
        left: 10%;
        /* Adjust as needed */
        transform: translate(25%, -50%);
        /* background-color: rgba(255, 255, 255, 0.5); */
        /* Semi-transparent background */
        padding: 10px;
        color: black;
        /* font-size: 18px; */
        text-align: left;
        margin-top: -4px;
    }

    .text-overlay h1 {
        color: #ffffff;
        font-weight: bold;
    }

    .text-overlay p {
        color: #ffffff;
    }

    #about {
        line-height: 2.2;
        font-size: 17px;
    }

    #core-values {
        color: #ffffff;
    }

    #core-values span.heading {
        padding: 10px 30px;
        background: #ff0000;
        border-radius: 2rem;
        margin-bottom: 45px;
    }

    #core-values ul li,
    #core-values p {
        line-height: 2.3;
        margin-top: 20px;
    }

    .leadership_team_btn a {
        font-size: 21px;
        padding: 10px 40px;
        border: 1px solid #000;
        border-radius: 2rem;
        color: #000000;
    }

    .leadership_team_btn .row-icon {
        font-size: 40px;
        margin-left: 15px;
    }
</style>
<!-- ======= Hero Section ======= -->
<main id="main">
    <section id="hero">
        <img class="banner_img" src="<?php echo e(asset('assets/img/about/banner.png')); ?>" alt="">
        <div class="text-overlay">
            <h1>Mahamaya Steel <br>
                Industries Limited
            </h1>
        </div>
    </section><!-- End Hero -->
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <img src="<?php echo e(asset('assets/img/about/icon.png')); ?>" style="width: 7rem" alt="">
                    <h1 class="my-lg-4 my-2">About Mahamaya Steel</h1>
                    <p class="text-justify px-lg-5 mx-lg-5 text-start">
                        Mahamaya Steel Industries Limited, popularly known as the Mahamaya Group, is an industrial
                        powerhouse with a dominant presence in the Chhattisgarh steel industry. As of fiscal year
                        2022-23, its net worth has grown to Rs. 127.86 Crores, up from Rs. 123.51 Crores in 2021-22. In
                        terms of tonnage, it ranks among the top 5 steel producers in the state.
                        <br> <br>
                        The company boasts a steel structural manufacturing capacity of 2,55,000 MT PA, a furnace
                        capacity of 2,00,000 TPA, and an oxygen plant with a capacity of 9,00,000 cubic meters PA.
                        Mahamaya Group has earned its reputation through consistent growth and a commitment to
                        strengthening the nation's future and building a better world.
                        <br>
                        <br>
                        Under its banner, the group includes subsidiary companies Devi Iron & Power Private Limited and
                        Abhishek Steel Industries Limited, both of which perform well in terms of production. Devi Iron
                        & Power Private Limited operates a 7.5 MW power plant and also has a sponge iron manufacturing
                        capacity of 90,000 MT PA. Both subsidiaries contribute significantly to the group's overall
                        turnover.
                        Founded in 1988, the company's journey began with the vision of building a purposeful
                        organization that could enhance the state's growth while creating opportunities for its people.
                        Notably, in 1998, the group became the first in the private sector to produce 600 mm joists. In
                        2021, it achieved another milestone by manufacturing flats up to 500 mm, again as the first
                        private sector company in India. Today, Mahamaya remains a leading manufacturer of both heavy
                        and light structures, operating under the "UNDER ONE ROOF" concept.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row mx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h1 class="my-lg-4 my-2">Our Products</h1>
                    <div class="row">
                        <div class="col-lg-4 col-6 my-2 position-relative  text-center">
                            <img src="<?php echo e(asset('assets/img/about/product.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;">JOIST</p>
                        </div>
                        <div class="col-lg-4 col-6 my-2 position-relative  text-center">
                            <img src="<?php echo e(asset('assets/img/about/product1.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;">CHANNEL</p>
                        </div>
                        <div class="col-lg-4 col-6 my-2 position-relative  text-center">
                            <img src="<?php echo e(asset('assets/img/about/product2.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;"> BILLET</p>
                        </div>
                        <div class="col-lg-4 col-6 my-2  position-relative text-center">
                            <img src="<?php echo e(asset('assets/img/about/product3.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;">SQUARE BLOOM</p>
                        </div>
                        <div class="col-lg-4 col-6 my-2 position-relative  text-center">
                            <img src="<?php echo e(asset('assets/img/about/product4.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;">CROSSING SLEEPER </p>
                        </div>
                        <div class="col-lg-4 col-6 my-2 position-relative  text-center">
                            <img src="<?php echo e(asset('assets/img/about/product5.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;">ROUND </p>
                        </div>
                        <div class="col-lg-4 col-6 my-2 position-relative  text-center">
                            <img src="<?php echo e(asset('assets/img/about/product6.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;">FLAT </p>
                        </div>
                        <div class="col-lg-4 col-6 my-2 position-relative  text-center">
                            <img src="<?php echo e(asset('assets/img/about/product7.png')); ?>" class="img-fluid" alt="">
                            <p class="bg-secondary text-light position-absolute bottom-0 w-75 rounded-pill"
                                style="left: 13%;">ANGLE</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="row justify-content-center">
                <center>
                    <h1 class="my-lg-4 my-4">LEADERSHIP TEAM</h1>
                </center>
                <div class="col-lg-7">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 my-lg-3 my-2">
                            <img src="<?php echo e(asset('assets/img/about/leader1.png')); ?>" alt="">
                            <small>
                                <center>
                                    <span>
                                        Director
                                        <br>
                                        Mr. Rajesh Agrawal
                                    </span>
                                </center>
                            </small>
                        </div>
                        <div class="col-lg-3 my-lg-3 my-2">
                            <img src="<?php echo e(asset('assets/img/about/leader2.png')); ?>" alt="">
                            <small>
                                <center>
                                    <span>
                                        Director
                                        <br>
                                        Mrs. Rekha Agrawal
                                    </span>
                                </center>
                            </small>
                        </div>
                        <div class="col-lg-3 my-lg-3 my-2">
                            <img src="<?php echo e(asset('assets/img/about/leader3.png')); ?>" alt="">
                            <small>
                                <center>
                                    <span>
                                        Director
                                        <br>
                                        Mr. Suresh Raman
                                    </span>
                                </center>
                            </small>
                        </div>
                        <div class="col-lg-3 my-lg-3 my-2">
                            <img src="<?php echo e(asset('assets/img/about/leader4.png')); ?>" alt="">
                            <small>
                                <center>
                                    <span>
                                        Director
                                        <br>
                                        Mr. Udayraj Singhania
                                    </span>
                                </center>
                            </small>
                        </div>
                        <div class="col-lg-3 my-lg-3 my-2">
                            <img src="<?php echo e(asset('assets/img/about/leader5.png')); ?>" alt="">
                            <small>
                                <center>
                                    <span>
                                        Director
                                        <br>
                                        Mr. Rajesh Lunia
                                    </span>
                                </center>
                            </small>
                        </div>
                        <div class="col-lg-3  my-lg-3 my-2">
                            <img src="<?php echo e(asset('assets/img/about/leader6.png')); ?>" alt="">
                            <small>
                                <center>
                                    <span>
                                        Director
                                        <br>
                                        Mrs. Vanitha Rangaiah
                                    </span>
                                </center>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container">
            <div class="row mx-lg-5">
                <div class = "card-wrapper">
                    <div class = "card border-0">
                        <!-- card left -->
                        <div class = "product-imgs">
                            <div class="row">
                                <div class="col-lg-9">
                                    <div class = "img-display">
                                        <div class = "img-showcase">
                                            <img class="main_img" src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                alt = "shoe image">
                                            <img class="main_img" src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                alt = "shoe image">
                                            <img class="main_img" src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                alt = "shoe image">
                                            <img class="main_img" src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                alt = "shoe image">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <div class = "img-select d-lg-flex flex-lg-column">
                                        <div class = "img-item">
                                            <a href = "#" data-id = "1">
                                                <img class="img"
                                                    src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                    alt = "shoe image">
                                            </a>
                                        </div>
                                        <div class = "img-item">
                                            <a href = "#" data-id = "2">
                                                <img class="img"
                                                    src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                    alt = "shoe image">
                                            </a>
                                        </div>
                                        <div class = "img-item">
                                            <a href = "#" data-id = "3">
                                                <img class="img"
                                                    src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                    alt = "shoe image">
                                            </a>
                                        </div>
                                        <div class = "img-item">
                                            <a href = "#" data-id = "4">
                                                <img class="img"
                                                    src = "<?php echo e(asset('assets/img/about/slider.png')); ?>"
                                                    alt = "shoe image">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
<?php echo $__env->make('user.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Footer -->

<script>
    const imgs = document.querySelectorAll(".img-select a");
    const imgBtns = [...imgs];
    let imgId = 1;

    imgBtns.forEach((imgItem) => {
        imgItem.addEventListener("click", (event) => {
            event.preventDefault();
            imgId = imgItem.dataset.id;
            slideImage();
        });
    });

    function slideImage() {
        const displayWidth = document.querySelector(
            ".img-showcase img:first-child"
        ).clientWidth;

        document.querySelector(".img-showcase").style.transform = `translateX(${
        -(imgId - 1) * displayWidth
    }px)`;
    }

    window.addEventListener("resize", slideImage);
</script>
<?php /**PATH F:\suraj\csra-main\csra-main\resources\views/user/about.blade.php ENDPATH**/ ?>