<!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light">
      <p class="clearfix mb-0"><span class="float-left d-inline-block"></span><span class="float-right d-sm-inline-block d-none">@<?php echo date('Y'); ?> All Rights Reserved by
        <a class="text-uppercase" href="#" target="_blank">CSRA.</a>
      </span>
        <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="bx bx-up-arrow-alt"></i></button>
      </p>
    </footer>
    <!-- END: Footer-->
    <script src="<?php echo e(asset('app-assets/vendors/js/vendors.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js ')); ?>"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/swiper.min.js ')); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('app-assets/js/scripts/configs/vertical-menu-light.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/core/app-menu.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/core/app.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/components.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/footer.min.js ')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/customizer.min.js ')); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <!-- END: Page JS-->

    <!-- <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/jquery.dataTables.min.js')); ?>"></script> -->
    <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
    <!-- <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js')); ?>"></script> -->
    <script src="<?php echo e(asset('app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('app-assets/js/scripts/pages/bootstrap-toast.min.js')); ?>"></script>

    <script src="<?php echo e(asset('app-assets/js/scripts/extensions/toastr.min.js')); ?>"></script>
   
    <script src="<?php echo e(asset('app-assets/js/scripts/extensions/sweet-alerts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/sweetalert2.all.min.js')); ?>"></script>

     <script src="<?php echo e(asset('app-assets/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/forms/select/form-select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('app-assets/vendors/js/pickers/pickadate/picker.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/pickers/pickadate/picker.date.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/pickers/pickadate/picker.time.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/pickers/pickadate/legacy.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/moment.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('app-assets/vendors/js/pickers/daterange/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js')); ?>"></script>

    <script src="<?php echo e(asset('app-assets/js/scripts/pages/app-invoice.min.js')); ?>"></script>

    <script src="<?php echo e(asset('app-assets/vendors/js/forms/repeater/jquery.repeater.min.js')); ?>"></script>

    <script src="<?php echo e(asset('vendor/uploader/js/fileinput.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('vendor/uploader/themes/fas/theme.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('vendor/uploader/themes/explorer-fas/theme.js')); ?>" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


    <!-- summernote -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <script>
      // summernote
      $(document).ready(function() {
        $('#summernote').summernote();
    });



     const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        didOpen: (toast) => {
          toast.addEventListener('mouseenter', Swal.stopTimer)
          toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
      })
    </script><?php /**PATH C:\xampp\htdocs\csra-main\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>