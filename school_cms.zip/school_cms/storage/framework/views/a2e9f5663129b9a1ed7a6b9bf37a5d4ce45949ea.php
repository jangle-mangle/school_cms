<?php echo $__env->make('user.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    #upcoming-event .heading span,
    #contact .heading span {
        font-size: 28px;
        font-weight: bold;
    }

    #upcoming-event .up-event-div {
        border: 2px solid #000;
        border-radius: 20px;
        padding: 5px;
    }

    #upcoming-event .container .outer {
        background: #dddddd;
        padding: 15px;
        border-radius: 20px;
    }
</style>

<!-- ======= Hero Section ======= -->
<main id="main">
    <section id="hero">
        <img class="banner_img" src="<?php echo e(asset('assets/img/activities/activity-banner.jpg')); ?>" alt="">
    </section>
    <section id="upcoming-event">
        <div class="container text-center">
            <div class="outer row d-flex flex-column justify-content-center align-items-center text-center">
                <div class="heading mb-3">
                    <span>UPCOMING EVENTS</span>
                    <center>
                        <img  style="width: 100px" src="<?php echo e(asset('assets/img/Activities/vl.png')); ?>" class="img-fluid d-block" alt="">
                    </center>
                </div>

                <div class="col-lg-5 border border-dark rounded-pill my-2 py-2">
                    <span class="h4 fw-bold">Vasant Panchami</span>
                    <span class="h5">Wed, 14 Feb, 2024</span>
                </div>



                <div class="col-lg-5 border border-dark rounded-pill my-2 py-2">
                    <span class="h4 fw-bold">Holi Celebration</span>
                    <span class="h5">Mon, 25 March, 2024</span>
                </div>



                <div class="col-lg-5 border border-dark rounded-pill my-2 py-2">
                    <span class="h4 fw-bold">Mahashivratri</span>
                    <span class="h5">Fri, 8 March, 2024</span>
                </div>



                <div class="col-lg-5 border border-dark rounded-pill my-2 py-2">
                    <span class="h4 fw-bold">Baisakhi</span>
                    <span class="h5">Sat, 13 Apr, 2024</span>
                </div>



                <div class="col-lg-5 border border-dark rounded-pill my-2 py-2">
                    <span class="h4 fw-bold">Akshay Tritiya</span>
                    <span class="h5">Fri, 10 May, 2024</span>
                </div>



                <div class="col-lg-5 border border-dark rounded-pill my-2 py-2">
                    <span class="h4 fw-bold">Dussehra</span>
                    <span class="h5">Sat, 12 Oct, 2024</span>
                </div>

            </div>
        </div>
    </section>
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section_mob_view">
        <div class="container" data-aos="fade-up">
            <div class="heading mb-3 text-center">
                <span>PAST EVENTS</span>
            </div>
            <div class="row">
                <div class="col-lg-6 my-2">
                    <img src="<?php echo e(asset('assets/img/Activities/activities-01.png')); ?>" class="img-=fluid" alt="">
                </div>
                <div class="col-lg-6 my-2">
                    <img src="<?php echo e(asset('assets/img/Activities/activities-02.png')); ?>" class="img-=fluid" alt="">
                </div>
                <div class="col-lg-6 my-2">
                    <img src="<?php echo e(asset('assets/img/Activities/activities-03.png')); ?>" class="img-=fluid" alt="">
                </div>
                <div class="col-lg-6 my-2">
                    <img src="<?php echo e(asset('assets/img/Activities/activities-04.png')); ?>" class="img-=fluid" alt="">
                </div>
                <div class="col-lg-6 my-2">
                    <img src="<?php echo e(asset('assets/img/Activities/activities-05.png')); ?>" class="img-=fluid" alt="">
                </div>
            </div>

        </div>
    </section><!-- End Contact Section -->



</main><!-- End #main -->

<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
<?php echo $__env->make('user.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- End Footer -->
<?php /**PATH F:\suraj\csra-main\csra-main\resources\views/user/activities.blade.php ENDPATH**/ ?>