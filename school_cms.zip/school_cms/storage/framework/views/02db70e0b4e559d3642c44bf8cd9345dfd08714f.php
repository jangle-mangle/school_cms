<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row"></div>
        <div class="content-body">
            <section class="users-list-wrapper">
                <div class="users-list-table mt-2">
                    <div class="card">
                        <div class="card-body">
                            <!-- datatable start -->
                            <div class="table-responsive">
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#bannerAddModal" style="float: right;">Add</button>
                                <table id="ExecutiveMembersTable" class="table table-striped" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Title</th>
                                            <th>Banner</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                                        <tr>
                                            <td><?php echo e($banner->id); ?></td>
                                            <td><?php echo e($banner->title); ?></td>
                                            <td>
                                                <img style="width:50px;" src="<?php echo e(asset('uploads/banner/'.$banner->img)); ?>" alt="">
                                            </td>
                                            <td>
                                                <a class="btn btn-sm btn-outline-danger" href="<?php echo e(url('admin/admin-delete-banner/'.$banner->id)); ?>"> Delete </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <!-- datatable ends -->
                            </div>
                            <!-- datatable ends -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- users list ends -->
        </div>
    </div>
</div>
<div class="buy-now" style="right: 60px;"><button type="button" class="btn btn-danger" data-toggle="modal"
        data-target="#vacancyAddModal">+</button></div>
<div class="sidenav-overlay"></div>
<div class="drag-target"></div>
<!-- Earning Swiper Starts -->


<?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modal.bannerAddModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\xampp\htdocs\school_cms\resources\views/admin/banner/banner.blade.php ENDPATH**/ ?>