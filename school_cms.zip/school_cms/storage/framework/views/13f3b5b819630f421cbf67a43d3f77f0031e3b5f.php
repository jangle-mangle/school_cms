<style>
    .deal-edit-label {
        cursor: pointer;
        background-color: #80808063;
        clip-path: polygon(75% 0%, 93% 48%, 78% 100%, 0% 100%, 10% 49%, 0% 0%);
        height: 35px;
    }

    .deal-edit-label-active {
        cursor: pointer;
        background-color: #32557f;
        clip-path: polygon(75% 0%, 93% 48%, 78% 100%, 0% 100%, 10% 49%, 0% 0%);
        height: 35px;
    }

    .deal-edit-label p,
    .deal-edit-label-active p {
        position: relative;
        top: 6px;
        color: white;
        text-align: center;
        font-size: 13px;
    }
</style>
<div class="modal fade text-left" id="executiveMemberModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-top modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Add New Executive Member</h4>
                <button type="button" class="close close-btn" data-dismiss="modal" aria-label="Close">
                    <i class="bx bx-x"></i>
                </button>
            </div>
            <div class="modal-body">
                <form class="form form-vertical" id="executive-members-form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="member-id" name="id" />
                    <div class="form-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="job_title">Role</label>
                                    <div class="position-relative has-icon-left">
                                        <select id="role" class="form-control select2" name="role" data-placeholder="Select role">
                                            <option value="">--Select--</option>
                                            <?php if(isset($roles[0])): ?>
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <div class="form-control-position">
                                            <i class="bx bxs-label"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="job_title">Name</label>
                                    <div class="position-relative has-icon-left">
                                        <input type="text" id="name" class="form-control" name="name" placeholder="Enter Name" required>
                                        <div class="form-control-position">
                                            <i class="bx bxs-label"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="job_title">Phone</label>
                                    <div class="position-relative has-icon-left">
                                        <input type="text" id="phone" class="form-control" name="phone" placeholder="Enter phone" required>
                                        <div class="form-control-position">
                                            <i class="bx bxs-label"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="job_title">Company</label>
                                    <div class="position-relative has-icon-left">
                                        <input type="text" id="company" class="form-control" name="company" placeholder="Enter company" required>
                                        <div class="form-control-position">
                                            <i class="bx bxs-label"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="job_title">Photo</label>
                                    <input type="hidden" name="old_photo" id="old_photo">
                                    <div class="position-relative has-icon-left">
                                        <input type="file" id="photo" class="form-control" name="photo" required>
                                        <div class="form-control-position">
                                            <i class="bx bxs-label"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-secondary close-btn" data-dismiss="modal">
                    <i class="bx bx-x d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Close</span>
                </button>
                <button type="button" class="btn btn-primary ml-1 submit-members-btn">
                    <i class="bx bx-check d-block d-sm-none"></i>
                    <span class="d-none d-sm-block">Save</span>
                </button>
            </div>
        </div>
    </div>
</div>



<script>
    $(document).ready(function() {


        $(document).on('click', '#executiveMemberModal .close-btn', function() {

            resetAlbumAddFrom();
        });
        
        $(document).on('click', '.member-edit-btn', function() {
            var id = $(this).data('id');
            var name = $(this).data('name');
            var role = $(this).data('role');
            var phone = $(this).data('phone');
            var company = $(this).data('company');
            var photo = $(this).data('photo');
            $("#member-id").val(id);
            $("#name").val(name);
            $("#role").val(role).trigger('change');
            $("#phone").val(phone);
            $("#company").val(company);
            $("#old_photo").val(photo);
        });

        $(document).on('click', '.submit-members-btn', function() {

            var that = this;
            var title = $('#name').val();
            var phone = $('#phone').val();
            var company = $('#company').val();
            var photo = $('#photo').val();
            var old_photo = $('#old_photo').val();

            //validation
            var error = 0;
            if (title == "" || title == undefined || title == null) {
                Toast.fire({
                    icon: 'error',
                    title: 'Please Enter Title.'
                });
                error += 1;
                return false;
            }
            else if (phone == "" || phone == undefined || phone == null) {
                Toast.fire({
                    icon: 'error',
                    title: 'Please Enter phone.'
                });
                error += 1;
                return false;
            }
            else if (company == "" || company == undefined || company == null) {
                Toast.fire({
                    icon: 'error',
                    title: 'Please Enter company.'
                });
                error += 1;
                return false;
            }
            else if (old_photo == '' && (photo == "" || photo == undefined || photo == null)) {
                Toast.fire({
                    icon: 'error',
                    title: 'Please upload photo.'
                });
                error += 1;
                return false;
            }
            else if (error == 0) {

                var myform = document.getElementById("executive-members-form");
                var formData = new FormData(myform);

                formData.append('_token', '<?php echo e(csrf_token()); ?>');
                $(this).html('Saving...').attr('disabled', true);
                $.ajax({
                    type: "post",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    url: "<?php echo e(route('admin.executive.member.submit')); ?>",
                    success: function(result) {
                        $(that).html('Save').attr('disabled', false);

                        if (result.error == true) {
                            Toast.fire({
                                icon: 'error',
                                title: result.message
                            });
                        } else {
                            Toast.fire({
                                icon: 'success',
                                title: result.message
                            });
                            $('#executiveMemberModal').modal('toggle');
                            resetAlbumAddFrom();
                        }
                        $('#roleTable').DataTable().ajax.reload();
                    }
                });
            }

        });



    }); // Main script closing tag.
</script><?php /**PATH C:\xampp\htdocs\csra-main\resources\views/admin/modal/executiveMemberModal.blade.php ENDPATH**/ ?>