<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row"></div>
        <div class="content-body">
            <section class="users-list-wrapper">
                <div class="users-list-table mt-2">
                    <div class="card">
                        <div class="card-body">
                            <!-- datatable start -->
                            <div class="table-responsive">
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#roleModal" style="float: right;">Add</button>
                                <table id="RolesTable" class="table table-striped" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                                <!-- datatable ends -->
                            </div>
                            <!-- datatable ends -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- users list ends -->
        </div>
    </div>
</div>
<div class="buy-now" style="right: 60px;"><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#vacancyAddModal">+</button></div>
<div class="sidenav-overlay"></div>
<div class="drag-target"></div>
<!-- Earning Swiper Starts -->


<?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.modal.roleModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(function() {

        var RolesTable = $('#RolesTable');

        load_data();

        function load_data() {
            RolesTable.DataTable({

                // dom: '<"html5buttons"B>lTfgitp',
                // buttons: [
                //     { extend: 'copy'},
                //     {extend: 'csv'},
                //     {extend: 'excel', title: 'ExampleFile'},
                //     {extend: 'pdf', title: 'ExampleFile'},

                //     {extend: 'print',
                //      customize: function (win){
                //             $(win.document.body).addClass('white-bg');
                //             $(win.document.body).css('font-size', '10px');

                //             $(win.document.body).find('table')
                //                     .addClass('compact')
                //                     .css('font-size', 'inherit');
                //     }
                //     }
                // ],
                responsive: true,
                serverSide: true,
                processing: true,
                ordering: false,
                ajax: {
                    url: "<?php echo e(route('admin.roles.datatable')); ?>",
                    // data:{'date': date,'type': type,'label': label, 'daterange': daterange}, 
                },
                "aoColumns": [
                    {
                        mData: 'id'
                    },
                    {
                        mData: 'name'
                    },
                    {
                        mData: 'actions'
                    },

                ],
                "columnDefs": [{
                    targets: -1,
                    className: 'text-right'
                }],
            });
        }

        $(document).on('click', '.status-btn', function() {
            var id = $(this).attr('data-value');
            var status = $(this).attr('name');
            if (status == 'delete') {

                Swal.fire({
                    title: 'You wont be able to retrive this!',
                    showDenyButton: true,
                    confirmButtonText: `Ok, Delete it.`,
                    denyButtonText: `No, Cancel it.`,
                }).then((result) => {
                    if (result.isConfirmed) {
                        statusChange(id, status);
                    }
                })
            } else {
                statusChange(id, status);
            }
        });

        function statusChange(id, status) {
            $.ajax({
                type: "post",
                url: "<?php echo e(route('admin.delete.vacancy')); ?>",
                data: {
                    'id': id,
                    'status': status,
                    '_token': '<?php echo e(csrf_token()); ?>'
                },
                success: function(result) {
                    if (result.error == true) {
                        Toast.fire({
                            icon: 'error',
                            title: result.message
                        })
                    } else {
                        Toast.fire({
                            icon: 'success',
                            title: result.message
                        })
                    }
                    VacancyTable.DataTable().ajax.reload();
                }
            });
        }


    });
</script>
</body>
<!-- END: Body-->

</html><?php /**PATH C:\xampp\htdocs\csra-main\resources\views/admin/roles.blade.php ENDPATH**/ ?>