-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table csra.contact_us
DROP TABLE IF EXISTS `contact_us`;
CREATE TABLE IF NOT EXISTS `contact_us` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_general_ci,
  `status` enum('Active','Inactive') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` enum('Yes','No') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.contact_us: ~15 rows (approximately)
INSERT INTO `contact_us` (`id`, `name`, `subject`, `message`, `status`, `created_at`, `updated_at`, `is_active`) VALUES
	(1, 'ashcv', NULL, 'jasbhv', 'Active', '2023-04-04 12:02:04', '2023-04-04 12:02:04', 'Yes'),
	(2, 'sahcbyas', NULL, 'sauhdyg', 'Active', '2023-04-04 12:06:19', '2023-04-04 12:06:19', 'Yes'),
	(3, 'asc', NULL, 'skdbh', 'Active', '2023-04-04 12:06:39', '2023-04-04 12:06:39', 'Yes'),
	(4, 'sajgh', NULL, 'shba', 'Active', '2023-04-05 11:56:55', '2023-04-06 10:01:37', 'Yes'),
	(5, 'hsgv', NULL, 'ygujub', 'Active', '2023-04-06 10:36:19', '2023-04-06 10:36:19', 'Yes'),
	(6, 'dsav', NULL, 'asfc', 'Active', '2023-04-06 10:45:41', '2023-04-06 10:45:41', 'Yes'),
	(7, 'asfc', NULL, 'ADXDAS', 'Active', '2023-04-06 11:09:43', '2023-04-06 11:09:43', 'Yes'),
	(8, 'asfc', NULL, 'ADXDAS', 'Active', '2023-04-06 11:09:43', '2023-04-06 11:09:43', 'Yes'),
	(9, 'fe', NULL, 'egfg', 'Active', '2023-04-06 11:11:12', '2023-04-06 11:11:12', 'Yes'),
	(10, 'SAD', NULL, 'FES', 'Active', '2023-04-06 11:13:06', '2023-04-10 12:26:12', 'Yes'),
	(11, 'abcd', NULL, 'hello', 'Active', '2023-04-12 06:41:15', '2023-04-12 06:41:15', 'Yes'),
	(12, 'aaa', 'aaa', 'aa', 'Active', '2023-08-14 20:01:02', '2023-08-14 20:01:02', 'Yes'),
	(13, 'aaa', 'aaa', 'aaa', 'Active', '2023-08-14 20:02:30', '2023-08-14 20:02:30', 'Yes'),
	(14, 'sadfas', 'dsfas', 'sadfas', 'Active', '2023-12-17 21:40:56', '2023-12-17 21:40:56', 'Yes'),
	(15, 'suraj pandey', 'testing', 'test message', 'Active', '2023-12-20 05:15:37', '2023-12-20 05:15:37', 'Yes');

-- Dumping structure for table csra.customers
DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('User') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'User' COMMENT 'User',
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active' COMMENT 'Active',
  `is_active` enum('Yes','No') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `all_users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.customers: ~0 rows (approximately)

-- Dumping structure for table csra.executive_member
DROP TABLE IF EXISTS `executive_member`;
CREATE TABLE IF NOT EXISTS `executive_member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `company` varchar(190) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.executive_member: ~9 rows (approximately)
INSERT INTO `executive_member` (`id`, `role`, `name`, `phone`, `company`, `created_at`, `updated_at`) VALUES
	(1, 1, 'Mr. Sanjay Tripathi', '9826136033', 'M/s Shivam Structural & Steel', '2023-12-19 18:17:43', '2023-12-20 09:02:53'),
	(2, 2, 'Mr. Banke Bihari Agrawal', '7746877701', 'M/s Lakshi Ispat Pvt. Ltd.', '2023-12-20 09:03:56', '2023-12-20 09:03:56'),
	(3, 3, 'Mr. Om Prakash Agrawal', '9755500444', 'M/s Sindh Ispat', '2023-12-20 09:04:44', '2023-12-20 09:04:44'),
	(4, 4, 'Mr. Manoj Kumar Agrawal', '9827136060', 'M/s Mahendra Spounge & Power', '2023-12-20 09:05:32', '2023-12-20 09:05:32'),
	(5, 5, 'Mr. Anand Choudhry Je', '9893555851', 'M/s Drolia Electrosteel Pvt. Ltd.', '2023-12-20 09:06:41', '2023-12-20 09:06:41'),
	(6, 5, 'Vinod Agrawal', '9425206401', 'M/s Krishna Iron Strips & Tubes', '2023-12-20 09:07:35', '2023-12-20 09:07:35'),
	(7, 5, 'Mr. Ajay Gupta', '9826143025', 'M/s Adarsh Ispat Udyog Pvt. Ltd.', '2023-12-20 09:08:59', '2023-12-20 09:08:59'),
	(8, 6, 'Mr. Rajkumar Agrawal', '9826726004', 'M/s alankar Steels Pvt. Ltd.', '2023-12-20 09:09:48', '2023-12-20 09:09:48'),
	(9, 6, 'Mr. Ashish Jindal', '9179050000', 'M/s Ajay Ingot Rolling Mill Pvt. Ltd.', '2023-12-20 09:10:45', '2023-12-20 09:10:45');

-- Dumping structure for table csra.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table csra.join_our_team
DROP TABLE IF EXISTS `join_our_team`;
CREATE TABLE IF NOT EXISTS `join_our_team` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `phone` varchar(13) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `resume` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` enum('Yes','No') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Yes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.join_our_team: ~4 rows (approximately)
INSERT INTO `join_our_team` (`id`, `name`, `email`, `phone`, `message`, `resume`, `status`, `created_at`, `updated_at`, `is_active`) VALUES
	(1, 'hvjh', 'hgvhg@gmail.com', '1234567890', 'developer', '1', 'Active', '2023-04-05 09:45:04', '2023-04-06 09:49:31', 'Yes'),
	(2, 'kjsabdkj', 'jhvsab@gmail.com', '1234567890', 'developer', NULL, 'Active', '2023-04-05 09:48:09', '2023-08-15 05:32:08', 'Yes'),
	(3, 'aaa', NULL, NULL, 'aaa', '1692044526.pdf', 'Active', '2023-08-14 20:22:06', '2023-08-14 20:22:06', 'Yes'),
	(4, 'aa', NULL, NULL, 'aaa', '1692044588.pdf', 'Active', '2023-08-14 20:23:08', '2023-08-14 20:23:08', 'Yes');

-- Dumping structure for table csra.members
DROP TABLE IF EXISTS `members`;
CREATE TABLE IF NOT EXISTS `members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `name_of_unit` varchar(190) COLLATE utf8mb4_general_ci NOT NULL,
  `partner` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.members: ~2 rows (approximately)
INSERT INTO `members` (`id`, `name`, `name_of_unit`, `partner`, `mobile`, `phone`, `address`, `created_at`, `updated_at`) VALUES
	(1, 'M.S. TMT Bar', '4', 'Mr. Dheeraj Surana', '9893190000', '0771-2326063, 232629 (Fax)', 'A.C. Shilps 1dsjhdshs', '2023-12-19 18:43:39', '2023-12-20 05:58:43'),
	(2, 'asdfas', '2', 'asdfsa', 'sadfda', 'safas', 'asdfas', '2023-12-20 05:53:37', '2023-12-20 05:58:52');

-- Dumping structure for table csra.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.migrations: ~28 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
	(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
	(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
	(6, '2016_06_01_000004_create_oauth_clients_table', 1),
	(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
	(8, '2019_08_19_000000_create_failed_jobs_table', 1),
	(9, '2021_01_06_052525_create_table_deals', 1),
	(10, '2021_01_06_052603_create_table_labels', 1),
	(11, '2021_01_06_052649_create_table_customers', 1),
	(12, '2021_01_06_054121_create_table_service_master', 1),
	(13, '2021_01_06_054151_create_table_extra_service_master', 1),
	(14, '2021_01_06_054331_create_table_service_packages_master', 1),
	(15, '2021_01_06_054410_create_table_service_billing_packages', 1),
	(16, '2021_01_06_054456_create_table_cor_service_master', 1),
	(17, '2021_01_06_054530_create_table_cor_billing_packages', 1),
	(18, '2021_01_06_054652_create_table_proposal', 1),
	(19, '2021_01_06_054716_create_table_proposal_services', 1),
	(20, '2021_01_06_054749_create_table_proposal_extra_services', 1),
	(21, '2021_01_06_054842_create_table_proposal_service_pakages', 1),
	(22, '2021_01_06_054909_create_table_proposal_billing_pakages', 1),
	(23, '2021_01_06_054948_create_table_proposal_cor_services', 1),
	(24, '2021_01_06_055051_create_table_proposal_cor_billing_packages', 1),
	(25, '2021_01_06_055229_create_table_billings', 1),
	(26, '2021_01_06_055308_create_table_billings_billing_packages', 1),
	(27, '2021_01_06_055353_create_table_billings_cor_billing_packages', 1),
	(28, '2023_04_04_103333_create_all_users_table', 2);

-- Dumping structure for table csra.oauth_access_tokens
DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.oauth_access_tokens: ~0 rows (approximately)

-- Dumping structure for table csra.oauth_auth_codes
DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.oauth_auth_codes: ~0 rows (approximately)

-- Dumping structure for table csra.oauth_clients
DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.oauth_clients: ~0 rows (approximately)

-- Dumping structure for table csra.oauth_personal_access_clients
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.oauth_personal_access_clients: ~0 rows (approximately)

-- Dumping structure for table csra.oauth_refresh_tokens
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.oauth_refresh_tokens: ~0 rows (approximately)

-- Dumping structure for table csra.packages
DROP TABLE IF EXISTS `packages`;
CREATE TABLE IF NOT EXISTS `packages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `place` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `days` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `discount_price` decimal(10,0) NOT NULL,
  `thumbnail_image` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `sdescription` text COLLATE utf8mb4_general_ci NOT NULL,
  `ldescription` text COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.packages: ~4 rows (approximately)
INSERT INTO `packages` (`id`, `title`, `place`, `days`, `price`, `discount_price`, `thumbnail_image`, `image`, `sdescription`, `ldescription`, `status`, `created_at`, `updated_at`) VALUES
	(12, 'A Journey of Togetherness', 'Gulmarg,Pahalgam,Srinagar', '2,3,3', 50000, 55000, '065300_THUMBNAIL.png', '230414065300_IMAGES.png,230414065300_IMAGES.jpg,230414065300_IMAGES.jpg', 'Dal is a lake in Srinagar, the summer capital of Jammu and Kashmir. It is an urban lake, the second largest lake in Jammu and Kashmir, and the most visited place in Srinagar by tourists and locals.', '<p><span style="color: rgb(77, 81, 86); font-family: arial, sans-serif; letter-spacing: normal; text-align: justify;">Dal is a lake in Srinagar, the summer capital of Jammu and Kashmir. It is an urban lake, the second largest lake in Jammu and Kashmir, and the most visited place in Srinagar by tourists and locals.</span><br></p>', 'Active', '2023-04-12 11:24:43', '2023-04-14 13:23:01'),
	(13, 'Premium Packages', 'Srinagar,Pahalgam,Kashmir', '2,3,4', 45000, 44000, '2304_THUMBNAIL.jpg', '230412050256_IMAGES.png,230412050256_IMAGES.png,230412050256_IMAGES.jpg', 'Dal is a lake in Srinagar, the summer capital of Jammu and Kashmir. It is an urban lake, the second largest lake in Jammu and Kashmir, and the most visited place in Srinagar by tourists and locals.', '<p><span style="color: rgb(77, 81, 86); font-family: arial, sans-serif; letter-spacing: normal; text-align: justify;">Dal is a lake in Srinagar, the summer capital of Jammu and Kashmir. It is an urban lake, the second largest lake in Jammu and Kashmir, and the most visited place in Srinagar by tourists and locals.</span><br></p>', 'Active', '2023-04-12 11:26:22', '2023-04-12 11:32:57'),
	(14, 'A Romantic Getaway', 'Srinagar,Pahalgam,Gulmarg,Aru valley', '2,1,3,', 60000, 59000, '065232_THUMBNAIL.png', '230414065232_IMAGES.png,230414065232_IMAGES.png,230414065232_IMAGES.png', 'A perfect start to a perfect marriage. Stay Pattern offers the optimum memorable Honeymoon Package that starts with choosing an exciting', '<p><span style="color: rgb(91, 104, 128); font-family: Poppins, Helvetica, Arial, sans-serif; font-size: 15px; letter-spacing: normal;">A perfect start to a perfect marriage. Stay Pattern offers the optimum memorable Honeymoon Package that starts with choosing an exciting</span><br></p>', 'Active', '2023-04-12 11:29:07', '2023-04-14 13:22:32'),
	(15, 'Romantic Escapade', 'Srinagar,Aru Valley,Pahalgam,Gulmarg', '2,4,2,1', 60000, 59000, '2304_THUMBNAIL.png', '230412050113_IMAGES.png,230412050113_IMAGES.jpg,230412050113_IMAGES.jpg,230412050113_IMAGES.png', 'Dal is a lake in Srinagar, the summer capital of Jammu and Kashmir. It is an urban lake, the second largest lake in Jammu and Kashmir, and the most visited place in Srinagar by tourists and locals.', '<p><span style="color: rgb(77, 81, 86); font-family: arial, sans-serif; letter-spacing: normal; text-align: justify;">Dal is a lake in Srinagar, the summer capital of Jammu and Kashmir. It is an urban lake, the second largest lake in Jammu and Kashmir, and the most visited place in Srinagar by tourists and locals.</span><br></p>', 'Active', '2023-04-12 11:31:13', '2023-04-12 11:31:13');

-- Dumping structure for table csra.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.password_resets: ~0 rows (approximately)

-- Dumping structure for table csra.roles
DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.roles: ~9 rows (approximately)
INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'President', '2023-12-19 17:06:23', '2023-12-20 08:59:43'),
	(2, 'Gr. Secratory', '2023-12-20 09:00:00', '2023-12-20 09:00:00'),
	(3, 'Treasurer', '2023-12-20 09:00:25', '2023-12-20 09:00:25'),
	(4, 'IPP', '2023-12-20 09:00:37', '2023-12-20 09:00:37'),
	(5, 'Vice President', '2023-12-20 09:00:50', '2023-12-20 09:00:50'),
	(6, 'Joint Secratory', '2023-12-20 09:00:59', '2023-12-20 09:00:59'),
	(7, 'Ex. Member', '2023-12-20 09:01:13', '2023-12-20 09:01:13'),
	(8, 'Permanent Invite', '2023-12-20 09:01:30', '2023-12-20 09:01:30'),
	(9, 'Sanrakchhak Mandal', '2023-12-20 09:01:48', '2023-12-20 09:01:48');

-- Dumping structure for table csra.units
DROP TABLE IF EXISTS `units`;
CREATE TABLE IF NOT EXISTS `units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.units: ~6 rows (approximately)
INSERT INTO `units` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'A.C. Strips (P) Ltd.', '2023-12-19 17:06:23', '2023-12-20 09:22:32'),
	(2, 'A.S. Ispat Udyog', '2023-12-20 05:43:52', '2023-12-20 09:22:53'),
	(3, 'A.C. Steels', '2023-12-20 05:45:12', '2023-12-20 09:23:02'),
	(4, 'Aditya Steels', '2023-12-20 05:45:51', '2023-12-20 09:23:11'),
	(5, 'Abhilasha Ispat Udyog', '2023-12-20 05:46:12', '2023-12-20 09:23:28'),
	(6, 'Agrawal Channels Mills Pvt. Ltd.', '2023-12-20 05:46:54', '2023-12-20 09:23:44');

-- Dumping structure for table csra.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` tinyint NOT NULL DEFAULT '1' COMMENT '1 = User',
  `is_active` enum('Yes','No') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table csra.users: ~0 rows (approximately)
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `role`, `is_active`, `created_at`, `updated_at`) VALUES
	(1, 'Admin', 'admin@gmail.com', '2021-08-12 06:48:06', '$2y$10$7Dtr41XLmb/Ov9TaT4Y2IOWtrH2KtirouVaPpvYfEBnUEDS85cPc.', 'BhIGTBvYD7TkOTnlB7vkWFfO9l5iH5yzEsO4NUl26tDVtLCAbfhruzGOkrjP', 1, 'Yes', '2021-01-09 05:34:34', NULL);

-- Dumping structure for table csra.vacancies
DROP TABLE IF EXISTS `vacancies`;
CREATE TABLE IF NOT EXISTS `vacancies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_title` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `qualification` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `experience` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_location` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_type` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('Active','Inactive') COLLATE utf8mb4_general_ci DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table csra.vacancies: ~3 rows (approximately)
INSERT INTO `vacancies` (`id`, `job_title`, `qualification`, `experience`, `job_location`, `job_type`, `status`, `created_at`, `updated_at`) VALUES
	(2, 'aaa', 'aaa', 'aaaa', 'aaa', 'aaaa', 'Active', '2023-08-15 06:00:53', '2023-08-15 06:00:53'),
	(3, 'aaa', 'aaa', 'aaaa', 'aaa', 'aaaa', 'Active', '2023-08-15 06:00:53', '2023-08-15 06:00:53'),
	(4, 'test', 'test', '5', 'raipur', 'tester', 'Active', '2023-08-16 07:46:33', '2023-08-16 07:46:33');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
