<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableDeals extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deals', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->integer('cutomer_id');
            $table->double('value', 15,2)->nullable();
            $table->string('label', 50);
            $table->string('type', 50);
            $table->mediumText('remarks')->nullable();
            $table->integer('handle_by');
            $table->date('follow_up_date');
            $table->date('wedding_date')->nullable();
            $table->date('vanue')->nullable();
            $table->enum('wedding_side', ['Groom', 'Bride', 'Both'])->nullable();
            $table->enum('status', ['Won', 'Lost'])->nullable();
            $table->enum('is_active', ['Yes', 'No'])->default('Yes');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deals');
    }
}
