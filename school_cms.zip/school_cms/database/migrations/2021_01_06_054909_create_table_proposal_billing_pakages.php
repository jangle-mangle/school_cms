<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableProposalBillingPakages extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('proposal_billing_packages', function (Blueprint $table) {
            $table->id();
            $table->integer('proposal_id');
            $table->string('name');
            $table->string('hsn')->nullable();
            $table->double('price', 15,2);
            $table->integer('quantity');
            $table->enum('is_active', ['Yes', 'No'])->default('Yes');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('proposal_billing_packages');
    }
}
