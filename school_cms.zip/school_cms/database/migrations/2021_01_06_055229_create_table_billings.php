<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableBillings extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('billings', function (Blueprint $table) {
            $table->id();
            $table->integer('deals_id');
            $table->integer('proposal_id');
            $table->double('price', 15,2)->default(0.00);
            $table->double('total', 15,2)->default(0.00);
            $table->string('gst');
            $table->double('recived_amount', 15,2)->default(0.00);
            $table->double('grand_total', 15,2)->default(0.00);
            $table->enum('is_active', ['Yes', 'No'])->default('Yes');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('billings');
    }
}
