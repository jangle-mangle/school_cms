<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableCustomers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['temp', 'saved'])->default('temp');
            $table->string('name');
            $table->string('organization')->nullable();
            $table->string('phone_no', 191)->nullable();
            $table->string('email', 191);
            $table->mediumText('address')->nullable();
            $table->mediumText('remarks')->nullable();
            $table->string('gst_number')->nullable();
            $table->enum('is_active', ['Yes', 'No'])->default('Yes');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
