<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LablesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$labels = ['New Lead', 'Contact Made', 'Proposal Sent', 'Awaited', 'Converted', 'Lost'];
    	$position = 1;
    	for ($i=0; $i < count($labels); $i++) { 
    		
    		DB::table('labels')->insert(
			    [
			    	'name' => $labels[$i], 
			    	'position' => $position,
			    	'created_at' => date('Y-m-d H:i:s'),
			    ]
			);
    		$position++;
    	}
        
    }
}
