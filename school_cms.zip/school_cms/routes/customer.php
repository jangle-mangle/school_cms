<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\CommonController;
use App\Http\Controllers\User\UserController;
use App\Http\Controllers\User\ContactUsController;
use App\Http\Controllers\User\LetestUpdateController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route::get('/requirment', [CommonController::class, 'Requirment'])->name('requirment');
// Route::post('/req_add/add', [CommonController::class, 'req_add']);

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('config:cache');
    return 'DONE'; //Return anything
});

Route::get('/linkstorage', function () {
    Artisan::call('storage:link');
    return 'DONE'; //Return anything
});

// Route::get('/', function () {
//     return view('user.index');
// })->name('customer.index');

// Route::get('/', [UserController::class, 'index'])->name('customer.index');



Auth::routes(); 

// Route::group(['prefix' => 'customer'], function (){
    Route::group(['middleware' => 'customer.guest:customer'], function(){
     Route::get('/', [UserController::class, 'index'])->name('customer.index');
     Route::get('/about', [UserController::class, 'about'])->name('customer.about');
     Route::get('/executive-member', [UserController::class, 'executive_member'])->name('executive.member');
     Route::get('/aditya_steel', [UserController::class, 'aditya_steel'])->name('aditya.steel');
     Route::get('/member', [UserController::class, 'member'])->name('member');
     Route::get('/contact', [UserController::class, 'contact'])->name('customer.contact');
     Route::get('/activities', [UserController::class, 'activities'])->name('customer.activities');


     Route::post('/contact-us-post', [UserController::class, 'contact_us'])->name('user.contact_us.form');
     Route::get('/empowerment-form', [UserController::class, 'empowerment_form']);
    });

    Route::group(['middleware' => 'customer.auth'], function (){

        Route::get('/home', [HomeController::class, 'index'])->name('customer.home');
      

    });

// });




