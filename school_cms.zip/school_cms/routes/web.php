<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\CommonController;
use App\Http\Controllers\User\UserController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\VacancyController;
use App\Http\Controllers\JoinOurTeamController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\ExecutiveMemberController;
use App\Http\Controllers\MemberController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// ====================START USER SITE=========================  
Route::get('/', [UserController::class, 'index']);
// Route::get('/about', [UserController::class, 'about'])->name('user.about');
Route::get('/contact', [UserController::class, 'contact'])->name('user.contact');
Route::get('/csr', [UserController::class, 'csr'])->name('user.csr');
Route::get('/nr-ispat', [UserController::class, 'nr_ispat'])->name('user.nr_ispat');
Route::get('/nr-steel-ferro', [UserController::class, 'nr_steel_ferro'])->name('user.nr_steel_ferro');
Route::get('/nr-tmt', [UserController::class, 'nr_tmt'])->name('user.nr_tmt');
Route::get('/nrvs', [UserController::class, 'nrvs'])->name('user.nrvs');
Route::get('/tmt-bars', [UserController::class, 'tmt_bars'])->name('user.tmt_bars');
Route::get('/ms-billets', [UserController::class, 'ms_billets'])->name('user.ms_billets');
Route::get('/sponge-iron', [UserController::class, 'sponge_iron'])->name('user.sponge_iron');
Route::get('/ms-wire-rod', [UserController::class, 'ms_wire_rod'])->name('user.ms_wire_rod');
Route::get('/silico-maganese', [UserController::class, 'silico_maganese'])->name('user.silico_maganese');
Route::get('/pig-iron', [UserController::class, 'pig_iron'])->name('user.pig_iron');
Route::get('/fly-ash-brick', [UserController::class, 'fly_ash_brick'])->name('user.fly_ash_brick');
Route::get('/update', [UserController::class, 'update'])->name('user.update');
Route::post('/contact_us', [UserController::class, 'contact_us'])->name('user.contact_us.form');
Route::post('/join-our-team', [UserController::class, 'join_our_team'])->name('user.join_our_team.form');

// ====================END USER SITE=========================  

// Route::get('/requirment', [CommonController::class, 'Requirment'])->name('requirment');
// Route::post('/req_add/add', [CommonController::class, 'req_add']);

Route::get('/admin', function () {
    return view('admin.login');
})->name('admin.login');

Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('config:cache');
    return 'DONE'; //Return anything
});


Route::get('/linkstorage', function () {
    Artisan::call('storage:link');
    return 'DONE'; //Return anything
});
Auth::routes();
Route::group(['prefix' => 'admin'], function (){

Route::get('/home', [HomeController::class, 'index'])->name('admin.home');
Route::post('/request/update', [CommonController::class, 'update']);




    // <---------------------- Contact Us Section --------------------------------------->

Route::get('/contact-us', [ContactUsController::class, 'index'])->name('admin.contact.us');
Route::get('/contact-datatable', [ContactUsController::class, 'data'])->name('admin.contact_us.datatable');

    // <---------------------- Vacancy Section --------------------------------------->

Route::get('/vacancy', [VacancyController::class, 'index'])->name('admin.vacancy');
Route::post('/vacancy/add', [VacancyController::class, 'add'])->name('admin.add.vacancy');
Route::get('/vacancy/datatable', [VacancyController::class, 'data'])->name('admin.vacancy.datatable');
Route::post('/vacancy/delete', [VacancyController::class, 'delete'])->name('admin.delete.vacancy');
Route::get('/vacancy/view/{id}', [VacancyController::class, 'editView'])->name('admin.vacancy.editView');
Route::post('/vacancy/edit', [VacancyController::class, 'edit'])->name('admin.edit.vacancy');


// <---------------------- join our team Section --------------------------------------->

Route::get('/join-our-team', [JoinOurTeamController::class, 'index'])->name('admin.join_our_team');
Route::get('/join_our_team/datatable', [JoinOurTeamController::class, 'data'])->name('admin.join_our_team.datatable');

// <---------------------- Roles Section --------------------------------------->
Route::get('/roles', [RoleController::class, 'index'])->name('admin.role');
Route::get('/roles_datatable', [RoleController::class, 'data'])->name('admin.roles.datatable');
Route::post('/add-roles', [RoleController::class, 'add'])->name('admin.add.role');

// <---------------------- Executive Members Section --------------------------------------->
Route::get('/executive-members', [ExecutiveMemberController::class, 'index'])->name('admin.executive.member.index');
Route::get('/executive-members-datatable', [ExecutiveMemberController::class, 'data'])->name('admin.executive.member.datatable');
Route::post('/submit-executive-members', [ExecutiveMemberController::class, 'submit'])->name('admin.executive.member.submit');

// <---------------------- Members Section --------------------------------------->
Route::get('/members', [MemberController::class, 'index'])->name('admin.member.index');
Route::get('/members-datatable', [MemberController::class, 'data'])->name('admin.member.datatable');
Route::get('/fetch-member', [MemberController::class, 'fetch'])->name('admin.member.fetch');
Route::post('/submit-members', [MemberController::class, 'submit'])->name('admin.member.submit');

// Unit section 
Route::get('/unit', [UnitController::class, 'index'])->name('admin.unit');
Route::get('/unit_datatable', [UnitController::class, 'data'])->name('admin.units.datatable');
Route::post('/add-unit', [UnitController::class, 'add'])->name('admin.add.unit');


Route::get('/admin-page-banner', [HomeController::class, 'banner_page'])->name('admin.page.banner');
Route::post('/admin-add-banner', [HomeController::class, 'add_banner'])->name('admin.add.banner');
Route::get('/admin-delete-banner/{id}', [HomeController::class, 'delete_banner'])->name('admin.delete.banner');


Route::get('/admin-page-event', [HomeController::class, 'event_page'])->name('admin.page.event');
Route::post('/admin-add-event', [HomeController::class, 'add_event'])->name('admin.add.event');
Route::get('/admin-delete-event/{id}', [HomeController::class, 'delete_event'])->name('admin.delete.event');
});


