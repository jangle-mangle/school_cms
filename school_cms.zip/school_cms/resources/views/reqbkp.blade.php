<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>The Wedding Solution - Dashboard</title>
  <!-- General CSS Files -->
   
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_app.min.css') }}">
  <!-- Template CSS -->
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_style.css') }}">
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_components.css') }}">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_custom.css') }}">
  <link rel='shortcut icon' type='image/x-icon' href="{{ asset('public/app-assets/img/favicon.ico') }}" />
  <style>
    .wizard>.steps {
    position: sticky;
    display: block;
    width: 100%;
    overflow: auto;
}
.wizard>.steps>ul>li {
    width: 25%;
    
    width: 260px !important;
}
.wizard ul, .tabcontrol ul{
  width: 2345px;
    display: flex;
    overflow: scroll;
    overflow: auto;
}
.wizard>.steps  a {
    background: #eee;
    color: #aaa;
    cursor: default;
}
.form-label{
  color:black;
  font-weight: bold;
}
.form-float{
   color:black;
  font-weight: bold;

}

    </style>
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1 ">
      <div class="navbar-bg"></div>
      <!-- <nav class="navbar navbar-expand-lg main-navbar sticky"> -->
       <!--  <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
                                    collapse-btn"> <i data-feather="menu"></i></a></li>
            <li>
              <form class="form-inline mr-auto">
                <div class="search-element">
                  <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="200">
                  <button class="btn" type="submit">
                    <i class="fas fa-search"></i>
                  </button>
                </div>
              </form>
            </li>
          </ul>
        </div> -->
       
      <!-- </nav> -->
      
      <!-- Main Content -->
      <div class="main-content" style="padding-right: 4px;
    padding-left: 4px;">
        <section class="section">
        
          <div class="section-body">
            
           <div class="row clearfix">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                  <div class="card-header">
                    <h4>The Wedding solutions</h4>
                  </div>
                  <div class="card-body">
                    <form id="wizard_with_validation" method="POST">
                      @csrf
                      <h3>Basic Information</h3>
                      <fieldset>

                        <div class="row">
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                              <div class="form-line">
                                <label class="form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" >
                              </div>
                            </div>
                             <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                                  <div class="form-line">
                                    <label class="form-label">Date Of Wedding</label>
                                    <input type="date" class="form-control" id="date" name="date" >
                                  </div>
                                </div>
                                 <hr class="d-block d-sm-none" style="border-top: 1px solid black;" >
                           </div>
                       </div>

                          <div class="row">
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                              <div class="form-line">
                                <label class="form-label">Contact Number <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="mobile" id="mobile" >
                              </div>
                            </div>
                             <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                                  <div class="form-line">
                                    <label class="form-label">Venue  </label>
                                    <input type="email" class="form-control" id="venue " name="venue " >
                                  </div>
                                </div>
                                 <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-12">
                                 <div class="form-group form-float">
                              <div class="form-line">
                                  <label class="form-label">User Email </label>
                                    <input type="email" class="form-control" id="username" name="username" >
                              </div>
                            </div>
                             <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                        
                       </div>
                       
                       
                       
                        
                      </fieldset>

                      <h3>Decoration Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Mehandi Setup</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="mehandi_setup" name="mehandi_setup" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="mehandi_setup" name="mehandi_setup" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>

                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="mehandi_setup_detail" id="mehandi_setup_detail" >
                                      </div>
                                    </div>
                                    <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Haldi Mandap</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="hadli_setup" name="hadli_setup" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="hadli_setup" name="hadli_setup" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="hadli_setup_detail" id="hadli_setup_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Sangeet Stage</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="sangeet_stage" name="sangeet_stage" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="sangeet_stage" name="sangeet_stage" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="sangeet_stage_detail" id="sangeet_stage_detail">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                            
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Reception Stage</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="reception_stage" name="reception_stage" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="reception_stage" name="reception_stage" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="reception_stage_detail" id="reception_stage_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                              

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Sheeting Arrange</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="seet_arrange" name="seet_arrange" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="seet_arrange" name="seet_arrange" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_seet_arrange" id="detail_seet_arrange">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                          
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Light and Sound</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="light_sound" name="light_sound" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="light_sound" name="light_sound" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_light_sound" id="detail_light_sound">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                         
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Pandit</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="pandit" name="pandit" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="pandit" name="pandit" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_pandit" id="detail_pandit">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                      

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Havan Kund</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="havan" name="havan" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="havan" name="havan" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_havan" id="detail_havan" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                         
                              <div class="col-md-4">
                               
                              </div>
                           </div>

                            

                        
                       
                      </fieldset>

                      <h3>Mehandi Detail</h3>
                     <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Bridal Mehandi Artist</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="bridal_mehandi" name="bridal_mehandi" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="bridal_mehandi" name="bridal_mehandi" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_bridal_mehandi" id="detail_bridal_mehandi">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                     

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Mehandi Artist</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="mehandi_artist" name="mehandi_artist" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="mehandi_artist" name="mehandi_artist" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details Number of People</label>
                                        <input type="text" class="form-control" name="detail_mehandi_artist" id="detail_mehandi_artist">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                       
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Nail and Tattoo Artist</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="nail_tattoo" name="nail_tattoo" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="nail_tattoo" name="nail_tattoo" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_nail_tattoo" id="detail_nail_tattoo">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
            
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Magician</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="magician" name="magician" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="magician" name="magician" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_magician" id="detail_magician">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
       

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Mehandi Decoration</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="mehandi_decoration" name="mehandi_decoration" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="mehandi_decoration" name="mehandi_decoration" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_mehandi_decoration" id="detail_mehandi_decoration">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                     
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Anchor</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="mehandi_anchor" name="mehandi_anchor" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="mehandi_anchor" name="mehandi_anchor" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control" name="detail_mehandi_anchor" id="detail_mehandi_anchor">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                   
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Light and Sound</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="mehandi_light" name="mehandi_light" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="mehandi_light" name="mehandi_light" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_mehandi_light" id="detail_mehandi_light">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
         

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Dhol</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="mehandi_dhol" name="mehandi_dhol" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="mehandi_dhol" name="mehandi_dhol" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="deatil_mehandi_dhol" id="deatil_mehandi_dhol" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Spical Entry</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="sp_entry" name="sp_entry" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="sp_entry" name="sp_entry" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_sp_entry" id="detail_sp_entry">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                 
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Fooding</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="mehandi_fooding" name="mehandi_fooding" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="mehandi_fooding" name="mehandi_fooding" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_mehandi_fooding" id="detail_mehandi_fooding">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                

                                <div class="col-md-4">
                                   
                                  
                                </div> 
                               <div class="col-md-4">
                                    
                                   
                                </div>
                           </div>

                            

                        
                       
                      </fieldset>

                      <h3>Services Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Pick-up and Drop</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="pick_drop" name="pick_drop" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="pick_drop" name="pick_drop" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_pick_drop" id="detail_pick_drop" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
              

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Car Services</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="car_service" name="car_service" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="car_service" name="car_service" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_car_service" id="detail_car_service">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                          
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Luggage Boys</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="luggages_boy" name="luggages_boy" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="luggages_boy" name="luggages_boy" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_luggages_boy" id="detail_luggages_boy">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                             
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Welcomes Girls</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="welcome_girl" name="welcome_girl" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="welcome_girl" name="welcome_girl" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_welcome_girl" id="detail_welcome_girl">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                  

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Help Desk Boys</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="help_boy" name="help_boy" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="help_boy" name="help_boy" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_help_boy" id="detail_help_boy">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Valets and Guard</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="valet_gurd" name="valet_gurd" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="valet_gurd" name="valet_gurd" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control" name="detail_valet_gurd" id="detail_valet_gurd">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                       
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">E-Rickshaw</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="e_rickshaw" name="e_rickshaw" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="e_rickshaw" name="e_rickshaw" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_e_rickshaw" id="detail_e_rickshaw" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Room Hampers</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="room_hampers" name="room_hampers" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="room_hampers" name="room_hampers" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_room_hampers" id="detail_room_hampers">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Senitization</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="senitization" name="senitization" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="senitization" name="senitization" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_senitization" id="detail_senitization">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                       
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Volunteers</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="volunteers" name="volunteers" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="volunteers" name="volunteers" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_volunteers" id="detail_volunteers">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                             

                                <div class="col-md-4">
                                   
                                  
                                </div> 
                               <div class="col-md-4">
                                    
                                   
                                </div>
                           </div>

                            

                        
                       
                      </fieldset>
                      <h3>Entertainment Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Pool Party</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="pool_party" name="pool_party" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="pool_party" name="pool_party" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_pool_party" id="detail_pool_party">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">DJ/Sound</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="dj_sound" name="dj_sound" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="dj_sound" name="dj_sound" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control" name="detail_dj_sound" id="detail_dj_sound">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                         
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Selfie Zone</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="selfi_zone" name="selfi_zone" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="selfi_zone" name="selfi_zone" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control" name="detail_selfi_zone" id="detail_selfi_zone" >
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                   
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Pool Party Props</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="pool_props" name="pool_props" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="pool_props" name="pool_props" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_pool_props" id="detail_pool_props">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Meena Bazar</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="meena_bazar" name="meena_bazar" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="meena_bazar" name="meena_bazar" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_meena_bazar" id="detail_meena_bazar">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                          
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Housie</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="housie" name="housie" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="housie" name="housie" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"  name="detail_housie" id="detail_housie">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Sports/Crselection Oss Fit</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="crselection_oss" name="crselection_oss" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="crselection_oss" name="crselection_oss" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_crselection_oss" id="detail_crselection_oss">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           

                                 <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Dhol Boys</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="dhol_boy" name="dhol_boy" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="dhol_boy" name="dhol_boy" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_dhol_boy" id="detail_dhol_boy" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                             
                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Cartoon Dancer</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="cartoon_dancer" name="cartoon_dancer" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="cartoon_dancer" name="cartoon_dancer" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cartoon_dancer" id="detail_cartoon_dancer">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               
                           </div>
                            <hr>
                           <div class="row">
                              <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Flower Jewellery</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="flower_jewellery" name="flower_jewellery" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="flower_jewellery" name="flower_jewellery" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_flower_jewellery" id="detail_flower_jewellery">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                               

                                 <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Bangel Shop</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="bangel_shop" name="bangel_shop" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="bangel_shop" name="bangel_shop" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_bangel_shop" id="detail_bangel_shop">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Photo Framing</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="photo_framing" name="photo_framing" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="photo_framing" name="photo_framing" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_photo_framing" id="detail_photo_framing">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            
                           </div>

                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                  <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Paper Show</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="paper_show" name="paper_show" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="paper_show" name="paper_show" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_paper_show" id="detail_paper_show">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                              

                                <div class="col-md-4">
                              
                               </div> 
                               <div class="col-md-4">
                               
                               </div>
                           </div>

                      
                      </fieldset>
                      <h3>Sangeet Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Truss</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="truss" name="truss" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="truss" name="truss" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_truss" id="detail_truss">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">LED Wall</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="led_wall" name="led_wall" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="led_wall" name="led_wall" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_led_wall" id="detail_led_wall">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                             
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Light</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="light" name="light" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="light" name="light" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control" name="detail_light" id="detail_light">
                                          </div>
                                        </div>
                                          <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                         
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Sound</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sound" name="sound" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sound" name="sound" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_sound" id="detail_sound">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                             

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Generator</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="generator" name="generator" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="generator" name="generator" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_generator" id="detail_generator">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                        
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Background dancer</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="background_dancer" name="background_dancer" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="background_dancer" name="background_dancer" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_background_dancer" id="detail_background_dancer">
                                          </div>
                                        </div>
                                          <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                   
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Choreographer</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="choreographer" name="choreographer" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="choreographer" name="choreographer" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_choreographer" id="detail_choreographer">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Sangeet Anchoor</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="sangeet_anchor" name="sangeet_anchor" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="sangeet_anchor" name="sangeet_anchor" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_sangeet_anchor" id="detail_sangeet_anchor" >
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Russian Waiters</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="russian_waiters" name="russian_waiters" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="russian_waiters" name="russian_waiters" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_russian_waiters" id="detail_russian_waiters" >
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                        
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">TV/Bollywood Artist</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="bollywood_artist" name="bollywood_artist" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="bollywood_artist" name="bollywood_artist" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_bollywood_artist" id="detail_bollywood_artist">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                    

                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Bride Groom Entry</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="bG_entry" name="bG_entry" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="bG_entry" name="bG_entry" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_bG_entry" id="detail_bG_entry">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                              
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Cold Payro</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="cold_payro" name="cold_payro" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="cold_payro" name="cold_payro" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cold_payro" id="detail_cold_payro">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           
                           </div>

                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Paper Blasts</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="paper_blast" name="paper_blast" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="paper_blast" name="paper_blast" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_paper_blast" id="detail_paper_blast">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                        

                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Dry Ice</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="dry_ice" name="dry_ice" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="dry_ice" name="dry_ice" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_dry_ice" id="detail_dry_ice">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                        
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Fire</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="fire" name="fire" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="fire" name="fire" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_fire" id="detail_fire">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                      
                           </div>

                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Smoke Machine</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="smoke_machine" name="smoke_machine" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="smoke_machine" name="smoke_machine" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_smoke_machine" id="detail_smoke_machine">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                   

                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Sangeet Decoration</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_decoration" name="sangeet_decoration" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_decoration" name="sangeet_decoration" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_sangeet_decoration" id="detail_sangeet_decoration">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                    
                               <div class="col-md-4">
                               
                               </div>
                           </div>

                      
                      </fieldset>
                      <h3>Mayra Bhat</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Sound</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="m_sound" name="m_sound" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="m_sound" name="m_sound" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_m_sound" id="detail_m_sound">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Mayra Musical Artist Team</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="myra_team" name="myra_team" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="myra_team" name="myra_team" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_myra_team" id="detail_myra_team">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Background Dancer</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="mayra_back_dancer" name="mayra_back_dancer" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="mayra_back_dancer" name="mayra_back_dancer" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_mayra_back_dancer" id="detail_mayra_back_dancer">
                                          </div>
                                        </div>
                                          <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                         
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Decoration Selfie Corner</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="selfi_corner" name="selfi_corner" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="selfi_corner" name="selfi_corner" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_selfi_corner" id="detail_selfi_corner">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Special Entry</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="mayra_sp_entry" name="mayra_sp_entry" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="mayra_sp_entry" name="mayra_sp_entry" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_mayra_sp_entry" id="detail_mayra_sp_entry">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                             <div class="col-md-4">
                               
                                     
                              </div>
                           </div>
                          

                      </fieldset>
                      <h3>Haldi</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Handi Decoration</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="handi_decoration" name="handi_decoration" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="handi_decoration" name="handi_decoration" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_handi_decoration" id="detail_handi_decoration">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                             

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Anchor</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="haldi_anchor" name="haldi_anchor" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="haldi_anchor" name="haldi_anchor" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_haldi_anchor" id="detail_haldi_anchor">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Sound</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="haldi_sound" name="haldi_sound" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="haldi_sound" name="haldi_sound" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_haldi_sound" id="detail_haldi_sound" >
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                           
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Lights</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="haldi_lights" name="haldi_lights" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="haldi_lights" name="haldi_lights" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_haldi_lights" id="detail_haldi_lights">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Special Entry</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="haldi_sp_entry" name="haldi_sp_entry" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="haldi_sp_entry" name="haldi_sp_entry" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_haldi_sp_entry" id="detail_haldi_sp_entry">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                       
                             <div class="col-md-4">
                               
                                     
                              </div>
                           </div>
                          

                      </fieldset>
                      <h3>Reception</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Bride Groom Entry</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="reception_bg_entry" name="reception_bg_entry" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="reception_bg_entry" name="reception_bg_entry" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_reception_bg_entry" id="detail_reception_bg_entry">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Unplugged Band</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="unplugged_band" name="unplugged_band" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="unplugged_band" name="unplugged_band" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_unplugged_band" id="detail_unplugged_band" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                               
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Artist</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="reception_artist" name="reception_artist" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="reception_artist" name="reception_artist" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_reception_artist" id="detail_reception_artist">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                           
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Unplugged Singer with Guitar</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="gitar_artist" name="gitar_artist" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="gitar_artist" name="gitar_artist" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_gitar_artist" id="detail_gitar_artist">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Waiters</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="rec_waiters" name="rec_waiters" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="rec_waiters" name="rec_waiters" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rec_waiters" id="detail_rec_waiters" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Fluit Artist</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="fluit_artist" name="fluit_artist" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="fluit_artist" name="fluit_artist" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_fluit_artist" id="detail_fluit_artist">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                    
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Band</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_band" name="rec_band" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_band" name="rec_band" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rec_band" id="detail_rec_band">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Instrumental Music</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="intrumental_music" name="intrumental_music" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="intrumental_music" name="intrumental_music" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_intrumental_music" id="detail_intrumental_music" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                       
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Instrumental Band</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="intrumental_band" name="intrumental_band" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="intrumental_band" name="intrumental_band" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_intrumental_band" id="detail_intrumental_band">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                          
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Sound</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_sound" name="rec_sound" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_sound" name="rec_sound" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">IF YES, Mention the scale</label>
                                        <input type="text" class="form-control" name="detail_rec_sound" id="detail_rec_sound" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                              

                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Light</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_light" name="rec_light" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_light" name="rec_light" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_rec_light" id="detail_rec_light">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                         
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Led Wall</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_led" name="rec_led" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_led" name="rec_led" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rec_led" id="detail_rec_led">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                          
                           </div>

                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Truss</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_truss" name="rec_truss" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_truss" name="rec_truss" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rec_truss" id="detail_rec_truss">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                          

                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Reception Decoration</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_decoration" name="rec_decoration" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_decoration" name="rec_decoration" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rec_decoration" id="detail_rec_decoration">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                            
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Theam Based Entry</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_theam_enytry" name="rec_theam_enytry" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_theam_enytry" name="rec_theam_enytry" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rec_theam_enytry" id="detail_rec_theam_enytry">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                              
                           </div>

                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Counter</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_counter" name="rec_counter" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_counter" name="rec_counter" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rec_counter" id="detail_rec_counter">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                              

                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Coconut Water</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="coconut_water" name="coconut_water" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="coconut_water" name="coconut_water" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_coconut_water" id="detail_coconut_water" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                         
                               <div class="col-md-4">
                                
                               </div>
                           </div>

                      
                      </fieldset>
                      <h3>Barat</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Band Party</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="barat_bandparty" name="barat_bandparty" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="barat_bandparty" name="barat_bandparty" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_barat_bandparty" id="detail_barat_bandparty">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Dhumal Party</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="dhumal_party" name="dhumal_party" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="dhumal_party" name="dhumal_party" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_dhumal_party" id="detail_dhumal_party">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Dhol Boys</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="barat_dholboys" name="barat_dholboys" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="barat_dholboys" name="barat_dholboys" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_barat_dholboys" id="detail_barat_dholboys">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
            
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Shehnai Player</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="shehnai_player" name="shehnai_player" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="shehnai_player" name="shehnai_player" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_shehnai_player" id="detail_shehnai_player">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Welcoming Girls</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="barat_welcomegirls" name="barat_welcomegirls" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="barat_welcomegirls" name="barat_welcomegirls" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_barat_welcomegirls" id="detail_barat_welcomegirls" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Safa</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="safa" name="safa" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="safa" name="safa" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_safa" id="detail_safa">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                     
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Ghodi</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="ghodi" name="ghodi" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="ghodi" name="ghodi" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_ghodi" id="detail_ghodi">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                             

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Firecrackers</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="firecrackers" name="firecrackers" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="firecrackers" name="firecrackers" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_firecrackers" id="detail_firecrackers">
                                      </div>
                                    </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Lights</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="barat_light" name="barat_light" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="barat_light" name="barat_light" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_barat_light" id="detail_barat_light">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                              
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Baggi/Vintage Car</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="baggi_vintagecar" name="baggi_vintagecar" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="baggi_vintagecar" name="baggi_vintagecar" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="detail_baggi_vintagecar" id="detail_baggi_vintagecar">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Itrs</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="itrs" name="itrs" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="itrs" name="itrs" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_itrs" id="detail_itrs">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                     
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Samdhi Mala</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="samdhi_mala" name="samdhi_mala" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="samdhi_mala" name="samdhi_mala" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_samdhi_mala" id="detail_samdhi_mala">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           
                           </div>

                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Rose</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rose" name="rose" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rose" name="rose" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rose" id="detail_rose">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                
                               </div> 
                               <div class="col-md-4">
                               
                               </div>
                           </div>

                      
                      </fieldset>
                      <h3>Cocktail party</h3>
                       <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Sound</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="cocktail_sound" name="cocktail_sound" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="cocktail_sound" name="cocktail_sound" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cocktail_sound" id="detail_cocktail_sound">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
               

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Lights</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="cocktail_lights" name="cocktail_lights" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="cocktail_lights" name="cocktail_lights" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_cocktail_lights" id="detail_cocktail_lights">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Truss</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="cocktail_truss" name="cocktail_truss" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="cocktail_truss" name="cocktail_truss" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_cocktail_truss" id="detail_cocktail_truss">
                                          </div>
                                        </div>
                                          <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                     
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Led Wall</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="cocktail_led_wall" name="cocktail_led_wall" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="cocktail_led_wall" name="cocktail_led_wall" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cocktail_led_wall" id="detail_cocktail_led_wall">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                    

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Background Dancer</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="cacktail_background_dancer" name="cacktail_background_dancer" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="cacktail_background_dancer" name="cacktail_background_dancer" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cacktail_background_dancer" id="detail_cacktail_background_dancer">
                                      </div>
                                    </div>
                                              <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                      
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Belly Dancer</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="belly_dancer" name="belly_dancer" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="belly_dancer" name="belly_dancer" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_belly_dancer" id="detail_belly_dancer">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                          
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Waiters</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="cocktail_waiters" name="cocktail_waiters" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="cocktail_waiters" name="cocktail_waiters" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cocktail_waiters" id="detail_cocktail_waiters">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Theam Based Decoration</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="cocktail_team" name="cocktail_team" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="cocktail_team" name="cocktail_team" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cocktail_team" id="detail_cocktail_team" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                               
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Anchor</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="cocktail_anchor" name="cocktail_anchor" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="cocktail_anchor" name="cocktail_anchor" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_cocktail_anchor" id="detail_cocktail_anchor">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
              
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Rock Band</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rock_band" name="rock_band" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rock_band" name="rock_band" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_rock_band" id="detail_rock_band" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                              

                                <div class="col-md-4">
                               
                               </div> 
                               <div class="col-md-4">
                               
                               </div>
                           </div>

                                                
                      </fieldset>
                      <h3>Common List</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Photography</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="photography" name="photography" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="photography" name="photography" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_photography" id="detail_photography">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                          

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Makeup</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="makeup" name="makeup" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="makeup" name="makeup" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="detail_makeup" id="detail_makeup">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                   
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Caters</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="caters" name="caters" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="caters" name="caters" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_caters" id="detail_caters">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                   
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Clothing</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="clothing" name="clothing" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="clothing" name="clothing" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="detail_clothing" id="detail_clothing">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                       
                                <div class="col-md-4">
                                   
                                </div> 
                             <div class="col-md-4">
                                
                              </div>
                           </div>
                         

                                                
                      </fieldset>
                  
                    </form>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </section>
        
      </div>
      <footer class="main-footer">
        <div class="footer-right">
          Copyright &copy; 2022 <div class="bullet"></div> Reserved By <a href="https://www.programmics.co.in/">PROGRAMMICS TECHNOLOGY.</a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
 
  <script src="{{ asset('public/app-assets/js/req_app.min.js') }}"></script>
   <script src="{{ asset('public/app-assets/js/jquery.validate.min.js') }}"></script>
  <!-- JS Libraies -->
  <script src="{{ asset('public/app-assets/js/jquery.steps.min.js') }}"></script>
  <!-- Page Specific JS File -->
  <script src="{{ asset('public/app-assets/js/formmm-wizard.js') }}"></script>
  <!-- Template JS File -->
  <script src="{{ asset('public/app-assets/js/req_scripts.js') }}"></script>
  <!-- Custom JS File -->
  <script src="{{ asset('public/app-assets/js/req_custom.js') }}"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>


</html>

