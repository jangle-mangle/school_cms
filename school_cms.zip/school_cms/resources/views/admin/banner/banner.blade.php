@include('admin.layout.header')

<!-- BEGIN: Content-->
<div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="content-header row"></div>
        <div class="content-body">
            <section class="users-list-wrapper">
                <div class="users-list-table mt-2">
                    <div class="card">
                        <div class="card-body">
                            <!-- datatable start -->
                            <div class="table-responsive">
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#bannerAddModal" style="float: right;">Add</button>
                                <table id="ExecutiveMembersTable" class="table table-striped" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Title</th>
                                            <th>Banner</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($banners as $banner)     
                                        <tr>
                                            <td>{{$banner->id}}</td>
                                            <td>{{$banner->title}}</td>
                                            <td>
                                                <img style="width:50px;" src="{{asset('uploads/banner/'.$banner->img)}}" alt="">
                                            </td>
                                            <td>
                                                <a class="btn btn-sm btn-outline-danger" href="{{url('admin/admin-delete-banner/'.$banner->id)}}"> Delete </a>
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <!-- datatable ends -->
                            </div>
                            <!-- datatable ends -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- users list ends -->
        </div>
    </div>
</div>
<div class="buy-now" style="right: 60px;"><button type="button" class="btn btn-danger" data-toggle="modal"
        data-target="#vacancyAddModal">+</button></div>
<div class="sidenav-overlay"></div>
<div class="drag-target"></div>
<!-- Earning Swiper Starts -->


@include('admin.layout.footer')
@include('admin.modal.bannerAddModal')

</body>
<!-- END: Body-->

</html>
