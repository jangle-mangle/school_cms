<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>The Wedding Solution - Dashboard</title>
  <!-- General CSS Files -->
   
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_app.min.css') }}">
  <!-- Template CSS -->
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_style.css') }}">
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_components.css') }}">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="{{ asset('public/app-assets/css/req_custom.css') }}">
  <link rel='shortcut icon' type='image/x-icon' href="{{ asset('public/app-assets/img/favicon.ico') }}" />
  <style>
    .wizard>.steps {
    position: sticky;
    display: block;
    width: 100%;
    overflow: auto;
}
.wizard>.steps>ul>li {
    width: 25%;
    
    width: 260px !important;
}
.wizard ul, .tabcontrol ul{
  width: 2345px;
    display: flex;
    overflow: scroll;
    overflow: auto;
}
.wizard>.steps  a {
    background: #eee;
    color: #aaa;
    cursor: default;
}
.form-label{
  color:black;
  font-weight: bold;
}
.form-float{
   color:black;
  font-weight: bold;

}

    </style>
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1 ">
      <div class="navbar-bg"></div>
      <!-- <nav class="navbar navbar-expand-lg main-navbar sticky"> -->
       <!--  <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
                                    collapse-btn"> <i data-feather="menu"></i></a></li>
            <li>
              <form class="form-inline mr-auto">
                <div class="search-element">
                  <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="200">
                  <button class="btn" type="submit">
                    <i class="fas fa-search"></i>
                  </button>
                </div>
              </form>
            </li>
          </ul>
        </div> -->
       
      <!-- </nav> -->
      
      <!-- Main Content -->
      <div class="main-content" style="padding-right: 4px;
    padding-left: 4px;">
        <section class="section">
        
          <div class="section-body">
            
           <div class="row clearfix">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="card">
                  <div class="card-header">
                    <h4>The Wedding solutions</h4>
                  </div>
                  <div class="card-body">
                    <form id="wizard_with_validation" method="POST">
                      @csrf
                      <h3>Basic Information</h3>
                      <fieldset>

                        <div class="row">
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                              <div class="form-line">
                                <label class="form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" required>
                              </div>
                            </div>
                             <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                                  <div class="form-line">
                                    <label class="form-label">Date Of Wedding</label>
                                    <input type="date" class="form-control" id="date" name="date" >
                                  </div>
                                </div>
                                 <hr class="d-block d-sm-none" style="border-top: 1px solid black;" >
                           </div>
                       </div>

                          <div class="row">
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                              <div class="form-line">
                                <label class="form-label">Contact Number <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="mobile" id="mobile" required>
                              </div>
                            </div>
                             <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                           <div class="col-md-6">
                                 <div class="form-group form-float">
                                  <div class="form-line">
                                    <label class="form-label">Venue  </label>
                                    <input type="text" class="form-control" id="venue" name="venue" >
                                  </div>
                                </div>
                                 <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                       </div>

                       <div class="row">
                           <div class="col-md-12">
                                 <div class="form-group form-float">
                              <div class="form-line">
                                  <label class="form-label">User Email </label>
                                    <input type="email" class="form-control" id="username" name="username" >
                              </div>
                            </div>
                             <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                           </div>
                        
                       </div>
                       
                       
                       
                        
                      </fieldset>

                      <h3>Decoration Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Mehandi Setup</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="mehandi_setup" name="mehandi_setup" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="mehandi_setup" name="mehandi_setup" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>

                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="mehandi_setup_detail" id="mehandi_setup_detail" >
                                      </div>
                                    </div>
                                    <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Haldi Mandap</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="hadli_setup" name="hadli_setup" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="hadli_setup" name="hadli_setup" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="hadli_setup_detail" id="hadli_setup_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Sangeet Stage</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="sangeet_stage" name="sangeet_stage" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="sangeet_stage" name="sangeet_stage" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="sangeet_stage_detail" id="sangeet_stage_detail">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                            
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Reception Stage</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="reception_stage" name="reception_stage" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="reception_stage" name="reception_stage" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="reception_stage_detail" id="reception_stage_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                              

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Entry & Venue</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="entry_venue" name="entry_venue" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="entry_venue" name="entry_venue" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="entry_venue_detail" id="entry_venue_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                          
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Bride Mandap Decoration</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="bride_man_decoration" name="bride_man_decoration" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="bride_man_decoration" name="bride_man_decoration" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="bride_man_decoration_detail" id="bride_man_decoration_detail">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                         
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Groom Mandap Decoration</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="groom_man_decoration" name="groom_man_decoration" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="groom_man_decoration" name="groom_man_decoration" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                      <input type="text" class="form-control" name="groom_man_decoration_detail" id="groom_man_decoration_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                      

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Food Counter Setup</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="food_cou_setup" name="food_cou_setup" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="food_cou_setup" name="food_cou_setup" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="food_cou_setup_detail" id="food_cou_setup_detail" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                         
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">VIP Lounge</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="vip_lounge" name="vip_lounge" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="vip_lounge" name="vip_lounge" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="vip_lounge_detail" id="vip_lounge_detail" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Sajan Kot</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sajan_kot" name="sajan_kot" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sajan_kot" name="sajan_kot" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                      <input type="text" class="form-control" name="sajan_kot_detail" id="sajan_kot_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                      

                                     <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Selfie Booth</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="selfie_booth" name="selfie_booth" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="selfie_booth" name="selfie_booth" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                      <input type="text" class="form-control" name="selfie_booth_detail" id="selfie_booth_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                      
                         
                              <div class="col-md-4">
                               
                              </div>
                           </div>

                            

                        
                       
                      </fieldset>

                      <h3>Mehandi Detail</h3>
                     <fieldset>

                            <div class="row">
                                                   

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Mehandi Artist</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="mehandi_artist" name="mehandi_artist" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="mehandi_artist" name="mehandi_artist" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details Number of People</label>
                                        <input type="text" class="form-control" name="detail_mehandi_artist" id="detail_mehandi_artist">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                       
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Dhol Boys</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="mehandi_dhol_boy" name="mehandi_dhol_boy" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="mehandi_dhol_boy" name="mehandi_dhol_boy" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="mehandi_dhol_boy_detail" id="mehandi_dhol_boy_detail">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>

                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Nail and Tattoo Artist</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="nail_tattoo" name="nail_tattoo" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="nail_tattoo" name="nail_tattoo" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="detail_nail_tattoo" id="detail_nail_tattoo">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
            
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Entertainment</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="mehandi_entertainment" name="mehandi_entertainment" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="mehandi_entertainment" name="mehandi_entertainment" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="mehandi_entertainment_detail" id="mehandi_entertainment_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
       

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Sound & DJ</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="mehandi_sound_dj" name="mehandi_sound_dj" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="mehandi_sound_dj" name="mehandi_sound_dj" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="mehandi_sound_dj_detail" id="mehandi_sound_dj_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                     
                             <div class="col-md-4">
                             
                              </div>
                   
                           </div>
                         

                            

                        
                       
                      </fieldset>

                      <h3>Haldi Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Flower Shower</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="flower_shower" name="flower_shower" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="flower_shower" name="flower_shower" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="flower_shower_detail" id="flower_shower_detail" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
              

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Dhol Boys</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="hadli_dhol_boy" name="hadli_dhol_boy" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="hadli_dhol_boy" name="hadli_dhol_boy" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="hadli_dhol_boy_detail" id="hadli_dhol_boy_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                          
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Props</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="haldi_props" name="haldi_props" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="haldi_props" name="haldi_props" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="haldi_props_detail" id="haldi_props_detail">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;">
                              </div>
                             
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Entry</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="haldi_entry" name="haldi_entry" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="haldi_entry" name="haldi_entry" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="haldi_entry_detail" id="haldi_entry_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                  

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Color Bomb</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="color_bomb" name="color_bomb" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="color_bomb" name="color_bomb" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="color_bomb_detail" id="color_bomb_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Sound & DJ</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="haldi_sound_dj" name="haldi_sound_dj" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="haldi_sound_dj" name="haldi_sound_dj" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control" name="haldi_sound_dj_detail" id="haldi_sound_dj_detail">
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                       
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Colors</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="haldi_colors" name="haldi_colors" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="haldi_colors" name="haldi_colors" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="haldi_colors_detail" id="haldi_colors_detail" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               

                                <div class="col-md-4">
                                 
                                </div> 
                           
                               <div class="col-md-4">
                                    
                                </div>
                       
                           </div>
                                                   

                        
                       
                      </fieldset>
                      <h3>Sangeet Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Light Setup</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_light" name="sangeet_light" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_light" name="sangeet_light" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="sangeet_light_detail" id="sangeet_light_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Sound & DJ</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="sangeet_dj_sound" name="sangeet_dj_sound" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="sangeet_dj_sound" name="sangeet_dj_sound" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control" name="sangeet_dj_sound_detail" id="sangeet_dj_sound_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                         
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Anchor</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="sangeet_anchor" name="sangeet_anchor" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="sangeet_anchor" name="sangeet_anchor" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control" name="sangeet_anchor_detail" id="sangeet_anchor_detail" >
                                          </div>
                                        </div>
                                         <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                   
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Choreography</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_choreography" name="sangeet_choreography" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_choreography" name="sangeet_choreography" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="sangeet_choreography_detail" id="sangeet_choreography_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Bride Groom Entry</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="sangeet_bg_entry" name="sangeet_bg_entry" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="sangeet_bg_entry" name="sangeet_bg_entry" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="sangeet_bg_entry_detail" id="sangeet_bg_entry_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                          
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Paper Blasters</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_paper_blast" name="sangeet_paper_blast" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_paper_blast" name="sangeet_paper_blast" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"  name="sangeet_paper_blast_detail" id="sangeet_paper_blast_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Cold Pyro</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="sangeet_cold_pyro" name="sangeet_cold_pyro" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="sangeet_cold_pyro" name="sangeet_cold_pyro" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="sangeet_cp_detail" id="sangeet_cp_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           

                                 <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">LED Wall</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="sangeet_led_wall" name="sangeet_led_wall" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="sangeet_led_wall" name="sangeet_led_wall" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="sangeet_led_wall_detail" id="sangeet_led_wall_detail" >
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                             
                                <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Background Dancer</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_back_dancer" name="sangeet_back_dancer" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_back_dancer" name="sangeet_back_dancer" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                       <input type="text" class="form-control"   name="sangeet_back_dancer_detail" id="sangeet_back_dancer_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               
                           </div>
                            <hr>
                           <div class="row">
                              <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">CO-2 Blast</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_co2_blast" name="sangeet_co2_blast" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_co2_blast" name="sangeet_co2_blast" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="sangeet_co2_blast_detail" id="sangeet_co2_blast_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div> 
                               

                                 <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Fire Blast</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_fire" name="sangeet_fire" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_fire" name="sangeet_fire" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="sangeet_fire_detail" id="sangeet_fire_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Entry</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="sangeet_entry" name="sangeet_entry" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="sangeet_entry" name="sangeet_entry" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="sangeet_entry_detail" id="sangeet_entry_detail">
                                      </div>
                                    </div>
                                     <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            
                           </div>

                          
                      
                      </fieldset>
                      <h3>Barat Detail</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Dhumal</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="barat_dhumal" name="barat_dhumal" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="barat_dhumal" name="barat_dhumal" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="barat_dhumal_detail" id="barat_dhumal_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Dhol</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="barat_dhol" name="barat_dhol" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="barat_dhol" name="barat_dhol" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="barat_dhol_detail" id="barat_dhol_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                             
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Safa</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="barat_saja" name="barat_saja" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="barat_saja" name="barat_saja" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control" name="barat_saja_detail" id="barat_saja_detail">
                                          </div>
                                        </div>
                                          <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                         
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Fire Crackers</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="barat_fire_crack" name="barat_fire_crack" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="barat_fire_crack" name="barat_fire_crack" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="barat_fire_crack_detail" id="barat_fire_crack_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                             

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Vintage Car</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="barat_vinatge_car" name="barat_vinatge_car" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="barat_vinatge_car" name="barat_vinatge_car" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="barat_vinatge_car_detail" id="barat_vinatge_car_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                        
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Car</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="barat_car" name="barat_car" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="barat_car" name="barat_car" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="barat_car_detail" id="barat_car_detail">
                                          </div>
                                        </div>
                                          <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                   
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Ghodi</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="barat_ghodi" name="barat_ghodi" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="barat_ghodi" name="barat_ghodi" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="barat_ghodi_detail" id="barat_ghodi_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Car Decoration</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="barat_car_decoration" name="barat_car_decoration" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="barat_car_decoration" name="barat_car_decoration" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                     <input type="text" class="form-control" name="barat_car_decoration_detail" id="barat_car_decoration_detail" >
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                               <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Samdhi Mala</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="barat_samdhi_mala" name="barat_samdhi_mala" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="barat_samdhi_mala" name="barat_samdhi_mala" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="barat_samdhi_mala_detail" id="barat_samdhi_mala_detail" >
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div>
                        
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Paper Confetti</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="barat_paper_confit" name="barat_paper_confit" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="barat_paper_confit" name="barat_paper_confit" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="barat_paper_confit_detail" id="barat_paper_confit_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                    

                                <div class="col-md-4">
                                
                               </div> 
                              
                               <div class="col-md-4">
                               
                               </div>
                           
                           </div>


                      
                      </fieldset>
                      <h3>Reception</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Bride Groom Entry</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_bg_entry" name="rec_bg_entry" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_bg_entry" name="rec_bg_entry" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="rec_bg_entry_detail" id="rec_bg_entry_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">DJ & Sound</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="rec_dj_sound" name="rec_dj_sound" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="rec_dj_sound" name="rec_dj_sound" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="rec_dj_sound_detail" id="rec_dj_sound_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Light</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="rec_light" name="rec_light" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="rec_light" name="rec_light" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="rec_light_detail" id="rec_light_detail">
                                          </div>
                                        </div>
                                          <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                         
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Varmala</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_varmala" name="rec_varmala" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_varmala" name="rec_varmala" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="rec_varmala_detail" id="rec_varmala_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Instrumental Band Group</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="rec_ins_group" name="rec_ins_group" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="rec_ins_group" name="rec_ins_group" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="rec_ins_group_detail" id="rec_ins_group_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                             <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Varmala Rotating Stage</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="rec_rot_stage" name="rec_rot_stage" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="rec_rot_stage" name="rec_rot_stage" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="rec_rot_stage_detail" id="rec_rot_stage_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           </div>
                            <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Paper Blaster</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="rec_paper_blaster" name="rec_paper_blaster" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="rec_paper_blaster" name="rec_paper_blaster" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="rec_paper_blaster_detail" id="rec_paper_blaster_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Cold Pyro</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="rec_cold_pyro" name="rec_cold_pyro" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="rec_cold_pyro" name="rec_cold_pyro" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="rec_cold_pyro_detail" id="rec_cold_pyro_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                             <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Cake</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="rec_cake" name="rec_cake" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="rec_cake" name="rec_cake" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control" name="rec_cake_detail" id="rec_cake_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           </div>
                          

                      </fieldset>
                      <h3>Phere</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Havan Kund</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="phere_havan_kund" name="phere_havan_kund" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="phere_havan_kund" name="phere_havan_kund" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="phere_havan_kund_detail" id="phere_havan_kund_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                             

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Pandit</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="phere_pandit" name="phere_pandit" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="phere_pandit" name="phere_pandit" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="phere_pandit_detail" id="phere_pandit_detail">
                                      </div>
                                    </div>
                                      <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Phoolon ki Chadar</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="phere_phol_chadar" name="phere_phol_chadar" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="phere_phol_chadar" name="phere_phol_chadar" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                          <input type="text" class="form-control"   name="phere_phol_chadar_detail" id="phere_phol_chadar_detail" >
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                           
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Sehanai Vadak</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="phere_sehnai_vadak" name="phere_sehnai_vadak" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="phere_sehnai_vadak" name="phere_sehnai_vadak" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="phere_sehnai_vadak_detail" id="phere_sehnai_vadak_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Sound System</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="phere_sound" name="phere_sound" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="phere_sound" name="phere_sound" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="phere_sound_detail" id="phere_sound_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                       
                             <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Makeup Artist</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="phere_makeup" name="phere_makeup" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="phere_makeup" name="phere_makeup" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="phere_makeup_detail" id="phere_makeup_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                           </div>
                          

                      </fieldset>
                      <h3>Cocktail/Pool Party</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Theme Props</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="pool_theme" name="pool_theme" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="pool_theme" name="pool_theme" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="pool_theme_detail" id="pool_theme_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">DJ & Sound</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="pool_dj_sound" name="pool_dj_sound" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="pool_dj_sound" name="pool_dj_sound" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="pool_dj_sound_detail" id="pool_dj_sound_detail" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                               
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">liquor license</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="pool_liquor" name="pool_liquor" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="pool_liquor" name="pool_liquor" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="pool_liquor_detail" id="pool_liquor_detail">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                           
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Dhol</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="pool_dhol" name="pool_dhol" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="pool_dhol" name="pool_dhol" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="pool_dhol_detail" id="pool_dhol_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
           

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Bar Tender/Female</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="pool_bar_tenders" name="pool_bar_tenders" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="pool_bar_tenders" name="pool_bar_tenders" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="pool_bar_tenders_detail" id="pool_bar_tenders_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                            
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Bar Setup</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="pool_bar_set" name="pool_bar_set" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="pool_bar_set" name="pool_bar_set" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                            <input type="text" class="form-control"   name="pool_bar_set_detail" id="pool_bar_set_detail">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                    
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Russian Waiters</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="pool_russian" name="pool_russian" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="pool_russian" name="pool_russian" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="pool_russian_detail" id="pool_russian_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                           
                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Jugglers</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="pool_jugglers" name="pool_jugglers" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="pool_jugglers" name="pool_jugglers" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="pool_jugglers_detail" id="pool_jugglers_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                       
                               <div class="col-md-4">
                                  
                                </div>
                          
                           </div>
                         
                      
                      </fieldset>
                      <h3>Others</h3>
                      <fieldset>

                            <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Makeup Artist</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="other_makeup_artist" name="other_makeup_artist" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="other_makeup_artist" name="other_makeup_artist" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                       <input type="text" class="form-control"   name="other_makeup_artist_detail" id="other_makeup_artist_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                            

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Caters</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="other_caters" name="other_caters" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="other_caters" name="other_caters" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details </label>
                                        <input type="text" class="form-control"   name="other_caters_detail" id="other_caters_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                                </div> 
                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Photography</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="other_photography" name="other_photography" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="other_photography" name="other_photography" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                          <input type="text" class="form-control" name="other_photography_detail" id="other_photography_detail">
                                           </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
            
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Clothing</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="other_cloth" name="other_cloth" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="other_cloth" name="other_cloth" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="other_cloth_detail" id="other_cloth_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                               

                                <div class="col-md-4">
                                    <div class="form-group form-float">
                                          <div class="form-line">
                                             <div class="form-group form-float">
                                                  <div class="form-line">
                                                    <label class="form-label">Car Services</label>
                                                    <label style="margin-left: 20px;">YES</label>
                                                    <input type="radio" id="other_car_service" name="other_car_service" value="YES">
                                                    <label>NO</label>
                                                    <input type="radio" id="other_car_service" name="other_car_service" value="NO">
                                                  </div>
                                            </div>
                                     
                                          </div>
                                     </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="other_car_service_detail" id="other_car_service_detail" >
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;">
                                </div> 
                                
                             <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Sanitization</label>
                                        <label style="margin-left: 20px;">YES</label>
                                        <input type="radio" id="other_sanitization" name="other_sanitization" value="YES">
                                        <label>NO</label>
                                        <input type="radio" id="other_sanitization" name="other_sanitization" value="NO">
                                      </div>
                                    </div>
                                 
                                      </div>
                                 </div>
                                        <div class="form-group form-float">
                                          <div class="form-line">
                                            <label class="form-label">Details</label>
                                          <input type="text" class="form-control" name="other_sanitization_detail" id="other_sanitization_detail">
                                          </div>
                                        </div>
                                            <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                              </div>
                     
                           </div>
                           <hr>
                           <div class="row">
                               <div class="col-md-4">
                                <div class="form-group form-float">
                                      <div class="form-line">
                                         <div class="form-group form-float">
                                              <div class="form-line">
                                                <label class="form-label">Help Desk</label>
                                                <label style="margin-left: 20px;">YES</label>
                                                <input type="radio" id="other_help" name="other_help" value="YES">
                                                <label>NO</label>
                                                <input type="radio" id="other_help" name="other_help" value="NO">
                                              </div>
                                         </div>
                                 
                                      </div>
                                 </div>
                                    <div class="form-group form-float">
                                      <div class="form-line">
                                        <label class="form-label">Details</label>
                                        <input type="text" class="form-control"   name="other_help_detail" id="other_help_detail">
                                      </div>
                                    </div>
                                        <hr class="d-block d-sm-none" style=" border-top: 1px solid black;" >
                               </div>
                             

                                <div class="col-md-4">
                                 
                                </div> 
                           
                               <div class="col-md-4">
                                    
                                </div>
                              
                           </div>
                         

                      
                      </fieldset>
                     
                  
                    </form>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </section>
        
      </div>
      <footer class="main-footer">
        <div class="footer-right">
          Copyright &copy; 2022 <div class="bullet"></div> Reserved By <a href="https://www.programmics.co.in/">PROGRAMMICS TECHNOLOGY.</a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
 
  <script src="{{ asset('public/app-assets/js/req_app.min.js') }}"></script>
   <script src="{{ asset('public/app-assets/js/jquery.validate.min.js') }}"></script>
  <!-- JS Libraies -->
  <script src="{{ asset('public/app-assets/js/jquery.steps.min.js') }}"></script>
  <!-- Page Specific JS File -->
  <script src="{{ asset('public/app-assets/js/formmm-wizard.js') }}"></script>
  <!-- Template JS File -->
  <script src="{{ asset('public/app-assets/js/req_scripts.js') }}"></script>
  <!-- Custom JS File -->
  <script src="{{ asset('public/app-assets/js/req_custom.js') }}"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>


</html>

