@include('user.layout.header')

<!-- ======= Hero Section ======= -->

<main id="main">

<section id="hero">
    <img class="banner_img" src="{{asset('assets/img/home/banner_1.jpg')}}" alt="">
    <img style="width:100%" src="{{asset('assets/img/home/banner_2.jpg')}}" alt="">
</section><!-- End Hero -->
<!-- ======= About Section ======= -->
<section id="about" class="about section_mob_view">
    <div class="container px-lg-5" data-aos="fade-up">

        <div class="row align-items-center">
            <h1 class="">About CSRA</h1>
            <small>
                <p>Chhattisgarh Steel Re-Rollers Association (CSRA) is an organization that has been dedicated
                    to enhancing the Steel Re-Rolling business
                    opportunities for its members since its inception in the year 1981. Registered under the
                    Societies Registration Act 1860, CSRA is
                    located in the vibrant city of Raipur, in the state of Chhattisgarh.</p>
            </small>
        </div>
        <div class="row align-items-start">
            <div class="col-lg-6">
                <div class="row px-4">
                    <div class="col-lg-12 px-4 card_height" style="border-bottom: 1px solid #dddddd;">
                        <div class="row">
                            <div class="col-lg-4 col-6">
                                <img src="{{asset('assets/img/home/icon_1.png')}}" class="img-fluid" alt="">
                            </div>
                            <div class="col-lg-8">
                                <h2>Our Vision </h2>
                                <p class="mt-lg-3">CCORE PURPOSE To provide
                                    information, programs, and
                                    services that improve the business
                                    opportunities of its members with
                                    coordination between state and
                                    Central government.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mt-lg-4">
                        <div class="row">
                            <div class="col-lg-4 col-6">
                                <img src="{{asset('assets/img/home/icon_3.png')}}" class="img-fluid" alt="">
                            </div>
                            <div class="col-lg-8">
                                <h2>Areas of
                                    Concern </h2>
                                <p>CSRA focuses on:</p>
                                <ul>
                                    <li>Value Creation</li>
                                    Safety
                                    <li>Energy Efficiency</li>
                                    <li>Acceptance of Renewable and</li>
                                    <li>New Sources of Energy</li>
                                    <li>Employment Generation</li>
                                    <li>Assisting in Cluster Development</li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row px-4" style="border-left: 1px solid #dddddd;">
                    <div class="col-lg-12 px-4 card_height" style="border-bottom: 1px solid #dddddd;">
                        <div class="row">
                            <div class="col-lg-4 col-6">
                                <img src="{{asset('assets/img/home/icon_2.png')}}" class="img-fluid" alt="">
                            </div>
                            <div class="col-lg-8">
                                <h2>Core Values </h2>
                                <ul class="mt-lg-3">
                                    <li>Environment Over Anything</li>
                                    <li>24*7 Members Assistance</li>
                                    <li>To Serve the Members with
                                        Govt. Rules and Regulations</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12 mt-lg-4">
                        <div class="row">
                            <div class="col-lg-4 col-6">
                                <img src="{{asset('assets/img/home/icon_4.png')}}" class="img-fluid" alt="">
                            </div>
                            <div class="col-lg-8">
                                <h2>Key Processe
                                    of CSRA </h2>
                                <p>CSRA focuses on:</p>
                                <ul>
                                    <li>Leadership</li>
                                    <li>Strategic Planning</li>
                                    <li> Management</li>
                                    <li>Market Development</li>
                                    <li>Investment Management</li>
                                    <li>Change Management</li>
                                    <li>Operating & Fulfillment</li>
                                    <li>Supply Management</li>
                                    <li>Research & Development</li>
                                    <li>Information Management</li>
                                    <li>Social Responsibility</li>


                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</section><!-- End About Section -->



<!-- ======= Our Product Section ======= -->
<section id="our_service" class="our_service"
    style="background: url('{{asset('assets/img/home/banner_3.png')}}');">
    <div class="container py-lg-5 py-3" data-aos="fade-up">
        <center>
            <h1 class="text-light text-uppercase">LEADERSHIP TEAM</h1>
        </center>
        <div class="row justify-content-center my-lg-4">
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-01.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">President</p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Sanjay Tripathi,
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Shivam Structural & Steel)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-02.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Gr. Secretary</p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Banke Bihari Agrawal, 
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Shivam Structural & Steel)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-03.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Treasure</p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Om Prakash Agrawal
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Sindh Ispat)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-04.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">IPP</p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Manoj Kumar Agrawal
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Mahendra Sponge & Power)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-05.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Vice President</p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Vinod Agrawal, 
                            
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Krishna Iron Strips & Tubes)</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center my-lg-4">
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-06.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Vice President
                           
                           </p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold"> Mr. Ajay Gupta,
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light"> (M/s. Adarsh Ispat Udyog Pvt. Ltd.)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-07.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Joint Secretary
                          
                           </p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold"> Mr. Rajkumar Agrawal, 
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light"> (M/s. Alankar Steels Pvt. Ltd)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-08.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Joint Secretary
                          
                            </p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">  Mr. Ashish Jindal,
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Ajay Ingot Rolling Mill Pvt. Ltd.)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-09.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Joint Secretary
                          
                             </p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">  Mr. R. N. Singla,
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Fortun Metliks Ltd.)</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 text-center my-0 leaders p-2">
                <div>
                    <img src="{{asset('assets/img/home/team-10.png')}}" class="img-fluid rounded-circle" alt="" style="width: 12rem;">
                    <div class="my-2">
                        <p style="font-size: 11px;" class="my-0 text-light">Vice Presiden</p>
                        <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Anand Choudhary je
                        </p>
                        <p style="font-size: 11px;" class="my-0 text-light">(M/s. Drolia Electrosteels Pvt. Ltd.)</p>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="row justify-content-center leadership_team_btn">
            <div class="col-5">
                <a href="{{route('executive.member')}}">
                    <img src="{{asset('assets/img/home/button_1.png')}}" class="img-fluid" alt="">
                </a>
            </div>
            <div class="col-5">
            <a href="{{route('member')}}">
                <img src="{{asset('assets/img/home/button_2.png')}}" class="img-fluid" alt="">
            </div>
            </a>
        </div>
       
    </div>
</section><!-- End Our Product Section -->




</main><!-- End #main -->

<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
@include('user.layout.footer')

<!-- End Footer -->