@include('user.layout.header')

<style>
    table thead th { background: #979797 !important; padding: 10px; border: 6px solid #ffffff; color: #ffffff !important; }
    table tbody td { background: #dddddd !important; border: 6px solid #ffffff; }
    table th, table td { vertical-align: middle; }
    .header_item a { color: #000000; }
</style>

<!-- ======= Hero Section ======= -->

<main id="main">
    <section id="hero">
    </section><!-- End Hero -->
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section_mob_view">
        <div class="container" data-aos="fade-up">
            <center>
                <h2 class="text-uppercase my-5 fw-bold">Executive Member</h2>
            </center>
            <div class="row">
                <div class="offset-md-1 col-md-10 table-responsive">
                    <table class="table text-center">
                        <thead>
                            <tr>
                                <th>NAME & DESIGNATION</th>
                                <th>PHONE</th>
                                <th>COMPANY</th>
                            </tr>
                        </thead>
                        <tbody>
                            {!! $tableData !!}
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </section><!-- End Contact Section -->



</main><!-- End #main -->

<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
@include('user.layout.footer')

<!-- End Footer -->
