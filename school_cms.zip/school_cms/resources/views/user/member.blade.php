@include('user.layout.header')
<!-- ======= Hero Section ======= -->
<style>
    .primary_color {
        background-color: #f2f2f2 !important;
    }

    .secondary_color {
        background-color: #fff3f3 !important;
    }
</style>
<main id="main">
    <section id="hero">
    </section><!-- End Hero -->
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section_mob_view">
        <div class="container" data-aos="fade-up">
            <center>
                <h2 class="text-uppercase my-5"> Member</h2>
            </center>
            <div class="row table-responsive">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>Sr. No.</th>
                            <th>Name of Unit & Address </th>
                            <th>Product & Manufacture</th>
                            <th>Partner / Director </th>
                            <th>Mobile No </th>
                            <th>Phone/Fac./Office/Fax/Email ID </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="6">
                                <center>
                                    <h2 class="text-uppercase my-5"> Raipur</h2>
                                </center>
                            </td>
                        </tr>
                        {{-- row 1  --}}
                        <tr>
                            <td rowspan="2" class="primary_color">1.</td>
                            <td rowspan="2" class="secondary_color">
                                A.C. Strips (P) Ltd
                                <br>
                                <span class="small_text">Shop No. 20, Gate No. 03,
                                    New Cloth Market,
                                    Pandari Raipur (C.G.)</span>
                            </td>
                            <td rowspan="2" class="primary_color">M.S TMT BAR</td>
                            <td class="secondary_color">Mr. Dhiraj Surana</td>
                            <td class="primary_color">
                                9893364000
                            </td>
                            <td class="secondary_color">
                                0771-2582674, 2582574
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr. Dhiraj Surana</td>
                            <td class="primary_color">
                                9893364000
                            </td>
                            <td class="secondary_color">
                                0771-2582674, 2582574
                                <br>
                                <span class="small_text">acstrips@hotmail.com,</span> <br>
                                <span class="small_text">www.acturboTMT.com</span>
                            </td>
                        </tr>
                        {{-- row 2  --}}
                        <tr>
                            <td rowspan="2" class="primary_color">1.</td>
                            <td rowspan="2" class="secondary_color">
                                A.S. Ispat Udyog
                                <br>
                                <span class="small_text">Heerapur, Sondongri Road,
                                    Near Khyati Steel,
                                    Raipur (C.G.)</span>
                            </td>
                            <td rowspan="2" class="primary_color">M.S ANGLE</td>
                            <td class="secondary_color">Mr. Pramesh Agrawal</td>
                            <td class="primary_color">
                                9826145860 <br> 9039015860
                            </td>
                            <td class="secondary_color">
                                0771-6555860 <br> asispatudyog@gmail.com.
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr. Amit Agrawal</td>
                            <td class="primary_color">
                                9039085860
                            </td>
                            <td class="secondary_color">
                                Mr. Pravin 9584212088 a/c
                            </td>
                        </tr>
                        {{--  row 3  --}}
                        <tr>
                            <td rowspan="3" class="primary_color">3.</td>
                            <td rowspan="3" class="secondary_color">
                                A.C. Steels
                                <br>
                                <span class="small_text">Plot No. 71/72 Sector "C" 9993905400
                                    Ural Industrial Area, Urla,
                                    Raipur (C.G.)</span>
                            </td>
                            <td rowspan="3" class="primary_color">MS TMP BAR ROUND MIS</td>
                            <td class="secondary_color">Mr. Rahul Surana</td>
                            <td class="primary_color">
                                9993090000
                            </td>
                            <td class="secondary_color">
                                0771-2326063, 2326529 (Fax)
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr. Rahul Surana</td>
                            <td class="primary_color">
                                9893890000
                            </td>
                            <td class="secondary_color">
                                9993905400
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr. Shreyansh Surana</td>
                            <td class="primary_color">
                                9893890000
                            </td>
                            <td class="secondary_color">
                                www.actmt.in <br> ac_steels@yahoo.com
                            </td>
                        </tr>
                        {{-- row 4  --}}
                        <tr>
                            <td rowspan="2" class="primary_color">4.</td>
                            <td rowspan="2" class="secondary_color">
                                Aditya Steels
                                <br>
                                <span class="small_text">Plot No. 600 A/601
                                    Urla Industrial Area
                                    aipur (C.G.)</span>
                            </td>
                            <td rowspan="2" class="primary_color">M.S FLAT ROUND SQUARE</td>
                            <td class="secondary_color">Mr. Ajay khandelwal</td>
                            <td class="primary_color">
                                9893190000
                            </td>
                            <td rowspan="2" class="secondary_color">
                                adityssteels555@yahoo.com
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr. SUSHANI MOHANTY</td>
                            <td class="primary_color">
                                9893379370 <br> 9993916431
                            </td>
                        </tr>
                        {{-- row 5  --}}
                        <tr>
                            <td rowspan="3" class="primary_color">5.</td>
                            <td rowspan="3" class="secondary_color">
                                Abhilasha Ispat Udyog
                                <br>
                                <span class="small_text">Plot No. 35-36, Rawabhanta,
                                    Industrial Area, Raipur -
                                    493221 (C.G.)</span>
                            </td>
                            <td rowspan="3" class="primary_color">M.S ANGLE
                                H.R STREEP</td>
                            <td class="secondary_color">Mr. Arvind Goenka</td>
                            <td class="primary_color">
                                9425242785 <br>
                                9826828380 <br>
                                8959591000
                            </td>
                            <td class="secondary_color">

                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr. Vivek Sahni</td>
                            <td class="primary_color">
                                9827155000
                                <br> 8120788000
                            </td>
                            <td class="secondary_color" rowspan="2">
                                0771-2326063, 2326529 (Fax) <br>
                                ispat.abhilasha@gmail.com
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr. Abhishek Goenka</td>
                            <td class="primary_color">
                                94255-13144
                            </td>

                        </tr>

                        {{-- row 6  --}}
                        <tr>
                            <td rowspan="3" class="primary_color">6.</td>
                            <td rowspan="3" class="secondary_color">
                                Agrawal Channel
                                Mills Pvt. Ltd.
                                <br>Plot No. 34-35, Growth Centre Industrial State, Phase-II, S
                                iltara, Raipur (C.G.)</span>
                            </td>
                            <td rowspan="3" class="primary_color">M.S ANGLE M.S <br> CHANNEL BILLET </td>
                            <td class="secondary_color">Banke Bihari Agrawal</td>
                            <td class="primary_color">
                                7746877701 <br>
                            </td>
                            <td rowspan="3" class="secondary_color">
                                0771-4052009, <br>
                                admin@acmpl.co.in
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Rakesh Agrawal</td>
                            <td class="primary_color">
                                8461002001
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Pradeep Goyal</td>
                            <td class="primary_color">
                                9993397888
                            </td>
                        </tr>

                        {{-- row 7 --}}
                        <tr>
                            <td rowspan="3" class="primary_color">6.</td>
                            <td rowspan="3" class="secondary_color">
                                Agrawal Round
                                Rolling Mills Ltd.
                                <br>Ralas Motor Side, G. E. Road,
                                Tatibandh, Raipur (C.G.) <br>Agrawal Complex, Opposite.
                                Dr. Pradeep Pandey, Samta
                                Colony, Raipur (C.G.)</span>
                            </td>
                            <td rowspan="3" class="primary_color">M.S ROUND

                                CARBON ROUND

                                HIGH </td>
                            <td class="secondary_color">Mr.Mahesh Agrawal</td>
                            <td class="primary_color">
                                9329126003 <br>
                                9826126003
                            </td>
                            <td  class="secondary_color">
                                0771-4038805, <br>
                                4038805, 4038804
                            </td>
                        </tr>
                        <tr>
                            <td class="secondary_color">Mr.Sushil Agrawal</td>
                            <td class="primary_color">
                                9329622000 <br>
                                9826161102
                            </td>
                            <td class="primary_color">
                                agrawal_round@yahoo.com, <br>
                                www.agrawalround.com
                            </td>
                        </tr>
                       
                    </tbody>
                </table>
            </div>
        </div>
    </section><!-- End Contact Section -->
</main><!-- End #main -->
<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
@include('user.layout.footer')
<!-- End Footer -->
