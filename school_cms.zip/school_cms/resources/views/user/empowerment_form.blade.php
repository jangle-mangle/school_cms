@include('user.layout.header')
<style>
    .banner_img {
        position: relative;
        display: inline-block;
        /* Ensures the div only takes up as much width as needed */
    }

    .text-overlay {
        position: absolute;
        top: 80%;
        /* Adjust as needed */
        left: 10%;
        /* Adjust as needed */
        transform: translate(25%, -50%);
        /* background-color: rgba(255, 255, 255, 0.5); */
        /* Semi-transparent background */
        padding: 10px;
        color: black;
        /* font-size: 18px; */
        text-align: left;
        margin-top: -4px;
    }

    .text-overlay h1 {
        color: #ffffff;
        font-weight: bold;
    }

    .text-overlay p {
        color: #ffffff;
    }

    #about {
        line-height: 2.2;
        font-size: 17px;
    }

    #core-values {
        color: #ffffff;
    }

    #core-values span.heading {
        padding: 10px 30px;
        background: #ff0000;
        border-radius: 2rem;
        margin-bottom: 45px;
    }

    #core-values ul li,
    #core-values p {
        line-height: 2.3;
        margin-top: 20px;
    }

    .leadership_team_btn a {
        font-size: 21px;
        padding: 10px 40px;
        border: 1px solid #000;
        border-radius: 2rem;
        color: #000000;
    }

    .leadership_team_btn .row-icon {
        font-size: 40px;
        margin-left: 15px;
    }

    .form-control { border-radius: 20px; border: 1px solid #bebebe; }
    .btn-default { border: 1px solid #b8b8b8; background: #ddd; border-radius: 20px; }
</style>
<!-- ======= Hero Section ======= -->
<main id="main">
    <section id="hero">
        <img class="banner_img" src="{{ asset('assets/img/empowerment.jpg') }}" alt="">
    </section><!-- End Hero -->
    <section>
        <div class="container">
            <form action="">
                <div class="row">
                    <div class="offset-lg-1 col-lg-2 text-end fw-bold">
                        <label for="">Full Name</label>
                    </div>
                    <div class="col-lg-7">
                        <input type="text" class="form-control">
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="offset-lg-1 col-lg-2 text-end fw-bold">
                        <label for="">Email ID</label>
                    </div>
                    <div class="col-lg-7">
                        <input type="text" class="form-control">
                        <small>example@example.com</small>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="offset-lg-1 col-lg-2 text-end fw-bold">
                        <label for="">Phone</label>
                    </div>
                    <div class="col-lg-7">
                        <input type="text" class="form-control">
                        <small>Phone Number</small>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="offset-lg-1 col-lg-2 text-end fw-bold">
                        <label for="">Address</label>
                    </div>
                    <div class="col-lg-7">
                        <input type="text" class="form-control">
                        <small>Street Address</small>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="offset-lg-1 col-lg-2 text-end fw-bold">
                        
                    </div>
                    <div class="col-lg-7">
                        <input type="text" class="form-control">
                        <small>Street Address Line 2</small>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="offset-lg-1 col-lg-2 text-end fw-bold">
                        
                    </div>
                    <div class="col-lg-3">
                        <input type="text" class="form-control">
                        <small>city</small>
                    </div>
                    <div class="col-lg-3">
                        <input type="text" class="form-control">
                        <small>Postal Zip Code</small>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="offset-lg-1 col-lg-2 text-end fw-bold">
                        <label for="">Upload Resume</label>
                    </div>
                    <div class="col-lg-3">
                        <input type="file" class="form-control">
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="offset-lg-3 col-lg-3">
                        <button type="button" class="button btn btn-default">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </section>
</main><!-- End #main -->
<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
@include('user.layout.footer')
<!-- End Footer -->

<script>
    const imgs = document.querySelectorAll(".img-select a");
    const imgBtns = [...imgs];
    let imgId = 1;

    imgBtns.forEach((imgItem) => {
        imgItem.addEventListener("click", (event) => {
            event.preventDefault();
            imgId = imgItem.dataset.id;
            slideImage();
        });
    });

    function slideImage() {
        const displayWidth = document.querySelector(
            ".img-showcase img:first-child"
        ).clientWidth;

        document.querySelector(".img-showcase").style.transform = `translateX(${
        -(imgId - 1) * displayWidth
    }px)`;
    }

    window.addEventListener("resize", slideImage);
</script>
