@include('user.layout.header')

<!-- ======= Hero Section ======= -->

    <main id="main">

        <section id="hero">
            <img class="banner_img" src="{{asset('assets/img/home/banner_1.jpg')}}" alt="">
        </section><!-- End Hero -->
        <!-- ======= About Section ======= -->
        <section id="about" class="about section_mob_view">
            <div class="container px-lg-5" data-aos="fade-up">

                <div class="row align-items-center">
                    <h1 class="">About CSRA</h1>
                    <small>
                        <p>Chhattisgarh Steel Re-Rollers Association (CSRA) is an organization that has been dedicated
                            to enhancing the Steel Re-Rolling business
                            opportunities for its members since its inception in the year 1981. Registered under the
                            Societies Registration Act 1860, CSRA is
                            located in the vibrant city of Raipur, in the state of Chhattisgarh.</p>
                    </small>
                </div>
            </div>
        </section><!-- End About Section -->



        <!-- ======= Our Product Section ======= -->
        <section id="our_service" class="our_service"
            style="background: url('{{asset('assets/img/Aditya_steel/banner.png')}}">
            <div class="container py-lg-5 py-3" data-aos="fade-up">
                <center>
                    <h1 class="text-black text-uppercase">Our Product</h1>
                </center>
                <div class="row justify-content-center my-lg-4">
                    <div class=" col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="tmt-bars.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/04.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">TMT Bars</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">Our TMT
                                        bars are made with high-quality raw materials and undergo a
                                        rigorous TMT process, resulting in bars that are strong, durable, and
                                        long-lasting.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class=" col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="ms-billets.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/05.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">MS Billets</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">Our MS
                                        billets are made with consistent quality and precision, ensuring
                                        that they meet the highest standards.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="sponge-iron.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/06.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Sponge Iron</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">Our sponge
                                        iron is made with a unique process that produces a
                                        high-quality product with low impurities.</p>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class=" col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="ms-wire-rod.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/07.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">MS Wire Rod</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">Our MS wire
                                        rods are made with high-quality steel and undergo a
                                        rigorous cold-drawing process, resulting in rods that are strong, ductile, and
                                        corrosion-resistant.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center my-lg-4">
                    <div class=" col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="silico-maganese.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/08.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Silico Manganese</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">Our silico
                                        manganese is made with high-quality manganese ore and is
                                        processed using state-of-the-art technology, resulting in a product that is
                                        consistent
                                        and reliable</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="pig-iron.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/09.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Pig Iron</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">Our pig
                                        iron is made with high-quality iron ore and is processed using
                                        a traditional method, resulting in a product that is strong and durable.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="fly-ash-brick.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/07.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Fly Ash Brick</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">In the
                                        ever-evolving world of construction, the demand for top-tier quality building
                                        materials is at an all-time high.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 d-flex align-items-stretch my-lg-0 my-2">
                        <div class="card">
                            <a href="fly-ash-brick.html">
                                <img class="card-img-top img-fluid" src="{{asset('assets/img/Aditya_steel/09.png')}}"
                                    alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title text-dark">Fly Ash Brick</h5>
                                    <p class="card-text our_product_para text-dark" style="font-size: 14px;">In the
                                        ever-evolving world of construction, the demand for top-tier quality building
                                        materials is at an all-time high.</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </section><!-- End Our Product Section -->

        <section id="gallary" class="gallary mb-0">
            <div class="container py-3" data-aos="fade-up">
                <center>
                    <h1 class="text-black text-uppercase">GALLERY</h1>
                </center>
                <div class="row align-items-center">
                    <div class="wrap">
                        <div class="slider">

                            <div class="item">
                                <img src="{{asset('assets/img/Aditya_steel/gallery-01.png')}}" alt="">
                            </div>
                            <div class="item">
                                <img src="{{asset('assets/img/Aditya_steel/gallery-02.png')}}" alt="">
                            </div>
                            <div class="item">
                                <img src="{{asset('assets/img/Aditya_steel/gallery-03.png')}}" alt="">
                            </div>
                            <div class="item">
                                <img src="{{asset('assets/img/Aditya_steel/gallery-02.png')}}"
                                    alt="">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ======= Our Product Section ======= -->
        <section id="our_service" class="our_service mt-0"
            style="background: url('{{asset('assets/img/Aditya_steel/banner._1.png')}}">
            <div class="container py-3" data-aos="fade-up">
                <center>
                    <h1 class="text-light text-uppercase">LEADERSHIP TEAM</h1>
                </center>
                <div class="row justify-content-center my-lg-4">
                    <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2 mx-4">
                        <div>
                            <img src="{{asset('assets/img/Aditya_steel/leadership-01.png')}}" class="img-fluid rounded-circle"
                                alt="" style="width: 12rem;">
                            <div class="my-2">
                                <p style="font-size: 11px;" class="my-0 text-light">ounder / Chairman
                                </p>
                                <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Rajat
                                    Agrawal
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2 mx-4">
                        <div>
                            <img src="{{asset('assets/img/Aditya_steel/leadership-02.png')}}" class="img-fluid rounded-circle"
                                alt="" style="width: 12rem;">
                            <div class="my-2">
                                <p style="font-size: 11px;" class="my-0 text-light">
                                    Director
                                </p>
                                <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Aditya
                                    Agrawal
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 text-center my-0 leaders p-2 mx-4">
                        <div>
                            <img src="{{asset('assets/img/Aditya_steel/leadership-03.png')}}" class="img-fluid rounded-circle"
                                alt="" style="width: 12rem;">
                            <div class="my-2">
                                <p style="font-size: 11px;" class="my-0 text-light">Director
                                </p>
                                <p style="font-size: 13px;" class="my-0 text-white text-capitalize fw-bold">Mr. Raj
                                    Agrawal
                                </p>

                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </section><!-- End Our Product Section -->

        <section>
            <div class="row mt-5 align-items-center">
                <div class="col-lg-6 contact_form">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59474.46661582552!2d81.54041034485147!3d21.3049239247607!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a28e72f7f16ad0f%3A0xfb581ba2433b6efb!2sUrla%20Industrial%20Complex%2C%20Birgoan%2C%20Raipur%2C%20Chhattisgarh%20492003!5e0!3m2!1sen!2sin!4v1702830455496!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class="col-lg-4 offset-lg-2">
                    <h5 class="fw-bold">Contact info :</h5>
                    <div class="info">
                        <div class="address">
                            <h6 class="fw-bold">Corporate Office:</h6>
                            <p>31-32, Urla Industrial Area, Urla,
                                Raipur-Chhattisgarh - 492003
                                (Sector C)</p>
                        </div>
                        <hr>
                        <div class="phone">
                            <h6 class="fw-bold">Contact Us</h6>
                            <p>+91 79426 97829</p>
                        </div>
                        <hr>
                        <div class="email">
                            <p><span class="fw-bold">Email - </span>
                                info@adityasteel.com</p>
                            <p><span class="fw-bold">Website - </span>
                               www:adityasteel.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>




    </main><!-- End #main -->

<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
@include('user.layout.footer')

<!-- End Footer -->