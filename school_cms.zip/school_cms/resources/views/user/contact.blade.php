@include('user.layout.header')

<!-- ======= Hero Section ======= -->

    <main id="main">
        <section id="hero">
            <img class="banner_img" src="{{asset('assets/img/Contact/contact-bg.jpg')}}" alt="">
           
        </section><!-- End Hero -->
        <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact section_mob_view">
            <div class="container" data-aos="fade-up">
                <div class="row mt-5 mx-lg-5">
                    <div class="col-lg-6 offset-lg-1 mt-5 mb-3 mt-lg-0 contact_form">
                        <form method="post" role="form" class="contact_us_form">
                            <input type="hidden" name="_token" value="{{csrf_token()}}">
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Name"
                                        required>
                                </div>
                            </div>
                            <div class="form-group mt-3">
                                <input type="text" class="form-control" name="subject" id="subject"
                                    placeholder="Subject" required>
                            </div>
                            <div class="form-group mt-3">
                                <textarea class="form-control" name="message" rows="3" placeholder="Message"
                                    required></textarea>
                            </div>

                            <div class=""><button type="submit" class="btn btn-primary my-3">Send Message</button></div>
                        </form>
                        <div class="my-5 fw-bold">
                            Join us in strengthening the steel re-rolling industry in Chhattisgarh and
                            be a part of CSRA's journey to prosperity and sustainability. Together, we
                            build relationships stronger than steel!
                        </div>
                    </div>
                    <div class="col-lg-4 offset-lg-1">
                        <div class="info">
                            <div class="address">
                                <h6>Corporate Office:</h6>
                                <p>1st Floor, Sona Tower, <br> Ramsagar Para, Raipur, C.G.-492001</p>
                            </div>
                            <div class="email">
                                <h6>Email Us</h6>
                                <p>office.cgsra@gmail.com</p>
                                <p>cgsra@rediffmail.com</p>
                            </div>
                            <div class="phone">
                                <h6>Call Us</h6>
                                <p>0771-2292732, 4017502</p>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </section><!-- End Contact Section -->


        <section id="contact" class="contact">
            </div>
            </div>
            <div data-aos="fade-up" class="mt-3">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3718.590300852905!2d81.62619317439348!3d21.248088980211012!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a28dd9438392e7f%3A0xf0e0332881332dd8!2sRamsagar%20Para%2C%20Jawahar%20Nagar%2C%20Raipur%2C%20Chhattisgarh!5e0!3m2!1sen!2sin!4v1702812446557!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section><!-- End Contact Section -->
    </main><!-- End #main -->

<!-- ======= Footer ======= -->
<!-- ======= Footer ======= -->
@include('user.layout.footer')

<!-- End Footer -->