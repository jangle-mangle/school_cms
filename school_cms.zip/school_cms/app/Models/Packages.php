<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Packages extends Model
{
    use HasFactory;

   protected $table = 'packages';
   protected $fillable = [
        'id',
        'title',
        'place',
        'days',
        'price',
        'discount_price',
        'sdescription',
        'ldescription',
        'image'=>'required|image|mimes:jpeg,jpg,png,bmp,gif,svg',
        'thumbnail_image'=>'required|image|mimes:jpeg,jpg,png,bmp,gif,svg',

    ];
}
