<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hotels extends Model
{
    use HasFactory;

   protected $table = 'hotels';
   protected $fillable = [
        'id',
        'title',
        'location',
        'short_description',
        'long_description',
        'rating',
        'status',
        'thumbnail_image'=>'required|image|mimes:jpeg,jpg,png,bmp,gif,svg',

    ];
}
