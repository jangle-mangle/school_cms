<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\CommonController as commonObj;
use Intervention\Image\ImageManagerStatic as Image;
use Illuminate\Http\Request;
use App\Models\ContactUs;
use Validator;
use Auth;
use DB;
use File;

class ContactUsController extends Controller
{
    // private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    //     $this->commonObj = new commonObj();
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 


    public function index()
    {
        $data = DB::table('career')->where('status', 'Active')->orderBy('id', 'desc')->get();
        dd($data);
        return view('admin.contact_us',['careers'=>$data]);
    }

    public function uploadThumbnail(Request $request)
    {
        if ($file = $request->file('file'))
        {
            $ext = $request->file('file')->getClientOriginalExtension();
            $imgName = date('ymdhis').'_THUMBNAIL.'.$ext;

            $request->file->storeAs('public/albums/thumbnail_image', $imgName);

            $data = $imgName;

            return response()->json([
                "success" => true,
                "file" => $data
            ]);
        }
        else
        {
            return response()->json([
                "success" => false
            ]);
        }
    }

    public function uploadGalleryImages(Request $req)
    {
        $data = [];

        if($req->hasfile('file')) {
            foreach($req->file('file') as $file)
            {
                $ext = $file->getClientOriginalExtension();
                $imgName = rand(1000, 9999).date('ymdhis').'_image.'.$ext;

                $file->storeAs('public/albums/gallery_image/', $imgName);

                $data[] = $imgName;
            }

            return response()->json([
                "success" => true,
                'files' => $data
            ]); 
        }      
    }



    public function post(Request $request)
    {   
        // dd($request->all());
        $validator = Validator::make($request->all(), 
            [ 
              'name' => 'required',
              'email' => 'required',
              'message' => 'required' 
            ]);

        if ($validator->fails()) {
            return response()->json([
                'message'   => $validator->errors()->first(),
                'error' => true
            ]);
        }
        else
        {
            $post = new ContactUs;
            $post->name = $request->name;         
            $post->email = $request->email;         
            $post->message = $request->message;
            $post->mobileno = isset($request->mobileno)?$request->mobileno:NULL;
            $post->website = isset($request->website)?$request->website:NULL;

            $add = $post->save();         
            // $response = DB::table('albums')->insertGetId($data);

            if($add)
            {
                $result = [ 'status' => true, 'message' => "Form Submitted Succesfully" ];
            }
            else
            {
                $result = [ 'status' => false, 'message' => "Something went wrong, try again later !" ];
            }
        }
        return response()->json($result);
    }


    public function update(Request $request)
    {   
        $validator = Validator::make($request->all(), 
        [ 
          'album_name' => 'required',
          'album_category' => 'required',
          'position' => 'required|numeric|min:1',  
          'description' => 'nullable|max:300',  
        ]);

        if ($validator->fails()) {
             return response()->json([
               'message'   => $validator->errors()->first(),
               'error' => true
              ]);
        }

        $album = DB::table('albums')->where('id', $request->id)->first();

        if($request->thumbnail_image!=$album->thumbnail_image)
        {
            $data = [
                'name' => $request->album_name,
                'category' => $request->album_category,
                'position' => $request->position,
                'description' => $request->description,
                'thumbnail_image' => $request->thumbnail_image,
                'updated_at' => date('Y-m-d h:i:s'),
            ];
        }
        else
        {
            $data = [
                'name' => $request->album_name,
                'category' => $request->album_category,
                'position' => $request->position,
                'description' => $request->description,
                'updated_at' => date('Y-m-d h:i:s'),
            ];
        }
             
        $response = DB::table('albums')->where('id', $request->id)->update($data);

        if ($response > 0) {

            if (is_array($request->images)) {
                $this->multipleGalleryImageUpload($request->images, $request->id);
            }
            if (is_array($request->gallery_videos_link)) {
                $this->galleryLinkUpload($request->gallery_videos_link, $request->id);
            }
            return response()->json(['error' => false, 'message' => 'Album Updated Succesfully!'], 200);
        }

        return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
    }

    private function multipleGalleryImageUpload($files, $album_id)
    {
        $response = 0;

        foreach ($files as $photo)
        {     

            $imageData = [
                'image' => $photo,
                'folder' => 'albums/gallery_image', 
                'album_id' => $album_id,
                'this_for' => 'Album Image', 
                'created_at' => date('Y-m-d H:i:s')
            ];
            $response = DB::table('image_files')->insertGetId($imageData);
        }
        return $response;
    }
    


    public function data(Request $request){

        $data = DB::table('career')->where('status', 'Active')->orderBy('id', 'desc')->get();

        return datatables()->of($data)->addColumn('id', function ($data) {
            return  $data->id;

        })->addColumn('email', function ($data) {
        return  $data->email;

        })->addColumn('name', function ($data) {
        return  $data->name; 

        })->addColumn('contact', function ($data) {
        return  $data->contact; 

        })->addColumn('job_post', function ($data) {
        return  $data->post_id; 

        })->addColumn('status', function ($data) {
            if ($data->status == 'Active') {
                return '<span class="badge badge-light-info">Active</span>';
            }
            return '<span class="badge badge-light-danger">In-Active</span>';

        })->addColumn('resume', function ($data) {
            $resume = isset($data->resume)? $data->resume : '';
            return $resume;
        })->rawColumns(['contact', 'status', 'name', 'email', 'id', 'resume','job_post'])->make(true);

    }



    
    public function delete_gallery_image(Request $request){


        $response=DB::table('image_files')->where('this_for', 'Album Image')->where('id', $request->id)->delete();

        if ($response > 0) {

            return response()->json(['error' => false, 'message' => 'Deleted Succesfully!'], 200);

        }
        return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
    }

    public function status(Request $request){

        $data = [];

        if ($request->status == 'enable') {
          $data = ['is_active'=>'Yes', 'updated_at' => date('Y-m-d H:i:s')];
        }
        elseif($request->status == 'disable'){
           $data = ['is_active'=>'No', 'updated_at' => date('Y-m-d H:i:s')];
        }
        elseif($request->status == 'delete'){
           $data = ['is_active'=>'No', 'updated_at' => date('Y-m-d H:i:s'), 'deleted_at' => date('Y-m-d H:i:s')];
        }

        $result = DB::table('albums')->where('id',$request->id)->update($data);

        if ($result > 0) {

            if($request->status == 'delete'){
                return response()->json(['error' => false, 'message' => 'Album Deleted Succesfully!'], 200);
            }

            return response()->json(['error' => false, 'message' => 'Status Updated Succesfully!'], 200);

        } else {
             return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
        }
    }

    public function get(Request $request){
        
        $albums = DB::table('albums')->where('id', $request->id)->first();

        if ($albums) {

            $albums->thumbnail_image_with_url = url("storage/albums/thumbnail_image/").'/'.$albums->thumbnail_image;
            $data['albums'] = $albums;

            $images = DB::table('image_files')->where('album_id', $albums->id)->get();

            $files = [];

            foreach ($images as $image) {

                $image->image_with_url = ($image->this_for == 'Album Image') ? url("storage/$image->folder/$image->image") : NULL ;
                array_push($files, $image);
            }

            $data['files'] = $this->commonObj->convertToObject($files);

            if (count($data) > 0) {
                return response()->json(['error' => false, 'message' => 'Data Found', 'data' => $data]);
            } 
        }
        return response()->json(['error'=> true, 'message' => 'Data Not Found!']);
    }

    private function isValidImageFile($files = [])
    {
        //allowed image type of product images.
        $allowedFileExt = ['jpg','png', 'jpeg', 'GIF', 'gif', 'bmp', 'pjpeg'];

        if (!empty($files) && is_array($files)) {

            foreach ($files as $file) {

                $extension = $file->getClientOriginalExtension();

                if(!in_array($extension, $allowedFileExt)) 
                    return false;
            }
            return true;
        }elseif (!empty($files)) {

            $extension = $files->getClientOriginalExtension();
           
            return (in_array($extension, $allowedFileExt)) ? true : false ;

        }
        return false;
    }

    
    private function galleryLinkUpload($links, $album_id){

        $response = 0;

        //delete the previous links.
        $response=DB::table('image_files')->where('this_for', 'Album Video Link')->where('album_id', $album_id)->delete();

        //If product have extra image for display.
        foreach ($links as $link) {      
            
            if (isset($link)) {
                $imageData = [
                            'link' => $link,
                            'album_id' => $album_id,
                            'this_for' => 'Album Video Link', 
                            'created_at' => date('Y-m-d H:i:s')
                        ];
                $response = DB::table('image_files')->insertGetId($imageData);
            }
            
        }
        return $response;
    }

    private function galleryImageUpload($files, $album_id, $album_title = ''){

        $response = 0;
        $i = 0;

        //delete the previous image files.
        // if ($action == 'auto') {
        //     $response = DB::table('image_files')->where('image_for', 'Product')->where('refrance_id', $product_id)->delete();
        // }

        //Make directory, If doesn't exist.
        $targetDir = storage_path('/app/public/albums/gallery_image');
        if (!(File::isDirectory($targetDir))) {

            File::makeDirectory($targetDir, 0777, true, true);
        }

        //If product have extra image for display.
        foreach ($files as $mediaFile) {      
            
            $extension = $mediaFile->extension();
            $file_name=date('ymdhis')."_".str_replace(' ', '_', strtoupper($album_title))."_$i.$extension";
            // $file_name = date('ymdhis').'_'.$mediaFile->getClientOriginalName();
            
            $mediaFile->move($targetDir, $file_name);
            
            $imageData = [
                        'image' => $file_name,
                        'folder' => 'albums/gallery_image', 
                        'album_id' => $album_id,
                        'this_for' => 'Album Image', 
                        'created_at' => date('Y-m-d H:i:s')
                    ];
            $response = DB::table('image_files')->insertGetId($imageData);
            $i++;
        }
        return $response;
    }
}
