<?php

namespace App\Http\Controllers\User;

use App\Models\ExecutiveMember;
use App\Models\Role;
use DB;
use Auth;
use Illuminate\Http\Request;
use Psy\CodeCleaner\ReturnTypePass;
use Validator;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function index(Request $request)
    {
        $title = 'Homepage';
        return view('user.homepage', compact('title'));
    }

    public function index1(Request $request)
    {
        $title = 'Homepage';
        return view('user.index', compact('title'));
    }

    public function about(){
        $title = 'About';
        return view('user.about', compact('title'));
    }

    public function executive_member(Request $request)
    {
        $title = 'Executive Member';
        $roles = Role::with('members')->get();
        $tableData = '';
        // if (!$roles->isEmpty()) {
        //     foreach ($roles as $role) {
                $members = DB::select("SELECT e.*, r.name as role_name FROM executive_member e LEFT JOIN roles r ON r.id = e.role");
                if ($members) {
                    $countRows = 0;
                    foreach ($members as $member) {
                        $tableData .= '<tr>';
                        $tableData .= '<td width="" style="vertical-align: middle;">
                            <span style="display: inline-block; float: left;"><img src="' . asset("uploads/executive-members/" . $member->photo) . '" style="width: 100px;"></span>
                            <span style="display: inline-block;">
                            <h6 class="fw-bold">' . $member->name . '</h6>
                            <p>' . $member->role_name . '</p>
                            </span>
                        </td>';
                        $tableData .= '<td style="">' . $member->phone . '</td>';
                        $tableData .= '<td class="fw-bold">' . $member->company . '</td>';
                        $tableData .= '</tr>';
                    }
                }
        //     }
        // }
        return view('user.executive_member', compact('title', 'tableData'));
    }
    public function member(Request $request)
    {
        $title = 'Member';
        return view('user.member', compact('title'));
    }
    public function aditya_steel(Request $request)
    {
        $title = 'Aditya Steel';
        return view('user.aditya_steel', compact('title'));
    }
    public function contact(Request $request)
    {
        $title = 'Contact Us';
        return view('user.contact', compact('title'));
    }
    public function activities(Request $request)
    {
        $title = 'Activities';
        return view('user.activities', compact('title'));
    }



    public function contact_us(Request $request)
    {

        $data = [
            'name' => $request->name,
            'subject' => $request->subject,
            'message' => $request->message
        ];
        if (DB::table('contact_us')->insert($data)) {
            return response()->json(['status' => true, 'message' => 'Form submitted successfully!']);
        }
        return response()->json(['status' => true, 'message' => 'Something went wrong, please try again later!']);
    }

    public function join_our_team(Request $request)
    {
        $file = NULL;
        if ($request->hasFile('resume')) {
            $image = $request->file('resume');
            $name = time() . '.' . $image->getClientOriginalExtension();
            $destinationPath = public_path('/resume');
            $image->move($destinationPath, $name);
            $file = $name;
        }

        $data = [
            'name' => $request->name,
            'email' => $request->Email,
            'phone' => $request->Phone,
            'message' => $request->message,
            'resume' => $file
        ];
        if (DB::table('join_our_team')->insert($data)) {
            return response()->json(['status' => true, 'message' => 'Form submitted successfully!']);
        }
        return response()->json(['status' => true, 'message' => 'Something went wrong, please try again later!']);
    }

    public function empowerment_form(){
        $title = 'Form';
        return view('user.empowerment_form', compact('title'));
    }
}
