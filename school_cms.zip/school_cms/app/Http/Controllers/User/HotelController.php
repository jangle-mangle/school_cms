<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Validator;
use Auth;
use DB;

class HotelController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        $data['hotel_details'] = DB::table('hotels')->where('id',$request->id)->first();
        $data['all_hotels'] = DB::table('hotels')->where('status','Active')->get();

        return view('user.hotel_details')->with($data);
    }

     

}
