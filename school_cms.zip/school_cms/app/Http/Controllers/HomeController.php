<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CommonController as commonObj;
use Illuminate\Http\Request;
use Validator;
use Auth;
use DB;
use Illuminate\Support\Arr;

class HomeController extends Controller
{
    private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->commonObj = new commonObj();
    }
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('admin.dashboard');
    }
    //   =========================================COMMON SAVE DATA  ===================================
    public function upload_img($data,$folder_name)
    {
        if ($data->hasFile('img')) {
            $image = $data->file('img');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/'), $imageName);

           $data['img'] = $imageName   ;
        }
    }



    public function insert_update_common($id='', $form_data,$table_name)
    {
        $data = Arr::except($form_data, ['_token']);
        $isBanner = DB::table($table_name)->where('id',$data['id'])->first() ; 
        if (isset($isBanner)) {
            $data['img'] =  $isBanner->img ; 
            $save = DB::table($table_name)->where('id',$isBanner->id)->update($data) ; 
            if ($save) {
                return true ; 
            }
            else { 
                return false ; 
            }
        }
        else { 
            $save = DB::table($table_name)->insert($data) ; 
            if ($save) {
                return true ; 
            }
            else { 
                return false ; 
            }
        }
    }
    public function delete_common($table_name ,$id)
    {
        $isDeleted = DB::table($table_name)->where('id',$id)->delete() ; 
        if ($isDeleted) {
            return true ; 
        }
        else { 
            return false ;  
        }
    }
    

//   =========================================START BANNER SECTION ===================================
    public function banner_page()
    {
        $data = DB::table('banner')->get(); 
        return view('admin.banner.banner')->with('banners',$data);
    }

    public function add_banner(Request $request)
    {
        $form_data = $request->all() ; 
        if ($request->hasFile('img')) {
            $image = $request->file('img');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/banner'), $imageName);

           $form_data['img'] = $imageName   ;
        }
        else { 
            $img_name = DB::table($table_name)->where('id',$form_data['id'])->value('img') ;
            $form_data['img'] = $img_name   ;
        }
        $isBanner = $this->insert_update_common($form_data['id'],$form_data,'banner');
        if ($isBanner) {
            return redirect('admin/admin-page-banner')->with(['status'=>true, 'message'=> 'Operations successfully']); 
        }
        else { 
            return redirect('admin/admin-page-banner')->with(['status'=>false, 'message'=> 'Something went wrong']); 
        }
        
    }
    public function delete_banner($id)
    {
        $isDeleted = $this->delete_common('banner',$id) ; 
        if ($isDeleted) {
            return redirect('admin/admin-page-banner')->with(['status'=>true, 'message'=> 'Operations successfully']); 
        }
        else { 
            return redirect('admin/admin-page-banner')->with(['status'=>false, 'message'=> 'Something went wrong']); 
        }
    }

    // =========================================END BANNER SECTION ===================================
   
   
   
    // =========================================START TITLE SECTION ===================================
    public function event_page()
    {
        $data = DB::table('events')->get(); 
        return view('admin.event.index')->with('events',$data);
    }

    public function add_event(Request $request)
    {
        $form_data = $request->all() ; 
        if ($request->hasFile('img')) {
            $image = $request->file('img');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads/banner'), $imageName);

           $form_data['img'] = $imageName   ;
        }
        else { 
            $img_name = DB::table($table_name)->where('id',$form_data['id'])->value('img') ;
            $form_data['img'] = $img_name   ;
        }
        $isSubmit = $this->insert_update_common($form_data['id'],$form_data,'events');
        if ($isSubmit) {
            return redirect('admin/admin-page-event')->with(['status'=>true, 'message'=> 'Operations successfully']); 
        }
        else { 
            return redirect('admin/admin-page-event')->with(['status'=>false, 'message'=> 'Something went wrong']); 
        }
        
    }
    public function delete_event($id)
    {
        $isDeleted = $this->delete_common('banner',$id) ; 
        if ($isDeleted) {
            return redirect('admin/admin-page-banner')->with(['status'=>true, 'message'=> 'Operations successfully']); 
        }
        else { 
            return redirect('admin/admin-page-banner')->with(['status'=>false, 'message'=> 'Something went wrong']); 
        }
    }
    // =========================================END TITLE SECTION ===================================




     

}
