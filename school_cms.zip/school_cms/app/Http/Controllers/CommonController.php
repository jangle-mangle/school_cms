<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use File;
use Validator;
use Illuminate\Support\Facades\Session;


class CommonController extends Controller
{
    public function convertToObject($array) {
        $object = new \stdClass();
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $value = $this->convertToObject($value);
            }
            $object->$key = $value;
        }
        return $object;
    }

    public function getLabels(Request $request)
    {
        $labelData = DB::table('labels')->select('id', 'name')->where('is_active', 'Yes')
            ->orderBy('position' ,'asc')->get();

        $labels = [];
        foreach ($labelData as $label) {
            $dump = [];
            $dump['id'] = $label->id;
            $dump['name'] = $label->name;
            $dump['count'] = DB::table('deals')->where('label',$label->name)->where('status', 'Pending')->where('is_active','Yes')->count();
            array_push($labels, $dump);
            $dump = [];
        }
        // $labels = $this->convertToObject($labels);

        return json_encode($labels);
    }

     public function Requirment()
    {
        return view('req');
    }
    
    

      public function req_add(Request $request)
    {   
        
       
            $data = [
                'email' => $request->username,
                'name' => $request->name,
                'mobile' => $request->mobile,
                'vanue' => $request->venue,
                'wedding_date' => $request->date,
                // 'created_at' => date('Y-m-d h:i:s'),
            ];

               
            $response = DB::table('req_user')->insertGetId($data);
           
           if ($response > 0)
           {

            $decoration = [
                'req_id' => $response,
                'mehandi_setup' => $request->mehandi_setup,
                'mehandi_setup_detail' => $request->mehandi_setup_detail,
                'hadli_setup' => $request->hadli_setup,
                'hadli_setup_detail' => $request->hadli_setup_detail,

                'sangeet_stage' => $request->sangeet_stage,
                'sangeet_stage_detail' => $request->sangeet_stage_detail,
                'reception_stage' => $request->reception_stage,
                'reception_stage_detail' => $request->reception_stage_detail,
                
                'entry_venue' => $request->entry_venue,
                'entry_venue_detail' => $request->entry_venue_detail,
                'bride_man_decoration' => $request->bride_man_decoration,
                'bride_man_decoration_detail' => $request->bride_man_decoration_detail,
                

                'groom_man_decoration' => $request->groom_man_decoration,
                'groom_man_decoration_detail' => $request->groom_man_decoration_detail,
                'food_cou_setup' => $request->food_cou_setup,
                'food_cou_setup_detail' => $request->food_cou_setup_detail,

                'vip_lounge' => $request->vip_lounge,
                'vip_lounge_detail' => $request->vip_lounge_detail,
                'sajan_kot' => $request->sajan_kot,
                'sajan_kot_detail' => $request->sajan_kot_detail,

                 'selfie_booth' => $request->selfie_booth,
                'selfie_booth_detail' => $request->selfie_booth_detail,
            ];



            $d_response = DB::table('req_deocration')->insert($decoration);

             $mehandi = [
                'req_id' => $response,
                'mehandi_artist' => $request->mehandi_artist,
                'detail_mehandi_artist' => $request->detail_mehandi_artist,
                'mehandi_dhol_boy' => $request->mehandi_dhol_boy,
                'mehandi_dhol_boy_detail' => $request->mehandi_dhol_boy_detail,

                'nail_tattoo' => $request->nail_tattoo,
                'detail_nail_tattoo' => $request->detail_nail_tattoo,
                'mehandi_entertainment' => $request->mehandi_entertainment,
                'mehandi_entertainment_detail' => $request->mehandi_entertainment_detail,

                'mehandi_sound_dj' => $request->mehandi_sound_dj,
                'mehandi_sound_dj_detail' => $request->mehandi_sound_dj_detail,
            ];



            $m_response = DB::table('req_mehandi')->insert($mehandi);

             $haldi = [
                'req_id' => $response,
                'flower_shower' => $request->flower_shower,
                'flower_shower_detail' => $request->flower_shower_detail,
                'hadli_dhol_boy' => $request->hadli_dhol_boy,
                'hadli_dhol_boy_detail' => $request->hadli_dhol_boy_detail,

                'haldi_props' => $request->haldi_props,
                'haldi_props_detail' => $request->haldi_props_detail,
                'haldi_entry' => $request->haldi_entry,
                'haldi_entry_detail' => $request->haldi_entry_detail,

                'color_bomb' => $request->color_bomb,
                'color_bomb_detail' => $request->color_bomb_detail,
                'haldi_sound_dj' => $request->haldi_sound_dj,
                'haldi_sound_dj_detail' => $request->haldi_sound_dj_detail,

                'haldi_colors' => $request->haldi_colors,
                'haldi_colors_detail' => $request->haldi_colors_detail,
            ];



            $h_response = DB::table('req_haldi')->insert($haldi);
            

             $sangeet = [
                'req_id' => $response,
                'sangeet_light' => $request->sangeet_light,
                'sangeet_light_detail' => $request->sangeet_light_detail,
                'sangeet_dj_sound' => $request->sangeet_dj_sound,
                'sangeet_dj_sound_detail' => $request->sangeet_dj_sound_detail,

                'sangeet_anchor' => $request->sangeet_anchor,
                'sangeet_anchor_detail' => $request->sangeet_anchor_detail,
                'sangeet_choreography' => $request->sangeet_choreography,
                'sangeet_choreography_detail' => $request->sangeet_choreography_detail,

                'sangeet_bg_entry' => $request->sangeet_bg_entry,
                'sangeet_bg_entry_detail' => $request->sangeet_bg_entry_detail,

                'sangeet_paper_blast' => $request->sangeet_paper_blast,
                'sangeet_paper_blast_detail' => $request->sangeet_paper_blast_detail,
                'sangeet_cold_pyro' => $request->sangeet_cold_pyro,
                'sangeet_cp_detail' => $request->sangeet_cp_detail,

                'sangeet_led_wall' => $request->sangeet_led_wall,
                'sangeet_led_wall_detail' => $request->sangeet_led_wall_detail,
                'sangeet_back_dancer' => $request->sangeet_back_dancer,
                'sangeet_back_dancer_detail' => $request->sangeet_back_dancer_detail,

                'sangeet_co2_blast' => $request->sangeet_co2_blast,
                'sangeet_co2_blast_detail' => $request->sangeet_co2_blast_detail,
                'sangeet_fire' => $request->sangeet_fire,
                'sangeet_fire_detail' => $request->sangeet_fire_detail,

                'sangeet_entry' => $request->sangeet_entry,
                'sangeet_entry_detail' => $request->sangeet_entry_detail,
            ];



            $san_response = DB::table('req_sangeet')->insert($sangeet);
            
             $barat = [
                'req_id' => $response,
                'barat_dhumal' => $request->barat_dhumal,
                'barat_dhumal_detail' => $request->barat_dhumal_detail,
                'barat_dhol' => $request->barat_dhol,
                'barat_dhol_detail' => $request->barat_dhol_detail,

                'barat_saja' => $request->barat_saja,
                'barat_saja_detail' => $request->barat_saja_detail,
                'barat_fire_crack' => $request->barat_fire_crack,
                'barat_fire_crack_detail' => $request->barat_fire_crack_detail,

                'barat_vinatge_car' => $request->barat_vinatge_car,
                'barat_vinatge_car_detail' => $request->barat_vinatge_car_detail,

                'barat_car' => $request->barat_car,
                'barat_car_detail' => $request->barat_car_detail,
                'barat_ghodi' => $request->barat_ghodi,
                'barat_ghodi_detail' => $request->barat_ghodi_detail,

                'barat_car_decoration' => $request->barat_car_decoration,
                'barat_car_decoration_detail' => $request->barat_car_decoration_detail,
                'barat_samdhi_mala' => $request->barat_samdhi_mala,
                'barat_samdhi_mala_detail' => $request->barat_samdhi_mala_detail,

                'barat_paper_confit' => $request->barat_paper_confit,
                'barat_paper_confit_detail' => $request->barat_paper_confit_detail,
            ];



            $b_response = DB::table('req_barat')->insert($barat);
 
            
             $reception = [
                'req_id' => $response,
                'rec_bg_entry' => $request->rec_bg_entry,
                'rec_bg_entry_detail' => $request->rec_bg_entry_detail,
                'rec_dj_sound' => $request->rec_dj_sound,
                'rec_dj_sound_detail' => $request->rec_dj_sound_detail,

                'rec_light' => $request->rec_light,
                'rec_light_detail' => $request->rec_light_detail,
                'rec_varmala' => $request->rec_varmala,
                'rec_varmala_detail' => $request->rec_varmala_detail,

                'rec_ins_group' => $request->rec_ins_group,
                'rec_ins_group_detail' => $request->rec_ins_group_detail,
                'rec_rot_stage' => $request->rec_rot_stage,
                'rec_rot_stage_detail' => $request->rec_rot_stage_detail,

                 'rec_paper_blaster' => $request->rec_paper_blaster,
                'rec_paper_blaster_detail' => $request->rec_paper_blaster_detail,
                'rec_cold_pyro' => $request->rec_cold_pyro,
                'rec_cold_pyro_detail' => $request->rec_cold_pyro_detail,

                 'rec_cake' => $request->rec_cake,
                'rec_cake_detail' => $request->rec_cake_detail,

            ];



            $rec_response = DB::table('req_recepetion')->insert($reception);
            

             $phere = [
                'req_id' => $response,
                'phere_havan_kund' => $request->phere_havan_kund,
                'phere_havan_kund_detail' => $request->phere_havan_kund_detail,
                'phere_pandit' => $request->phere_pandit,
                'phere_pandit_detail' => $request->phere_pandit_detail,

                'phere_phol_chadar' => $request->phere_phol_chadar,
                'phere_phol_chadar_detail' => $request->phere_phol_chadar_detail,
                'phere_sehnai_vadak' => $request->phere_sehnai_vadak,
                'phere_sehnai_vadak_detail' => $request->phere_sehnai_vadak_detail,

                'phere_sound' => $request->phere_sound,
                'phere_sound_detail' => $request->phere_sound_detail,
                'phere_makeup' => $request->phere_makeup,
                'phere_makeup_detail' => $request->phere_makeup_detail,

            ];



            $phere_response = DB::table('req_phere')->insert($phere);
         

         $cocktail = [
                'req_id' => $response,
                'pool_theme' => $request->pool_theme,
                'pool_theme_detail' => $request->pool_theme_detail,
                'pool_dj_sound' => $request->pool_dj_sound,
                'pool_dj_sound_detail' => $request->pool_dj_sound_detail,

                'pool_liquor' => $request->pool_liquor,
                'pool_liquor_detail' => $request->pool_liquor_detail,
                'pool_dhol' => $request->pool_dhol,
                'pool_dhol_detail' => $request->pool_dhol_detail,

                'pool_bar_tenders' => $request->pool_bar_tenders,
                'pool_bar_tenders_detail' => $request->pool_bar_tenders_detail,
                'pool_bar_set' => $request->pool_bar_set,
                'pool_bar_set_detail' => $request->pool_bar_set_detail,

                'pool_russian' => $request->pool_russian,
                'pool_russian_detail' => $request->pool_russian_detail,
                'pool_jugglers' => $request->pool_jugglers,
                'pool_jugglers_detail' => $request->pool_jugglers_detail,


            ];



            $cock_response = DB::table('req_cocktail')->insert($cocktail);
           
            $others = [
                'req_id' => $response,
                'other_makeup_artist' => $request->other_makeup_artist,
                'other_makeup_artist_detail' => $request->other_makeup_artist_detail,
                'other_caters' => $request->other_caters,
                'other_caters_detail' => $request->other_caters_detail,

                'other_photography' => $request->other_photography,
                'other_photography_detail' => $request->other_photography_detail,
                'other_cloth' => $request->other_cloth,
                'other_cloth_detail' => $request->other_cloth_detail,

                'other_car_service' => $request->other_car_service,
                'other_car_service_detail' => $request->other_car_service_detail,
                'other_sanitization' => $request->other_sanitization,
                'other_sanitization_detail' => $request->other_sanitization_detail,

                'other_help' => $request->other_help,
                'other_help_detail' => $request->other_help_detail,

            ];



            $other_response = DB::table('req_other')->insert($others);
         
   

          
       
            return response()->json(['error' => false, 'message' => 'Request Added Succesfully!']);

         }

   return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
        
    }

    public function update(Request $request)
    {   
        $id = $request->req_id;

       
            $data = [
                'email' => $request->username,
                'name' => $request->name,
                'mobile' => $request->mobile,
                
            ];



       $response = DB::table('req_user')->where('id', $id)->update($data);

    

         
           if ($response==0 || $response==1)
           {
          

            $mandap = [
                'tea_coffe' => $request->tea_coffe,
                't_c_detail' => $request->tea_details,
                'sp_mandap' => $request->sp_mandap,
                'sp_m_detail' => $request->detail_sp_mandap,

                'decoration' => $request->decoration,
                'decoration_detail' => $request->detail_decoration,
                'phool_chadar' => $request->ph_chadar,
                'p_c_detail' => $request->detail_ph_chadar,

                'sheet_arrange' => $request->seet_arrange,
                's_a_detail' => $request->detail_seet_arrange,
                'light_sound' => $request->light_sound,
                'l_s_detail' => $request->detail_light_sound,

                'mandap_pandit' => $request->pandit,
                'm_p_detail' => $request->detail_pandit,
                'havan_kund' => $request->havan,
                'm_h_detail' => $request->detail_havan,
            ];



            $m_response = DB::table('req_mandap')->where('req_id', $id)->update($mandap);

             $mehandi = [
                'bridal_mehandi_artist' => $request->bridal_mehandi,
                'b_m_a_detail' => $request->detail_bridal_mehandi,
                'mehandi_artist' => $request->mehandi_artist,
                'm_a_count_detail' => $request->detail_mehandi_artist,

                'nail_tatto_artist' => $request->nail_tattoo,
                'n_t_detail' => $request->detail_nail_tattoo,
                'magician' => $request->magician,
                'magician_detail' => $request->detail_magician,

                'mehandi_decoration' => $request->mehandi_decoration,
                'm_md_detail' => $request->detail_mehandi_decoration,
                'm_anchor' => $request->mehandi_anchor,
                'm_a_detail' => $request->detail_mehandi_anchor,

                'm_light_sound' => $request->mehandi_light,
                'm_ls_detail' => $request->detail_mehandi_light,
                'dhol' => $request->mehandi_dhol,
                'dhol_detail' => $request->deatil_mehandi_dhol,

                'm_special_entry' => $request->sp_entry,
                'm_se_detail' => $request->detail_sp_entry,
                'fooding' => $request->mehandi_fooding,
                'm_f_detail' => $request->detail_mehandi_fooding,
            ];



            $m_response = DB::table('req_mehandi')->where('req_id', $id)->update($mehandi);

             $service = [
                's_pick_drop' => $request->pick_drop,
                's_pd_detail' => $request->detail_pick_drop,
                'car_service' => $request->car_service,
                's_car_detail' => $request->detail_car_service,

                'luggages_boy' => $request->luggages_boy,
                's_lb_detail' => $request->detail_luggages_boy,
                'welcome_girl' => $request->welcome_girl,
                's_wg_detail' => $request->detail_welcome_girl,

                'help_desk_boy' => $request->help_boy,
                's_hdb_detail' => $request->detail_help_boy,
                'valet_guard' => $request->valet_gurd,
                's_vg_detail' => $request->detail_valet_gurd,

                'e_rickhaw' => $request->e_rickshaw,
                's_er_detail' => $request->detail_e_rickshaw,
                'room_hampers' => $request->room_hampers,
                's_rh_detail' => $request->detail_room_hampers,

                'senitization' => $request->senitization,
                'ss_detail' => $request->detail_senitization,
                'voluneters' => $request->volunteers,
                'sv_detail' => $request->detail_volunteers,
            ];



            $s_response = DB::table('req_services')->where('req_id', $id)->update($service);
            

             $entertainment = [
                'en_poolparty' => $request->pool_party,
                'en_pp_detail' => $request->detail_pool_party,
                'en_dj_sound' => $request->dj_sound,
                'en_djs_detail' => $request->detail_dj_sound,

                'en_selfie_zone' => $request->selfi_zone,
                'en_sz_detail' => $request->detail_selfi_zone,
                'en_poolprops' => $request->pool_props,
                'en_prop_detail' => $request->detail_pool_props,

                'en_meena_bazar' => $request->meena_bazar,
                'en_mb_detail' => $request->detail_meena_bazar,

                'en_housie' => $request->housie,
                'en_housie_detail' => $request->detail_housie,
                'en_sports_cress' => $request->crselection_oss,
                'en_sc_detail' => $request->detail_crselection_oss,

                'en_dhol_boy' => $request->dhol_boy,
                'en_db_detail' => $request->detail_dhol_boy,
                'en_cartoon_dance' => $request->cartoon_dancer,
                'en_cd_detail' => $request->detail_cartoon_dancer,

                'flower_jewellery' => $request->flower_jewellery,
                'en_fj_detail' => $request->detail_flower_jewellery,
                'en_bangle_shop' => $request->bangel_shop,
                'en_bs_detail' => $request->detail_bangel_shop,

                'en_photo_frame' => $request->photo_framing,
                'en_pf_detail' => $request->detail_photo_framing,
                'en_paper_show' => $request->paper_show,
                'en_ps_detail' => $request->detail_paper_show,
            ];



            $ent_response = DB::table('req_entertainment')->where('req_id', $id)->update($entertainment);
            
             $sangeet = [
                's_truss' => $request->truss,
                's_t_detail' => $request->detail_truss,
                's_led_wall' => $request->led_wall,
                's_lw_detail' => $request->detail_led_wall,

                's_light' => $request->light,
                's_l_detail' => $request->detail_light,
                's_sound' => $request->sound,
                's_s_detail' => $request->detail_sound,

                's_generator' => $request->generator,
                's_g_detail' => $request->detail_generator,

                's_back_dancer' => $request->background_dancer,
                's_bd_detail' => $request->detail_background_dancer,
                's_choreograph' => $request->choreographer,
                's_c_detail' => $request->detail_choreographer,

                's_anchor' => $request->sangeet_anchor,
                's_a_detail' => $request->detail_sangeet_anchor,
                's_russ_waiters' => $request->russian_waiters,
                's_rw_detail' => $request->detail_russian_waiters,

                's_tv_boll_artist' => $request->bollywood_artist,
                's_tba_detail' => $request->detail_bollywood_artist,
                's_br_gr_entry' => $request->bG_entry,
                's_bge_detail' => $request->detail_bG_entry,

                's_cold_payro' => $request->cold_payro,
                's_cp_detail' => $request->detail_cold_payro,
                's_paperblast' => $request->paper_blast,
                's_pb_detail' => $request->detail_paper_blast,

                's_dry_ice' => $request->dry_ice,
                's_di_detail' => $request->detail_dry_ice,
                's_fire' => $request->fire,
                's_f_detail' => $request->detail_fire,

                's_smoke_machine' => $request->smoke_machine,
                's_mm_detail' => $request->detail_smoke_machine,
                'sangeet_decoration' => $request->sangeet_decoration,
                'ssd_detail' => $request->detail_sangeet_decoration,
            ];



            $san_response = DB::table('req_sangeet')->where('req_id', $id)->update($sangeet);
 
            
             $mayra = [
                'mb_sound' => $request->m_sound,
                'md_s_detail' => $request->detail_m_sound,
                'm_m_artist_team' => $request->myra_team,
                'mb_mmat_detail' => $request->detail_myra_team,

                'mb_back_dancer' => $request->mayra_back_dancer,
                'mb_bd_detail' => $request->detail_mayra_back_dancer,
                'mb_deco_selfi_corner' => $request->selfi_corner,
                'mb_dsc_detail' => $request->detail_selfi_corner,

                'mb_special_entry' => $request->mayra_sp_entry,
                'mb_spe_detail' => $request->detail_mayra_sp_entry,

            ];



            $mayra_response = DB::table('req_mayra_bhat')->where('req_id', $id)->update($mayra);
            

             $haldi = [
                'handi_decoration' => $request->handi_decoration,
                'handi_detail' => $request->detail_handi_decoration,
                'h_anchor' => $request->haldi_anchor,
                'h_a_detail' => $request->detail_haldi_anchor,

                'h_sound' => $request->haldi_sound,
                'h_s_detail' => $request->detail_haldi_sound,
                'h_light' => $request->haldi_lights,
                'h_l_detail' => $request->detail_haldi_lights,

                'h_special_entry' => $request->haldi_sp_entry,
                'h_se_detail' => $request->detail_haldi_sp_entry,

            ];



            $haldi_response = DB::table('req_haldi')->where('req_id', $id)->update($haldi);
         

         $reception = [
                'rec_bg_entry' => $request->reception_bg_entry,
                'rec_bge_detail' => $request->detail_reception_bg_entry,
                'rec_unp_band' => $request->unplugged_band,
                'rec_unb_detail' => $request->detail_unplugged_band,

                'rec_artist' => $request->reception_artist,
                'rec_a_detail' => $request->detail_reception_artist,
                'rec_uns_guitar' => $request->gitar_artist,
                'rec_unsg_detail' => $request->detail_gitar_artist,

                'rec_waiters' => $request->rec_waiters,
                'rec_w_detail' => $request->detail_rec_waiters,
                'rec_fluit_artist' => $request->fluit_artist,
                'rec_fluit_detail' => $request->detail_fluit_artist,

                'rec_band' => $request->rec_band,
                'rec_b_detail' => $request->detail_rec_band,
                'rec_ins_music' => $request->intrumental_music,
                'rec_inm_detail' => $request->detail_intrumental_music,

                'rec_ins_band' => $request->intrumental_band,
                'rec_insb_detail' => $request->detail_intrumental_band,
                'rec_sound' => $request->rec_sound,
                'rec_s_detail' => $request->detail_rec_sound,

                'rec_light' => $request->rec_light,
                'rec_l_detail' => $request->detail_rec_light,
                'rec_led_wall' => $request->rec_led,
                'rec_lw_detail' => $request->detail_rec_led,

                'rec_truss' => $request->rec_truss,
                'rec_t_detail' => $request->detail_rec_truss,
                'rec_decoration' => $request->rec_decoration,
                'rec_d_detail' => $request->detail_rec_decoration,

                'rec_thba_entry' => $request->rec_theam_enytry,
                'rec_thbae_detail' => $request->detail_rec_theam_enytry,
                'rec_counter' => $request->rec_counter,
                'rec_c_detail' => $request->detail_rec_counter,

                'rec_coconut_water' => $request->coconut_water,
                'rec_ccw_detail' => $request->detail_coconut_water,

            ];



            $party_response = DB::table('req_reception')->where('req_id', $id)->update($reception);
           
            $barat = [
                'b_band_party' => $request->barat_bandparty,
                'b_bp_detail' => $request->detail_barat_bandparty,
                'b_dhumal_party' => $request->dhumal_party,
                'b_dp_detail' => $request->detail_dhumal_party,

                'b_dhol_boy' => $request->barat_dholboys,
                'b_db_detail' => $request->detail_barat_dholboys,
                'b_shehnai_player' => $request->shehnai_player,
                'b_sp_detail' => $request->detail_shehnai_player,

                'b_welcome_girl' => $request->barat_welcomegirls,
                'b_wg_detail' => $request->detail_barat_welcomegirls,
                'b_safa' => $request->safa,
                'b_s_detail' => $request->detail_safa,

                'b_ghodi' => $request->ghodi,
                'b_g_detail' => $request->detail_ghodi,
                'b_firecrakers' => $request->firecrackers,
                'b_fire_detail' => $request->detail_firecrackers,

                'b_lights' => $request->barat_light,
                'b_l_detail' => $request->detail_barat_light,
                'b_baggi_v_car' => $request->baggi_vintagecar,
                'b_bv_details' => $request->detail_baggi_vintagecar,

                'b_itrs' => $request->itrs,
                'b_itrs_detail' => $request->detail_itrs,
                'b_samdhi_mala' => $request->samdhi_mala,
                'b_sm_detail' => $request->detail_samdhi_mala,

                'b_rose' => $request->rose,
                'b_r_detail' => $request->detail_rose,

            ];



            $barat_response = DB::table('rec_barat')->where('req_id', $id)->update($barat);
         
         $cocktail = [
                'co_sound' => $request->cocktail_sound,
                'co_s_detail' => $request->detail_cocktail_sound,
                'co_light' => $request->cocktail_lights,
                'co_l_detail' => $request->detail_cocktail_lights,

                'co_truss' => $request->cocktail_truss,
                'co_t_detail' => $request->detail_cocktail_truss,
                'co_led_wall' => $request->cocktail_led_wall,
                'co_lw_detail' => $request->detail_cocktail_led_wall,

                'co_back_dance' => $request->cacktail_background_dancer,
                'co_bgd_detail' => $request->detail_cacktail_background_dancer,
                'co_belly_dance' => $request->belly_dancer,
                'co_belly_detail' => $request->detail_belly_dancer,

                'co_waiters' => $request->cocktail_waiters,
                'co_w_detail' => $request->detail_cocktail_waiters,
                'co_tbd' => $request->cocktail_team,
                'co_tbd_detail' => $request->detail_cocktail_team,

                'co_anchor' => $request->cocktail_anchor,
                'co_a_detail' => $request->detail_cocktail_anchor,
                'co_rock_band' => $request->rock_band,
                'co_rb_detail' => $request->detail_rock_band,

            ];



            $cock_response = DB::table('rec_cocktail')->where('req_id', $id)->update($cocktail);
           
           $common = [
                'com_photography' => $request->photography,
                'com_p_detail' => $request->detail_photography,
                'com_makeup' => $request->makeup,
                'com_m_detail' => $request->detail_makeup,

                'com_caters' => $request->caters,
                'com_c_detail' => $request->detail_caters,
                'com_clothing' => $request->clothing,
                'com_cl_detail' => $request->detail_clothing,

            ];



           $comm_response = DB::table('rec_common_list')->where('req_id', $id)->update($common);

          
       
            return response()->json(['error' => false, 'message' => 'Request Updated Succesfully!']);

         }

   return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
        
    }

}
