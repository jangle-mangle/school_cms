<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CommonController as commonObj;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use Validator;
use Auth;
use DB;
use File;

class ContactUsController extends Controller
{
    private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->commonObj = new commonObj();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 


    public function index()
    {
        return view('admin.contact_us');
    }



    public function data(Request $request){

        $data = DB::table('contact_us')->orderBy('id', 'desc')->get();

        return datatables()->of($data)->addColumn('id', function ($data) {
            return  $data->id;

        })->addColumn('name', function ($data) {
        return  $data->name;

        })->addColumn('subject', function ($data) {
        return  $data->subject; 

        })->addColumn('message', function ($data) {
        return  $data->message; 

        })->rawColumns(['name', 'subject','message', 'id'])->make(true);

    }



    public function delete(Request $request)
    {
        $response=DB::table('contact_us')->where('id', $request->id)->delete();
        if ($response)
        {
            return response()->json(['error' => false, 'message' => 'Contact Us Deleted Succesfully!'], 200);
        }
        return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);    
    }

    
    public function changeStatus(Request $request){
        $table=DB::table('contact_us')->where('id', $request->id)->first();
        if(isset($table))
        {
           if($table->status == 'Active')
            {
                $response=DB::table('contact_us')->where('id', $request->id)->update(['status' => 'Inactive']);
                if ($response)
                {
                    return response()->json(['error' => false, 'message' => 'Contact Us Status Inactive Succesfully!'], 200);
                }
                return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);

            }
            else
            {
                $response = DB::table('contact_us')->where('id', $request->id)->update(['status' => 'Active']);
                if ($response)
                {
                    return response()->json(['error' => false, 'message' => 'Contact Us Status Active Succesfully!'], 200);
                }
                return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
                
            }  
        }
        else
        {
            return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);

        }
          
    }



    public function status(Request $request){

        $data = [];

        if ($request->status == 'enable') {
          $data = ['is_active'=>'Yes', 'updated_at' => date('Y-m-d H:i:s')];
        }
        elseif($request->status == 'disable'){
           $data = ['is_active'=>'No', 'updated_at' => date('Y-m-d H:i:s')];
        }
        elseif($request->status == 'delete'){
           $data = ['is_active'=>'No', 'updated_at' => date('Y-m-d H:i:s'), 'deleted_at' => date('Y-m-d H:i:s')];
        }

        $result = DB::table('albums')->where('id',$request->id)->update($data);

        if ($result > 0) {

            if($request->status == 'delete'){
                return response()->json(['error' => false, 'message' => 'Album Deleted Succesfully!'], 200);
            }

            return response()->json(['error' => false, 'message' => 'Status Updated Succesfully!'], 200);

        } else {
             return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
        }
    }

    public function get(Request $request){
        
        $albums = DB::table('albums')->where('id', $request->id)->first();

        if ($albums) {

            $albums->thumbnail_image_with_url = url("storage/albums/thumbnail_image/").'/'.$albums->thumbnail_image;
            $data['albums'] = $albums;

            $images = DB::table('image_files')->where('album_id', $albums->id)->get();

            $files = [];

            foreach ($images as $image) {

                $image->image_with_url = ($image->this_for == 'Album Image') ? url("storage/$image->folder/$image->image") : NULL ;
                array_push($files, $image);
            }

            $data['files'] = $this->commonObj->convertToObject($files);

            if (count($data) > 0) {
                return response()->json(['error' => false, 'message' => 'Data Found', 'data' => $data]);
            } 
        }
        return response()->json(['error'=> true, 'message' => 'Data Not Found!']);
    }

    private function isValidImageFile($files = [])
    {
        //allowed image type of product images.
        $allowedFileExt = ['jpg','png', 'jpeg', 'GIF', 'gif', 'bmp', 'pjpeg'];

        if (!empty($files) && is_array($files)) {

            foreach ($files as $file) {

                $extension = $file->getClientOriginalExtension();

                if(!in_array($extension, $allowedFileExt)) 
                    return false;
            }
            return true;
        }elseif (!empty($files)) {

            $extension = $files->getClientOriginalExtension();
           
            return (in_array($extension, $allowedFileExt)) ? true : false ;

        }
        return false;
    }

    
    private function galleryLinkUpload($links, $album_id){

        $response = 0;

        //delete the previous links.
        $response=DB::table('image_files')->where('this_for', 'Album Video Link')->where('album_id', $album_id)->delete();

        //If product have extra image for display.
        foreach ($links as $link) {      
            
            if (isset($link)) {
                $imageData = [
                            'link' => $link,
                            'album_id' => $album_id,
                            'this_for' => 'Album Video Link', 
                            'created_at' => date('Y-m-d H:i:s')
                        ];
                $response = DB::table('image_files')->insertGetId($imageData);
            }
            
        }
        return $response;
    }

    private function galleryImageUpload($files, $album_id, $album_title = ''){

        $response = 0;
        $i = 0;

        //delete the previous image files.
        // if ($action == 'auto') {
        //     $response = DB::table('image_files')->where('image_for', 'Product')->where('refrance_id', $product_id)->delete();
        // }

        //Make directory, If doesn't exist.
        $targetDir = storage_path('/app/public/albums/gallery_image');
        if (!(File::isDirectory($targetDir))) {

            File::makeDirectory($targetDir, 0777, true, true);
        }

        //If product have extra image for display.
        foreach ($files as $mediaFile) {      
            
            $extension = $mediaFile->extension();
            $file_name=date('ymdhis')."_".str_replace(' ', '_', strtoupper($album_title))."_$i.$extension";
            // $file_name = date('ymdhis').'_'.$mediaFile->getClientOriginalName();
            
            $mediaFile->move($targetDir, $file_name);
            
            $imageData = [
                        'image' => $file_name,
                        'folder' => 'albums/gallery_image', 
                        'album_id' => $album_id,
                        'this_for' => 'Album Image', 
                        'created_at' => date('Y-m-d H:i:s')
                    ];
            $response = DB::table('image_files')->insertGetId($imageData);
            $i++;
        }
        return $response;
    }
}
