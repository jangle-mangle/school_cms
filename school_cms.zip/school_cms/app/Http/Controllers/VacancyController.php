<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CommonController as commonObj;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use App\Models\Hotels;
use Validator;
use Auth;
use DB;
use File;

class VacancyController extends Controller
{
    private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->commonObj = new commonObj();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 


    public function index()
    {
        return view('admin.vacancy');
    }


    public function add(Request $request)
    {   
        // dd($request->all());
        $error_msg = ['thumbnail_image.max' => 'Image may not be greater than 1 MB.'];
        $validator = Validator::make($request->all(), 
            [ 
              'job_title' => 'required',
              'qualification' => 'required',
              'experience' => 'required',
              'job_location' => 'required',
              'job_type' => 'required',
            ]);

        if ($validator->fails()) {
            return response()->json([
                'message'   => $validator->errors()->first(),
                'error' => true
            ]);
        }
        else
        {

            $data = [
                    'job_title' => $request->job_title,
                    'qualification' => $request->qualification,
                    'experience' => $request->experience,
                    'job_location' => $request->job_location,
                    'job_type' => $request->job_type,
                    ];

            $add = DB::table('vacancies')->insert($data);        

            if ($add){

                return response()->json(['error' => false, 'message' => 'Data Added Succesfully!'], 200);
            }
            return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
        }
    }



    public function edit(Request $request)
    {   
        $validator = Validator::make($request->all(), 
            [ 
              'job_title' => 'required',
              'qualification' => 'required',
              'experience' => 'required',
              'job_location' => 'required',
              'job_type' => 'required',
            ]);

        if ($validator->fails()) {
            return response()->json([
                'message'   => $validator->errors()->first(),
                'error' => true
            ]);
        }
        else
        {
        
            $data = [
                    'job_title' => $request->job_title,
                    'qualification' => $request->qualification,
                    'experience' => $request->experience,
                    'job_location' => $request->job_location,
                    'job_type' => $request->job_type,
                    ];

            $edit = DB::table('vacancies')->where('id',$request->id)->update($data); 


            // if(DB::table('vacancies')->where('id',$request->id)->update($data))
            // {
                return response()->json(['error' => false, 'message' => 'Data Edited Succesfully!'], 200);
            // }
            // return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
        }
    }



    
    
    public function data(Request $request){

        $data = DB::table('vacancies')->orderBy('id', 'desc')->get();

        return datatables()->of($data)->addColumn('actions', function ($data) {

            $btn = '<div class="btn-group" role="group"><button type="button" class="btn btn-sm btn-primary" style="padding:.700rem .666rem;" ><a href="'.route('admin.vacancy.editView', $data->id).'" class="adbum-edit-btn" style="color:white;"><i class="bx bx-edit-alt"></i></a></button>';

            // if ($data->status == 'Active') {
            //     $btn .= '<button type="button" class="btn btn-sm btn-danger" style="padding:.700rem .666rem;"><a href="javascript:void()" name="disable" data-value="'.$data->id.'" class="status-btn" style="color:white;"><i class="bx bx-block"></i></a></button>';
            // }else{
            //     $btn .= '<button type="button" class="btn btn-sm btn-primary" style="padding:.700rem .666rem;"><a href="javascript:void()" name="enable" data-value="'.$data->id.'" class="status-btn" style="color:white;"><i class="bx bx-check-double"></i></a></button>';
            // }

            $btn .= '<button type="button" class="btn btn-sm btn-danger" style="padding:.700rem .666rem;"><a href="javascript:void()" name="delete" data-value="'.$data->id.'" class="status-btn" style="color:white;"><i class="bx bx-trash"></i></a></button></div>';

            return $btn;

        })->addColumn('id', function ($data) {
            return  $data->id;

        })->addColumn('job_title', function ($data) {
            return  $data->job_title;

        })->addColumn('qualification', function ($data) {
            return  $data->qualification;

        })->addColumn('experience', function ($data) {
            return  $data->experience;

        })->addColumn('job_location', function ($data) {
            return  $data->job_location;

        })->addColumn('job_type', function ($data) {
            return  $data->job_type;

        })->rawColumns(['actions','id', 'job_title', 'qualification', 'experience', 'job_location', 'job_type'])->make(true);

    }


    public function editView(Request $request){
        
        $data['vacancies'] = DB::table('vacancies')->where('id',$request->id)->first();
        if(isset($data['vacancies']))
        {
            return view('admin.editVacancy')->with($data);
        }
        else
        {
            abort(404);
        }

    }

    

    public function delete(Request $request){
      
        $data = [];
        if($request->status == 'delete'){
           
           $result = DB::table('vacancies')->where('id',$request->id)->delete();
        }

        if ($result) 
        {
                return response()->json(['error' => false, 'message' => 'Data Deleted Succesfully!'], 200);

        } else {
             return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
        }
    }


   
}
