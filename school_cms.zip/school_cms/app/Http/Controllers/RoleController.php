<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CommonController as commonObj;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use Validator;
use Auth;
use DB;
use File;
use App\Models\Role;

class RoleController extends Controller
{
    private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->commonObj = new commonObj();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 


    public function index()
    {
        return view('admin.roles');
    }


    public function data(Request $request){

        $data = DB::table('roles')->orderBy('id', 'desc')->get();

        return datatables()->of($data)
        ->addColumn('id', function ($data) {
            return  $data->id;
        })
        ->addColumn('name', function ($data) {
            return  $data->name;
        })
        ->addColumn('actions', function ($data) {
            $btn = '<div class="btn-group" role="group">';
                $btn .= '<a href="javascript:;" data-id="'.$data->id.'" data-name="'.$data->name.'" class="btn btn-sm btn-primary role-edit-btn" style="color:white; padding:.700rem .666rem;" data-toggle="modal" data-target="#roleModal"><i class="bx bx-edit-alt"></i></a>';
                $btn .= ' <a href="javascript:void()" name="delete" data-id="'.$data->id.'" data-name="'.$data->name.'" class="btn btn-sm btn-danger status-btn" style="color:white; padding:.700rem .666rem;"><i class="bx bx-trash"></i></a>';
            $btn .= '</div>';
            return $btn;
        })
        ->rawColumns(['actions', 'id', 'name'])->make(true);

    }

    public function add(Request $request) { 
        if(isset($request->id))
        {
            $role = Role::find($request->id);
            $role->name = $request->name;
            $query = $role->save();
            if($query)
            {
                return response()->json(['status' => true, 'message' => 'Role updated successfully !']);
            }
            else
            {
                return response()->json(['status' => false, 'message' => 'Something went wrong, try again later !']);
            }
        }
        else
        {
            $role = new Role;
            $role->name = $request->name;
            $query = $role->save();
            if($query)
            {
                return response()->json(['status' => true, 'message' => 'Role saved successfully !']);
            }
            else
            {
                return response()->json(['status' => false, 'message' => 'Something went wrong, try again later !']);
            }
        }

        
    }


}
