<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CommonController as commonObj;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use Validator;
use Auth;
use DB;
use File;
use App\Models\Unit;
use App\Models\Member;

class MemberController extends Controller
{
    private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->commonObj = new commonObj();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 


    public function index()
    {
        $data['units'] = Unit::orderBy('name', 'ASC')->get();
        return view('admin.members')->with($data);
    }


    public function data(Request $request){

        $data = DB::table('members')->orderBy('id', 'desc')->get();

        return datatables()->of($data)
        ->addColumn('id', function ($data) {
            return  $data->id;
        })
        ->addColumn('name_of_unit', function ($data) {
            $unit_name = Unit::find($data->name_of_unit)  ; 
            return  $unit_name->name;
        })
        ->addColumn('name', function ($data) {
            return  $data->name;
        })
        ->addColumn('partner', function ($data) {
            return  $data->partner;
        })
        ->addColumn('mobile', function ($data) {
            return  $data->mobile;
        })
        ->addColumn('phone', function ($data) {
            return  $data->phone;
        })
        ->addColumn('address', function ($data) {
            return  isset($data->address) ? $data->address : '-';
        })
        ->addColumn('actions', function ($data) {
            $btn = '<div class="btn-group" role="group">';
                $btn .= '<a href="javascript:;" data-id="'.$data->id.'" class="btn btn-sm btn-primary member-edit-btn" style="color:white; padding:.700rem .666rem;" data-toggle="modal" data-target="#memberModal"><i class="bx bx-edit-alt"></i></a>';
                $btn .= ' <a href="javascript:void()" name="delete" data-id="'.$data->id.'" class="btn btn-sm btn-danger status-btn" style="color:white; padding:.700rem .666rem;"><i class="bx bx-trash"></i></a>';
            $btn .= '</div>';
            return $btn;
        })
        ->rawColumns(['id', 'name', 'partner', 'mobile', 'phone', 'address', 'actions'])
        ->make(true);

    }

    public function submit(Request $request) { 
        if(isset($request->id))
        {
            $member = Member::find($request->id);
            $member->name = $request->name;
            $member->name_of_unit = $request->name_of_unit;
            $member->partner = $request->partner;
            $member->mobile = $request->mobile;
            $member->phone = $request->phone;
            $member->address = $request->address;
            $query = $member->save();
            if($query)
            {
                return response()->json(['status' => true, 'message' => 'Member updated successfully !']);
            }
            else
            {
                return response()->json(['status' => false, 'message' => 'Something went wrong, try again later !']);
            }
        }
        else
        {
            $member = new Member;
            $member->name = $request->name;
            $member->name_of_unit = $request->name_of_unit;
            $member->partner = $request->partner;
            $member->mobile = $request->mobile;
            $member->phone = $request->phone;
            $member->address = $request->address;
            $query = $member->save();
            if($query)
            {
                return response()->json(['status' => true, 'message' => 'Member saved successfully !']);
            }
            else
            {
                return response()->json(['status' => false, 'message' => 'Something went wrong, try again later !']);
            }
        }
    }

    public function fetch(Request $request)
    { 
        $member = Member::find($request->id);
        if(isset($member->id))
        {
            return response()->json(['status' => true, 'message' => 'Fetched !', 'data' => $member]);
        }
        else
        {
            return response()->json(['status' => false, 'message' => 'No data found !', 'data' => NULL]);
        }

    }


}
