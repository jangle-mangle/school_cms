<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CommonController as commonObj;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use Validator;
use Auth;
use DB;
use File;
use App\Models\Role;
use App\Models\ExecutiveMember;

class ExecutiveMemberController extends Controller
{
    private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->commonObj = new commonObj();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */




    public function index()
    {
        $data['roles'] = Role::orderBy('name', 'ASC')->get();
        return view('admin.executive_members')->with($data);
    }


    public function data(Request $request)
    {

        // $data = DB::table('executive_member')->orderBy('id', 'desc')->get();
        $data = DB::SELECT("SELECT e.*, r.name as role_name FROM executive_member e LEFT JOIN roles r ON r.id = e.role");

        return datatables()->of($data)
            ->addColumn('id', function ($data) {
                return  $data->id;
            })
            ->addColumn('name', function ($data) {
                return  $data->name;
            })
            ->addColumn('phone', function ($data) {
                return  $data->phone;
            })
            ->addColumn('role', function ($data) {
                return  $data->role_name;
            })
            ->addColumn('company', function ($data) {
                return  $data->company;
            })
            ->addColumn('actions', function ($data) {
                $btn = '<div class="btn-group" role="group">';
                $btn .= '<a href="javascript:;" data-id="' . $data->id . '" data-name="' . $data->name . '" data-phone="' . $data->phone . '" data-role="' . $data->role . '" data-company="' . $data->company . '" data-photo="'.$data->photo.'" class="btn btn-sm btn-primary member-edit-btn" style="color:white; padding:.700rem .666rem;" data-toggle="modal" data-target="#executiveMemberModal"><i class="bx bx-edit-alt"></i></a>';
                $btn .= ' <a href="javascript:void()" name="delete" data-id="' . $data->id . '" class="btn btn-sm btn-danger status-btn" style="color:white; padding:.700rem .666rem;"><i class="bx bx-trash"></i></a>';
                $btn .= '</div>';
                return $btn;
            })
            ->rawColumns(['id', 'name', 'phone', 'role', 'company', 'actions'])
            ->make(true);
    }

    public function submit(Request $request)
    {
        if ($request->hasFile('photo')) {
            $file = $request->file('photo');
            $fileName = $file->getClientOriginalName();
            $file->move(public_path('uploads/executive-members'), $fileName);
        }else{
            $fileName = $request->old_photo;
        }

        if (isset($request->id)) {
            $member = ExecutiveMember::find($request->id);
            $member->role = $request->role;
            $member->name = $request->name;
            $member->phone = $request->phone;
            $member->company = $request->company;
            $member->photo = $fileName;
            $query = $member->save();
            if ($query) {
                return response()->json(['status' => true, 'message' => 'Executive member updated successfully !']);
            } else {
                return response()->json(['status' => false, 'message' => 'Something went wrong, try again later !']);
            }
        } else {
            $member = new ExecutiveMember;
            $member->role = $request->role;
            $member->name = $request->name;
            $member->phone = $request->phone;
            $member->company = $request->company;
            $member->photo = $fileName;
            $query = $member->save();
            if ($query) {
                return response()->json(['status' => true, 'message' => 'Executive member saved successfully !']);
            } else {
                return response()->json(['status' => false, 'message' => 'Something went wrong, try again later !']);
            }
        }
    }
}
