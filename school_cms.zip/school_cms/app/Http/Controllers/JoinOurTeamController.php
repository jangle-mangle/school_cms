<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CommonController as commonObj;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;
use Validator;
use Auth;
use DB;
use File;

class JoinOurTeamController extends Controller
{
    private $commonObj;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->commonObj = new commonObj();
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

 


    public function index()
    {
        return view('admin.join_with_us');
    }


    public function add(Request $request)
    {  
        // $error_msg = ['image.max' => 'Image may not be greater than 1 MB.'];
        $validator = Validator::make($request->all(), 
            [ 
              'title' => 'required',
              'image' => 'required',
            ]);

        if ($validator->fails()) {
             return response()->json([
               'message'   => $validator->errors()->first(),
               'error' => true
              ]);
        }

        $img_multiple = $request->file('image');
        $i = 1;
        foreach($img_multiple as $key => $img){
            $image = NULL;
            $j = $i++;
            if($img){

                $file = $img;
                // dd($file);
                $extension = $file->extension();
                $image = $j.date('ymdhis').".$extension";
                $targetDir = storage_path('/app/public/project');
                if (!(File::isDirectory($targetDir))) {

                    File::makeDirectory($targetDir, 0777, true, true);
                }

                $width = Image::make($file)->width();

                if($width > 1920){
                    $thumbnail_resize = Image::make($file->getRealPath());              
                    $thumbnail_resize->resize(1920, null);
                    $thumbnail_resize->save(storage_path('app/public/project/' .$image));
                }else{
                    $thumbnail_resize = Image::make($file->getRealPath());              
                    $thumbnail_resize->save(storage_path('app/public/project/' .$image));
                }




                // $file->move($targetDir, $image);
                $thumbnail_resize = Image::make($file->getRealPath());  
                $small_image = $j.'small-'.date('ymdhis').".$extension";            
                $thumbnail_resize->resize(350, null);
                $thumbnail_resize->save(storage_path('app/public/project/' .$small_image));
            }

        if($key == 0)
        {    
            $data = [
                    'title' => $request->title,
                    'created_at' => date('Y-m-d h:i:s'),
                ];
         
            $response = DB::table('project')->insertGetId($data);
        }

            $insert = [
                    'project_id' => $response,
                    'image' => $image,
                    'created_at' => date('Y-m-d h:i:s'),
                ];

            $add = DB::table('project_image')->insertGetId($insert);    
        }

        if ($response > 0) {
            return response()->json(['error' => false, 'message' => 'Project Added Succesfully!'], 200);
        }
        return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
    }





    public function data(Request $request){

        $data = DB::table('join_our_team')->orderBy('id', 'desc')->get();

        return datatables()->of($data)->addColumn('id', function ($data) {
            return  $data->id;

        })->addColumn('name', function ($data) {
            return  $data->name;

        })->addColumn('email', function ($data) {
            return  $data->email;

        })->addColumn('phone', function ($data) {
            return  $data->phone;

        })->addColumn('message', function ($data) {
            return  $data->message;

        })->addColumn('resume', function ($data) {
            $image = '-';
            if(isset($data->resume))
            {
                $image = "<a href='".asset('resume/'.$data->resume)."' target='_blank'><i class='bx bxs-file'></i></a>";
            }
            return $image;

        })->rawColumns(['message', 'resume', 'id', 'name','email','phone'])->make(true);

    }



    
    public function changeStatus(Request $request){
        $table=DB::table('project')->where('id', $request->id)->first();
        if($request->status == 'delete')
        {
            $response=DB::table('project')->where('id', $request->id)->delete();
            if ($response)
            {
                return response()->json(['error' => false, 'message' => 'Image Deleted Succesfully!'], 200);
            }
        }   
        return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
    }


    




    // public function status(Request $request){

    //     $data = [];

    //     if ($request->status == 'enable') {
    //       $data = ['is_active'=>'Yes', 'updated_at' => date('Y-m-d H:i:s')];
    //     }
    //     elseif($request->status == 'disable'){
    //        $data = ['is_active'=>'No', 'updated_at' => date('Y-m-d H:i:s')];
    //     }
    //     elseif($request->status == 'delete'){
    //        $data = ['is_active'=>'No', 'updated_at' => date('Y-m-d H:i:s'), 'deleted_at' => date('Y-m-d H:i:s')];
    //     }

    //     $result = DB::table('albums')->where('id',$request->id)->update($data);

    //     if ($result > 0) {

    //         if($request->status == 'delete'){
    //             return response()->json(['error' => false, 'message' => 'Album Deleted Succesfully!'], 200);
    //         }

    //         return response()->json(['error' => false, 'message' => 'Status Updated Succesfully!'], 200);

    //     } else {
    //          return response()->json(['error'=> true, 'message' => 'Somthing went wrong, try again !']);
    //     }
    // }


}
